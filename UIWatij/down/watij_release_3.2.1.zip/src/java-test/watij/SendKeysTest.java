package watij;

import static watij.finders.SymbolFactory.id;
import static watij.finders.SymbolFactory.name;

public class SendKeysTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textfields1.html");
    }

    public void testTabbing() throws Exception {
        ie.textField(name, "text1").focus();

//        ie.sendKeys("{tab}");
//        ie.sendKeys("Scooby");
//        assertEquals("Scooby", ie.textField(id, "text2").value());
    }

    public void testEnter() throws Exception {
        ie.textField(name, "text1").focus();
        ie.sendKeys("{tab}{tab}{tab}{tab}");
        ie.sendKeys("Dooby{enter}");
        assertTrue(ie.text().contains("PASS"));
    }
}
    
 
