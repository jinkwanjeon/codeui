package watij;

import static watij.finders.SymbolFactory.name;

public class IFrameTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "iframeTest.html");
    }

    public void testIframe() throws Exception {
        ie.frame("senderFrame").textField(name, "textToSend").set("Hello World");
        ie.frame("senderFrame").button(0).click();
        assertTrue(ie.frame("receiverFrame").textField(name, "receiverText").verifyContains("Hello World"));
    }

}
