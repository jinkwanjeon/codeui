package watij;

import static watij.finders.SymbolFactory.value;

public class FlashTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "buttons1.html");
    }

    //For now requires manual verification
    public void testButtonFlashing() throws Exception {
        ie.bringToFront();
        ie.button(value, "diffvalue2").flash();
        ie.buttons().flash();
    }
}
