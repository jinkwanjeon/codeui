package watij;

public class WidthHeightTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "pass.html");
    }

    public void testWidthAndHeight() throws Exception {
        ie.bringToFront();
        int orig_width = ie.width();
        int orig_height = ie.height();
        ie.width(200);
        ie.height(100);
        assertTrue(200 == ie.width() || 250 == ie.width());
        assertEquals(100, ie.height());
        ie.width(orig_width);
        ie.height(orig_height);
    }
}
