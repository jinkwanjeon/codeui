/* Copyright (c) 2006, CA Inc.  All rights reserved */
package watij.jniwrapper;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import com.jniwrapper.win32.ie.IEAutomation;
import com.jniwrapper.win32.ie.WebBrowser;
import com.jniwrapper.win32.ie.event.NavigationEventListener;
import com.jniwrapper.win32.ie.dom.SelectElement;
import com.jniwrapper.win32.ie.dom.OptionElement;
import com.jniwrapper.win32.ie.dom.HTMLElement;
import org.w3c.dom.NodeList;

import java.util.List;

public class VistaTeamDevTest extends TestCase
{
	private IEAutomation webBrowser;
	private VistaTeamDevTest.IEListener listener;

	public void testLinkWaitReady() {
		try {
			//setUp();
			new VistaTeamDevTest.ConditionRunner(10000, 200).waitUntil(new VistaTeamDevTest.Condition() {
				public boolean isSatisfied() {
					//noinspection CatchGenericClass
					try {
						webBrowser = new IEAutomation();
						return true;
					} catch (final Throwable t) {
						System.err.println(t.getMessage());
						return false;
					}
				}
			});
			listener = new VistaTeamDevTest.IEListener();
			webBrowser.addNavigationListener(listener);
			webBrowser.setVisible(true);
			//goto url
			listener.setNavigationCompleted(false);
			webBrowser.navigate("http://www.google.com/");
			new VistaTeamDevTest.ConditionRunner(180000, 200).waitUntil(new VistaTeamDevTest.Condition() {
				public boolean isSatisfied() {
					return listener.isNavigationCompleted();
				}
			});
			webBrowser.waitReady();

            webBrowser.close();
        } catch (Exception e) {
			e.printStackTrace();
            fail("Should not have thrown an exception");
        }
	}

	private SelectElement findSelectListByName(final String name) {
		final NodeList list = webBrowser.getDocument().getElementsByTagName("select");
		for (int i = 0; i < list.getLength(); i++) {
			final SelectElement l = (SelectElement) list.item(i);
			if (name.equals(l.getAttribute("name")))
				return l;
		}
		throw new RuntimeException("Can't find select list with name " + name);
	}

	public void selectItem(final SelectElement elem, final String item) throws Exception {
		//noinspection unchecked
		final List<OptionElement> optionsArray = elem.getOptions();
		for (final OptionElement optionElement : optionsArray) {
			if (item.equals(optionElement.getText())) {
				optionElement.select();
				return;
			}
		}
		throw new RuntimeException("No option with text of " + item + " in this select element");
	}

	private HTMLElement findButtonByValue(final String value) {
		final NodeList list = webBrowser.getDocument().getElementsByTagName("input");
		for (int i = 0; i < list.getLength(); i++) {
			final HTMLElement elem = (HTMLElement) list.item(i);
			if ("button".equals(elem.getAttribute("type")) &&
			    value.equals(elem.getAttribute("value")))
				return elem;
		}
		throw new RuntimeException("Can't find button with value " + value);
	}

	private HTMLElement findLeftPanel() {
		//noinspection unchecked
		final List<HTMLElement> frames = webBrowser.getDocument().getFrames();
		for (final HTMLElement frame : frames) {
			if ("left_panel".equals(frame.getAttribute("name")))
				return frame;
		}
		throw new RuntimeException("Can't find left panel frame");
	}

	private HTMLElement findLogoutLink() {
		final HTMLElement leftPanel = findLeftPanel();
		final NodeList list = leftPanel.getElementsByTagName("A");
		for (int i = 0; i < list.getLength(); i++) {
			final HTMLElement elem = (HTMLElement) list.item(i);
			final String url = elem.getAttribute("href");
			if (url != null && url.contains("logout()"))
				return elem;
		}
		throw new RuntimeException("Can't find logout link");
	}

    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }

    public static Test suite()
    {
        return new TestSuite( VistaTeamDevTest.class );
    }

	public static interface Condition {
		boolean isSatisfied();
	}

	public static class ConditionRunner {
		private long timeout;
		private long waitIncrement;

		public ConditionRunner(final long timeout, final long waitIncrement) {
			this.timeout = timeout;
			this.waitIncrement = waitIncrement;
		}

		public void waitUntil(final VistaTeamDevTest.Condition cond) throws Exception {
			final long started = System.currentTimeMillis();
			while (!cond.isSatisfied()) {
				if (System.currentTimeMillis() - started > timeout) {
					throw new RuntimeException("Timeout exceeded");
				}
				try {
					Thread.sleep(waitIncrement);
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	public static class IEListener implements NavigationEventListener
  {
		private boolean navigationCompleted;


		public void setNavigationCompleted(final boolean navigationCompleted) {
			this.navigationCompleted = navigationCompleted;
		}

		public boolean isNavigationCompleted() {
			return navigationCompleted;
		}

		public void downloadBegin() {
		}

		public void downloadCompleted() {
		}

		public void documentCompleted(final WebBrowser webBrowser, final String string) {
		}

		public void entireDocumentCompleted(final WebBrowser webBrowser, final String string) {
		}

		public void navigationCompleted(final WebBrowser webBrowser, final String string) {
			navigationCompleted = true;
		}

		public void progressChanged(final int i, final int i1) {
		}
	}
}
