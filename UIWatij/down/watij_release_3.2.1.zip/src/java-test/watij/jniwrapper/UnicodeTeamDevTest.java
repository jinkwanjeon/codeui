/* Copyright (c) 2006, CA Inc.  All rights reserved */
package watij.jniwrapper;

import com.jniwrapper.win32.ie.IEAutomation;
import com.jniwrapper.win32.ie.WebBrowser;
import com.jniwrapper.win32.ie.event.NavigationEventListener;
import com.jniwrapper.win32.ie.dom.HTMLElement;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.File;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.framework.Test;

public class UnicodeTeamDevTest extends TestCase {
    private static final String HTML_ROOT = System.getProperty("HTML_ROOT");

	private IEAutomation webBrowser;
	private UnicodeTeamDevTest.IEListener listener;

	public void testTeamDevUnicodeSupport() {
		try {
			Properties props = new Properties();
            props.load(new FileInputStream(HTML_ROOT + "..\\unicode.properties"));


            new UnicodeTeamDevTest.ConditionRunner(10000, 200).waitUntil(new UnicodeTeamDevTest.Condition() {
				public boolean isSatisfied() {
					//noinspection CatchGenericClass
					try {
						webBrowser = new IEAutomation();
						return true;
					} catch (final Throwable t) {
						t.printStackTrace();
						return false;
					}
				}
			});
			listener = new UnicodeTeamDevTest.IEListener();
			webBrowser.addNavigationListener(listener);
			webBrowser.setVisible(true);
			//goto url
			listener.setNavigationCompleted(false);
			webBrowser.navigate(HTML_ROOT + "unicode.html");
			new UnicodeTeamDevTest.ConditionRunner(180000, 200).waitUntil(new UnicodeTeamDevTest.Condition() {
				public boolean isSatisfied() {
					return listener.isNavigationCompleted();
				}
			});
			webBrowser.waitReady();

            findButtonByText(props.getProperty("simplified_chinese")).click();
			webBrowser.waitReady();
            findButtonByText(props.getProperty("french")).click();
            webBrowser.waitReady();

            webBrowser.close();

        } catch (Exception e) {
			e.printStackTrace();
            fail("Should not have thrown an exception");
        }
	}

	private HTMLElement findButtonByText(final String name) {
		final NodeList list = webBrowser.getDocument().getElementsByTagName("button");
		for (int i = 0; i < list.getLength(); i++) {
			final HTMLElement elem = (HTMLElement) list.item(i);
            if (name.equals(elem.getText()))
                return elem;
        }
		throw new RuntimeException("Can't find button with name " + name);
	}

    public static void main( String[] args )
    {
        junit.textui.TestRunner.run( suite() );
    }
    
    public static Test suite()
    {
        return new TestSuite( UnicodeTeamDevTest.class );
    }

    public static interface Condition {
		boolean isSatisfied();
	}

	public static class ConditionRunner {
		private long timeout;
		private long waitIncrement;

		public ConditionRunner(final long timeout, final long waitIncrement) {
			this.timeout = timeout;
			this.waitIncrement = waitIncrement;
		}

		public void waitUntil(final UnicodeTeamDevTest.Condition cond) throws Exception {
			final long started = System.currentTimeMillis();
			while (!cond.isSatisfied()) {
				if (System.currentTimeMillis() - started > timeout) {
					throw new RuntimeException("Timeout exceeded");
				}
				try {
					Thread.sleep(waitIncrement);
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	public static class IEListener implements NavigationEventListener {
		private boolean navigationCompleted;


		public void setNavigationCompleted(final boolean navigationCompleted) {
			this.navigationCompleted = navigationCompleted;
		}

		public boolean isNavigationCompleted() {
			return navigationCompleted;
		}

		public void downloadBegin() {
		}

		public void downloadCompleted() {
		}

		public void documentCompleted(final WebBrowser webBrowser, final String string) {
		}

		public void entireDocumentCompleted(final WebBrowser webBrowser, final String string) {
		}

		public void navigationCompleted(final WebBrowser webBrowser, final String string) {
			navigationCompleted = true;
		}

		public void progressChanged(final int i, final int i1) {
		}
	}
}
