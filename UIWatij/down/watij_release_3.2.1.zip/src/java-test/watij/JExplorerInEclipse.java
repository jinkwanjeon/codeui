package watij;

import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.automation.types.VariantBool;
import com.jniwrapper.win32.com.types.ClsCtx;
import com.jniwrapper.win32.ie.AuthenticateHandler;
import com.jniwrapper.win32.ie.BrowserSupport;
import com.jniwrapper.win32.ie.KeyFilter;
import com.jniwrapper.win32.ie.WebBrowser;
import com.jniwrapper.win32.ie.event.*;
import com.jniwrapper.win32.shdocvw.IWebBrowser2;
import com.jniwrapper.win32.shdocvw.InternetExplorer;
import com.jniwrapper.win32.ui.Wnd;

import java.beans.PropertyChangeListener;
import java.util.List;

public class JExplorerInEclipse extends BrowserSupport {


    public static void main(String[] args) throws Exception {
        JExplorerInEclipse jExplorerInEclipse = new JExplorerInEclipse();
        jExplorerInEclipse.navigate("http://www.google.com");
    }


    public JExplorerInEclipse() throws Exception {
        super(OleMessageLoop.getInstance());
        createBrowser();
    }

    private void createBrowser() throws Exception {
        OleMessageLoop.getInstance().doInvokeAndWait(new Runnable() {
            public void run() {
                try {
                    IWebBrowser2 browser = InternetExplorer.create(ClsCtx.LOCAL_SERVER);
                    browser.setVisible(VariantBool.TRUE);
                    setBrowser(browser);
                } catch (Exception e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        });
    }

    protected Wnd getBrowserWindow() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addPropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removePropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNavigationListener(NavigationEventListener navigationEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeNavigationListener(NavigationEventListener navigationEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getNavigationListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addStatusListener(StatusEventListener statusEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeStatusListener(StatusEventListener statusEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getStatusListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setEventHandler(WebBrowserEventsHandler webBrowserEventsHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowserEventsHandler getEventHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setDialogEventHandler(DialogEventHandler dialogEventHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public DialogEventHandler getDialogEventHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setScriptErrorListener(ScriptErrorListener scriptErrorListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public ScriptErrorListener getScriptErrorListener() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void close() {
        //To change body of implemented methods use File | Settings | File Templates.
    }


    public void setAuthenticateHandler(AuthenticateHandler authenticateHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }


    public AuthenticateHandler getAuthenticateHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setNewWindowHandler(NewWindowEventHandler newWindowEventHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public NewWindowEventHandler getNewWindowHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNewWindowListener(NewWindowEventListener newWindowEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeNewWindowListener(NewWindowEventListener newWindowEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getNewWindowListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setKeyFilter(KeyFilter keyFilter) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public KeyFilter getKeyFilter() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void trackChildren() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser getRecentChild() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser waitChildCreation() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser waitChildCreation(Runnable runnable) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
