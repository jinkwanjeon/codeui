package watij;

import static watij.finders.SymbolFactory.title;
import static watij.finders.SymbolFactory.url;
import watij.runtime.NoMatchingWindowFoundException;
import watij.runtime.ie.IE;

public class AttachToExistingWindowTest extends WatijTestCase {

    IE ie;

    protected void setUp() throws Exception {
        ie = new IE();
        ie.start();
        ie.goTo(HTML_ROOT + "buttons1.html");
    }


    protected void tearDown() throws Exception {
        ie.close();
    }

    public void testExistingWindow() throws Exception {

        IE ie3 = new IE();

        try {
            ie3.attach(title, "missing");
            fail();
        } catch (NoMatchingWindowFoundException e) {
        }
        try {
            ie3.attach(title, "/missing/");
            fail();
        } catch (NoMatchingWindowFoundException e) {
        }
        try {
            ie3.attach(url, "missing");
            fail();
        } catch (NoMatchingWindowFoundException e) {
        }
        try {
            ie3.attach(url, "/missing/");
            fail();
        } catch (NoMatchingWindowFoundException e) {
        }

        ie3.attach(title, "/(?i:buttons)/");
        assertEquals("Test page for buttons", ie3.title());

        ie3.close();
        ie = new IE();
        ie.start(HTML_ROOT + "buttons1.html");
        ie3 = new IE();

        ie3.attach(title, "Test page for buttons");
        assertEquals("Test page for buttons", ie3.title());

        ie3.close();
        ie = new IE();
        ie.start(HTML_ROOT + "buttons1.html");
        ie3 = new IE();

        ie3.attach(url, "/buttons1.html/");
        assertEquals("Test page for buttons", ie3.title());

//           #hard to test url with explicit text
    }


}
