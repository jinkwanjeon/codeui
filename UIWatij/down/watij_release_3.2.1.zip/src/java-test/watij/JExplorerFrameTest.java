package watij;

import junit.framework.TestCase;

public class JExplorerFrameTest extends TestCase {

    public void testDummy() throws Exception {
        assertTrue(true);
    }

//    public static final String HTML_ROOT = System.getProperty("HTML_ROOT");
//
//    public void testFrame() throws Exception {
//        BrowserSupport browser = new MyBrowser();
//        browser.navigate(HTML_ROOT + "frame_buttons.html");
//        browser.waitReady();
//    }
//
//    public void testBehaviors() throws Exception {
//        BrowserSupport browser = new MyBrowser();
//        browser.navigate(HTML_ROOT + "testBehaviors.html");
//        browser.waitReady();
//
//        browser.executeScript("alert('hello');");
//        String text = browser.getDocument().getElementById("customID").getFirstChild().getNodeValue().trim();
//
//        assertEquals("Read Doc JavaScript's columns, tips, tools, and tutorials", text);
//    }
//
//    public static class MyBrowser extends BrowserSupport {
//
//        public MyBrowser() throws Exception {
//            super(OleMessageLoop.getInstance());
//            createBrowser();
//        }
//
//        private void createBrowser() throws Exception {
//            OleMessageLoop.getInstance().doInvokeAndWait(new Runnable() {
//                public void run() {
//                    try {
//                        IWebBrowser2 browser = InternetExplorer.create(ClsCtx.LOCAL_SERVER);
//                        browser.setVisible(VariantBool.TRUE);
//                        setBrowser(browser);
//                    } catch (Exception e1) {
//                        e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//                    }
//                }
//            });
//        }
//
//        protected Wnd getBrowserWindow() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void addPropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void removePropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void addNavigationListener(NavigationEventListener navigationEventListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void removeNavigationListener(NavigationEventListener navigationEventListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public List getNavigationListeners() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void addStatusListener(StatusEventListener statusEventListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void removeStatusListener(StatusEventListener statusEventListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public List getStatusListeners() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void setEventHandler(WebBrowserEventsHandler webBrowserEventsHandler) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public WebBrowserEventsHandler getEventHandler() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void setDialogEventHandler(DialogEventHandler dialogEventHandler) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public DialogEventHandler getDialogEventHandler() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void setScriptErrorListener(ScriptErrorListener scriptErrorListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public ScriptErrorListener getScriptErrorListener() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void close() {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void setNewWindowHandler(NewWindowEventHandler newWindowEventHandler) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public NewWindowEventHandler getNewWindowHandler() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void addNewWindowListener(NewWindowEventListener newWindowEventListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void removeNewWindowListener(NewWindowEventListener newWindowEventListener) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public List getNewWindowListeners() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void setKeyFilter(KeyFilter keyFilter) {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public KeyFilter getKeyFilter() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public void trackChildren() {
//            //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public WebBrowser getRecentChild() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public WebBrowser waitChildCreation() {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//        public WebBrowser waitChildCreation(Runnable runnable) {
//            return null;  //To change body of implemented methods use File | Settings | File Templates.
//        }
//
//    }
}
