package watij;

import static watij.finders.FinderFactory.id;

public class ExecuteScriptTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textfields1.html");
    }

    public void testSettingTextField() throws Exception {
        ie.executeScript("document.all.text2.value='set by execute';");
        assertEquals("set by execute", ie.textField(id("text2")).value());
    }

    public void testGettingTextField() throws Exception {
        ie.textField(id("text2")).set("get by execute");
        assertEquals("get by execute",ie.executeScript("document.all.text2.value;"));
    }
}