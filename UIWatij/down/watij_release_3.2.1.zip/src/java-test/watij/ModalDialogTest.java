package watij;

import static watij.finders.SymbolFactory.*;
import watij.runtime.UnknownObjectException;
import watij.dialogs.ModalDialog;

public class ModalDialogTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "modal_dialog_launcher.html");
        ie.bringToFront();
    }

    public void testModalDialog() throws Exception {
        new Thread(new Runnable() {
            public void run() {
                try {
                    ie.button("Launch Dialog").click();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
        ModalDialog modalDialog = ie.modalDialog();
        System.out.println("modalDialog.html() = " + modalDialog.html());
        modalDialog.textField(name, "modal_text").set("hello");
        modalDialog.button(value, "Close").click();
        assertEquals("hello", ie.textField(name, "modaloutput").value());
    }

    public void testModalDialogWithFrames() throws Exception {
        ie.textField(name, "modalpath").set("frame_buttons.html");
        new Thread(new Runnable() {
            public void run() {
                try {
                    ie.button("Launch Dialog").click();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
        ModalDialog modalDialog = ie.modalDialog();
        assertTrue(modalDialog.frame("buttonFrame").button(caption, "Click Me").enabled());
        try {
            modalDialog.button(caption, "Disabled Button").enabled();
            fail("Did not throw UnknownObjectException");
        } catch (UnknownObjectException e) {
        }
        modalDialog.close();
        assertEquals("undefined", ie.textField(name, "modaloutput").value());
    }
}
