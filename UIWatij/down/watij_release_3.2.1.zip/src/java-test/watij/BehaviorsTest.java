package watij;

import static watij.finders.SymbolFactory.id;

public class BehaviorsTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "testBehaviors.html");
    }

    public void testShow() throws Exception {
        ie.show();
    }

    public void testText() throws Exception {
        String text = ie.htmlElement(id, "customID").text().trim();
        assertEquals("Read Doc JavaScript's columns, tips, tools, and tutorials", text);
    }
}
