package watij;

public class TopLeftTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "pass.html");
    }

    public void testWidthAndHeight() throws Exception {
        ie.bringToFront();
        ie.top(200);
        ie.left(100);
        assertEquals(200, ie.top());
        assertEquals(100, ie.left());
    }

}
