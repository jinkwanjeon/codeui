package watij;

import watij.elements.Frame;
import static watij.finders.SymbolFactory.*;
import watij.runtime.UnknownObjectException;

public class FrameTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "frame_buttons.html");
    }

    public void testFrameNoWhat() throws Exception {
        try {
            ie.frame("missingFrame").button(id, "b2");
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.frame("buttonFrame2").button(id, "b2"));
        assertTrue(ie.frame("buttonFrame").button(id, "b2").enabled());
        assertFalse(ie.frame("buttonFrame").button(caption, "Disabled Button").enabled());
    }

    public void testFrameTitle() throws Exception {
        assertEquals("Test page for buttons", ie.frame("buttonFrame").title());
    }

    public void testFrameUsingName() throws Exception {
        try {
            ie.frame(name, "missingFrame").button(id, "b2");
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.frame(name, "buttonFrame2").button(id, "b2"));
        assertTrue(ie.frame(name, "buttonFrame").button(id, "b2").enabled());
        assertFalse(ie.frame(name, "buttonFrame").button(caption, "Disabled Button").enabled());
    }

    public void testFrameUsingNameAndRegexp() throws Exception {
        try {
            ie.frame(name, "/missingFrame/").button(id, "b2");
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertTrue(ie.frame(name, "/button/").button(id, "b2").enabled());
    }

    public void testFrameUsingIndex() throws Exception {
        try {
            ie.frame(8).button(id, "b2");
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.frame(1).button(id, "b2"));
        assertTrue(ie.frame(0).button(id, "b2").enabled());
        assertFalse(ie.frame(0).button(caption, "Disabled Button").enabled());
    }

    public void testFrameContainsText() throws Exception {
        Frame frame = ie.frame(name, "buttonFrame");
        assertTrue(frame.containsText("The top button is for testing buttons"));
    }

    //!? Can't do this in Java
//    public void test_frame_with_invalid_attribute() throws Exception {
//        assert_raises(ArgumentError) { ie.frame(blah, 'no_such_thing').button(id, "b2").enabled()  }
//    }

    //!? Can't do this in Java
//    public void test_preset_frame() throws Exception {
//        # with ruby's instance_eval, we are able to use the same frame for several actions
//        results = ie.frame("buttonFrame").instance_eval do [
//            button(id, "b2").enabled(),
//            button(caption, "Disabled Button").enabled()
//            ]
//        }
//        assert_equal([true, false], results)
//    }
//
//}
//

//
//require 'unittests/iostring'
//class TC_show_frames < TestUnitTestCase
//    include MockStdoutTestCase
//
//    public void capture_and_compare(page, expected)
//        ie.goto(htmlRoot + page)
//        stdout = @mockout
//        ie.showFrames
//        assert_equal(expected, @mockout)
//    }
//
//    public void test_show_nested_frames
//        capture_and_compare("nestedFrames.html", <<END_OF_MESSAGE)
//there are 2 frames
//frame  index 1 name nestedFrame
//frame  index 2 name nestedFrame2
//END_OF_MESSAGE
//    }
//
//    public void test_button_frames
//        capture_and_compare("frame_buttons.html", <<END_OF_MESSAGE)
//there are 2 frames
//frame  index 1 name buttonFrame
//frame  index 2 name buttonFrame2
//END_OF_MESSAGE
//    }
//
//    public void test_iframes
//        capture_and_compare("iframeTest.html", <<END_OF_MESSAGE)
//there are 2 frames
//frame  index 1 name s}erFrame
//frame  index 2 name receiverFrame
//END_OF_MESSAGE
//    }
//
//}


}
