package watij;

public class HttpHeaderTest extends WatijTestCase {

    public void testHttpHeaders() throws Exception {
        ie.bringToFront();
        ie.setAdditionalHttpHeaders("User-Agent: 007\n\rReferer: Majestys Secret Service\n\r");
//        ie.bringToFront();
        ie.goTo("http://pgl.yoyo.org/http/browser-headers.php");
//        assertTrue(ie.containsText("Keep-Alive"));
        assertTrue(ie.containsText("007"));
        assertTrue(ie.containsText("Majestys Secret Service"));
        ie.setAdditionalHttpHeaders(null);
    }

}
