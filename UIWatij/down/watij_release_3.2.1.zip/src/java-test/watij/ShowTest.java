package watij;

import static watij.finders.SymbolFactory.name;

public class ShowTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "buttons1.html");
    }

    public void testShowElement() throws Exception {
        ie.button(name, "buttonTag").show();
    }

    public void testShowElementCollections() throws Exception {
        ie.buttons().show();
    }

    public void testShowIE() throws Exception {
        ie.show();
    }
}
