package watij;

import junit.framework.TestCase;

public class JExplorerChildBrowserTest extends TestCase {

    public void testDummy() throws Exception {
        assertTrue(true);
    }

//    public static final String HTML_ROOT = System.getProperty("HTML_ROOT");
//
//    public void testJExplorerHtmlWindow() throws Exception {
//        NativeResourceCollector.getInstance().stop();
//        final ModalDialogSupport ieSupport = new ModalDialogSupport();
//        ieSupport.navigate(HTML_ROOT + "new_browser.html");
//        ieSupport.waitReady();
//        assertTrue(ieSupport.getContent().contains("New Browser Launcher"));
//        OleMessageLoop oleMessageLoop = ieSupport.getOleMessageLoop();
//
//        IHTMLDocument2 document2 = (IHTMLDocument2)oleMessageLoop.bindObject((IHTMLDocument2) ieSupport.getDocument().getDocumentPeer());
//        IHTMLWindow2 ihtmlWindow2 = (IHTMLWindow2)oleMessageLoop.bindObject(document2.getParentWindow());
//        System.out.println("ihtmlWindow2.getName().getValue() = " + ihtmlWindow2.getName().getValue());
//        System.out.println("ihtmlWindow2.getClosed() = " + ihtmlWindow2.getClosed());
//        ieSupport.executeScript("window.opener=null;window.close();");
//        System.out.println("document2 readystate = " + document2.getReadyState().getValue());
//        System.out.println("ihtmlWindow2.getClosed() = " + ihtmlWindow2.getClosed());
//    }
//
//    public void testJExplorerChildBrowser() throws Exception {
//        for (int i = 0; i < 20; i++) {
//            doTestJExplorerChildBrowser();
//        }
//    }
//
//    private void doTestJExplorerChildBrowser() throws Exception {
//
//        ModalDialogSupport ieSupport = new ModalDialogSupport();
//        ieSupport.navigate(HTML_ROOT + "new_browser.html");
//        ieSupport.waitReady();
//        assertTrue(ieSupport.getContent().contains("New Browser Launcher"));
//
//        HTMLDocument htmlDocument = ieSupport.getDocument();
//        NodeList nodeList = htmlDocument.getElementsByTagName("a");
//        HTMLElement htmlElement = (HTMLElement) nodeList.item(1);
//        htmlElement.click();
//
//        ieSupport.waitForChildBrowser(0);
//        ModalDialogSupport childBrowser = ieSupport.getChildBrowser(0);
//        childBrowser.waitReady();
//        assertTrue(childBrowser.getContent().contains("PASS"));
//        childBrowser.close();
//        ieSupport.close();
//        Thread.sleep(1000);
//    }
}
