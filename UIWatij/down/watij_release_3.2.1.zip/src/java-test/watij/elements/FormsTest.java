package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;
import watij.runtime.UnknownObjectException;

public class FormsTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "forms2.html");
    }

    public void testFormExists() throws Exception {
        assertTrue(ie.form(name, "test2").exists());
        assertFalse(ie.form(name, "missing").exists());

        assertTrue(ie.form("test2").exists());
        assertFalse(ie.form("missing").exists());

        assertTrue(ie.form(0).exists());
        assertFalse(ie.form(88).exists());

        assertTrue(ie.form(method, "get").exists());
        assertFalse(ie.form(method, "missing").exists());

        assertTrue(ie.form(action, "pass.html").exists());
        assertFalse(ie.form(action, "missing").exists());
    }

    public void testButtonInForm() throws Exception {
        assertTrue(ie.form(name, "test2").button(caption, "Submit").exists());
    }

    //WATIR # The following tests from bug 2261
    public void testFormHtml() throws Exception {
        assertEquals("\r\n<FORM name=test2 action=pass2.html method=get><BR><INPUT type=submit value=Submit> </FORM>", ie.form(name, "test2").html());
    }

    public void testFormFlash() throws Exception {
        try {
            ie.form(name, "test2").flash();
        } catch (Exception e) {
            fail("Exception should not have been thrown");
        }
    }

    public void test_form_sub_element() throws Exception {
        assertEquals("Click Me", ie.form(0).button(name, "b1").value());
    }

    public void test_showforms() throws Exception {
        ie.forms().show();
    }

//
//    # The following tests from bug 2261
//    public void test_p_in_form
//        ie.form(name, "buttonsubmit").p(1).text
//    }
//

    public void test_Form_Exists() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        assertTrue(ie.form(name, "test2").exists());
        assertFalse(ie.form(name, "missing").exists());

        assertTrue(ie.form("test2").exists());
        assertFalse(ie.form("missing").exists());

        assertTrue(ie.form(0).exists());
        assertFalse(ie.form(88).exists());

        assertTrue(ie.form(method, "get").exists());
        assertFalse(ie.form(method, "missing").exists());

        assertTrue(ie.form(action, "pass.html").exists());
        assertFalse(ie.form(action, "missing").exists());
    }

    public void test_index_other_element_before_it() throws Exception {
        //# test for bug reported by Scott Pack,  http//rubyforge.org/pipermail/wtr-general/2005-June/002223.html
        ie.goTo(HTML_ROOT + "forms3.html");
        assertEquals("check1", ie.checkbox(0).name());
    }

    public void test_reset() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        ie.textField(id, "t1").set("Hello, reset test!");
        assertEquals(ie.textField(id, "t1").getContents(), "Hello, reset test!");

        ie.button(caption, "Reset").click();
        assertEquals("", ie.textField(id, "t1").getContents());

        //# also verify it works under a form
        ie.textField(id, "t1").set("reset test - using a form");
        assertEquals(ie.textField(id, "t1").getContents(), "reset test - using a form");

        ie.form(1).button(1).click();
        assertEquals("", ie.textField(id, "t1").getContents());

        //# also verify it works under a form, this time using the id attribute
        ie.textField(id, "t1").set("reset test - using a form");
        assertEquals(ie.textField(id, "t1").getContents(), "reset test - using a form");

        ie.form(1).button(id, "reset_button").click();
        assertEquals("", ie.textField(id, "t1").getContents());
    }

    public void test_flash1() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        ie.form(name, "test2").button(caption, "Submit").flash();
    }

    public void test_objects_with_same_name() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        assertEquals("textfield", ie.textField(name, "g1").value());
        assertEquals("button", ie.button(name, "g1").value());
        assertEquals("1", ie.checkbox(name, "g1").value());
        assertEquals("2", ie.radio(name, "g1").value());

        assertEquals("textfield_id", ie.textField(id, "g1").value());
        assertEquals("button_id", ie.button(id, "g1").value());
        assertEquals("1_id", ie.checkbox(id, "g1").value());
        assertEquals("2_id", ie.radio(id, "g1").value());
    }

    public void test_flash2() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        ie.button(value, "Click Me").flash();
        try {
            ie.textField(name, "g177").flash();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
    }

    public void test_submitWithImage() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        assertTrue(ie.button(alt, "submit").exists());
        assertTrue(ie.button(alt, "/sub/").exists());

        assertFalse(ie.button(alt, "missing").exists());
        assertFalse(ie.button(alt, "/missing/").exists());

//        #assertTrue( ie.button(src , "file"/"/"/#{myDir}"/html"/images"/button.jpg").exists() )    # this doesnt work for everybody
        assertTrue(ie.button(src, "/button/").exists());

        assertFalse(ie.button(src, "missing").exists());
        assertFalse(ie.button(src, "/missing/").exists());

        ie.button(src, "/button/").click();
        assertTrue(ie.text().contains("PASS"));
    }


    public void test_find_textField_ignoring_form() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        assertEquals(ie.textField(name, "name").getContents(), "apple"); //# should it raise a not-unique error instead();
    }

    public void test_correct_form_field_is_found_using_form_name() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        assertEquals(ie.form(name, "apple_form").textField(name, "name").getContents(), "apple");
        assertEquals(ie.form(name, "banana_form").textField(name, "name").getContents(), "banana");
    }

    public void test_correct_form_field_is_found_using_form_index() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        assertEquals(ie.form(0).textField(name, "name").getContents(), "apple");
        assertEquals(ie.form(1).textField(name, "name").getContents(), "banana");
    }

    public void test_using_text_on_form() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        ie.form(name, "apple_form").textField(name, "name").set("strudel");
        assertEquals(ie.form(0).textField(name, "name").getContents(), "strudel");
    }

    public void test_submit() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        ie.form(name, "apple_form").submit();
        assertTrue(ie.text().contains("PASS"));
    }

    public void test_hidden() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");

        //# test using index
        assertTrue(ie.hidden(0).exists());
        assertTrue(ie.hidden(1).exists());
        assertFalse(ie.hidden(2).exists());

        ie.hidden(0).set("44");
        ie.hidden(1).set("55");

        ie.button(value, "Show Hidden").click();

        assertEquals("44", ie.textField(name, "vis1").value());
        assertEquals("55", ie.textField(name, "vis2").value());

        //# test using name and ID
        assertTrue(ie.hidden(name, "hid1").exists());
        assertTrue(ie.hidden(id, "hidden_1").exists());
        assertFalse(ie.hidden(name, "hidden_44").exists());
        assertFalse(ie.hidden(id, "hidden_55").exists());

        ie.hidden(name, "hid1").set("444");
        ie.hidden(id, "hidden_1").set("555");

        ie.button(value, "Show Hidden").click();

        assertEquals("444", ie.textField(name, "vis1").value());
        assertEquals("555", ie.textField(name, "vis2").value());

        //#  test the over-ridden app} method
        ie.hidden(name, "hid1").append("a");
        ie.button(value, "Show Hidden").click();
        assertEquals("444a", ie.textField(name, "vis1").value());
        assertEquals("555", ie.textField(name, "vis2").value());

        //#  test the over-ridden clear method
        ie.hidden(name, "hid1").clear();
        ie.button(value, "Show Hidden").click();
        assertEquals("", ie.textField(name, "vis1").value());
        assertEquals("555", ie.textField(name, "vis2").value());

        //# test using a form
        assertTrue(ie.form(name, "has_a_hidden").hidden(name, "hid1").exists());
        assertTrue(ie.form(name, "has_a_hidden").hidden(id, "hidden_1").exists());
        assertFalse(ie.form(name, "has_a_hidden").hidden(name, "hidden_44").exists());
        assertFalse(ie.form(name, "has_a_hidden").hidden(id, "hidden_55").exists());

        ie.form(name, "has_a_hidden").hidden(name, "hid1").set("222");
        ie.form(name, "has_a_hidden").hidden(id, "hidden_1").set("333");

        ie.button(value, "Show Hidden").click();

        assertEquals("222", ie.textField(name, "vis1").value());
        assertEquals("333", ie.textField(name, "vis2").value());

        //# iterators
        assertEquals(2, ie.hiddens().length());

        int count = 0;
        for (Hidden h : ie.hiddens()) {

            if (count == 0) {
                assertEquals("", h.id());
                assertEquals("hid1", h.name());
            }
            if (count == 1) {
                assertEquals("", h.name());
                assertEquals("hidden_1", h.id());
            }
            count++;
        }

        assertEquals("hid1", ie.hiddens().get(0).name());
        assertEquals("hidden_1", ie.hiddens().get(1).id());
    }
}
