package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.xpath;
import watij.runtime.ObjectDisabledException;

public class TextFieldsXpathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textfields1.html");
    }


    public void testTextFieldExists() throws Exception {
        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").exists());
        assertFalse(ie.textField(xpath, "//INPUT[@name='missing']").exists());

        assertTrue(ie.textField(xpath, "//INPUT[@id='text2']").exists());
        assertFalse(ie.textField(xpath, "//INPUT[@id='alsomissing']").exists());

//       #assertTrue(ie.textField(xpath , "//INPUT[@beforeText='This Text After']").exists() )
//       #assertTrue(ie.textField(xpath , "//INPUT[@afterText='This Text Before']").exists() )
    }

//    public void test_textField_dragContentsTo
//        ie.textField(xpath , "//INPUT[@name='text1']").dragContentsTo(xpath , "//INPUT[@id='text2']")
//        assertEquals(ie.textField(xpath , "//INPUT[@name='text1']").value, "" )
//        assertEquals(ie.textField(xpath , "//INPUT[@id='text2']").value, "goodbye allHello World" )
//    }

    public void testTextFieldVerifyContents() throws Exception {
        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("Hello World"));
        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("/Hello\\sW/"));
        assertFalse(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("Ruby"));
        assertFalse(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("/R/"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(xpath, "//INPUT[@name='NoName']"), "No field to get a value of");

        assertTrue(ie.textField(xpath, "//INPUT[@id='text2']").verifyContains("goodbye all"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(xpath, "/INPUT[@id='noID']"), "No field to get a value of");
    }

    public void testTextFieldEnabled() throws Exception {
        assertFalse(ie.textField(xpath, "//INPUT[@name='disabled']").enabled());
        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").enabled());
        assertTrue(ie.textField(xpath, "//INPUT[@id='text2']").enabled());
    }

    public void testTextFieldReadOnly() throws Exception {
        assertFalse(ie.textField(xpath, "//INPUT[@name='disabled']").readOnly());
        assertTrue(ie.textField(xpath, "//INPUT[@name='readOnly']").readOnly());
        assertTrue(ie.textField(xpath, "//INPUT[@id='readOnly2']").readOnly());
    }

    public void testTextFieldValue() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodValue(ie.textField(xpath, "//INPUT[@name='missing_field']"));
        assertEquals("Hello World", ie.textField(xpath, "//INPUT[@name='text1']").value());
    }
//
//    public void build_to_s_regex(lhs, rhs)
//        Regexp.new("^#{lhs} +#{rhs}")
//    }
//

    public void testTextFieldAppend() throws Exception {
        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(xpath, "//INPUT[@id='readOnly2']"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(xpath, "//INPUT[@name='disabled']"), "Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(xpath, "//INPUT[@name='missing_field']"), "Some Text");

        ie.textField(xpath, "//INPUT[@name='text1']").append(" Some Text");
        assertEquals("Hello World Some Text", ie.textField(xpath, "//INPUT[@name='text1']").value());
    }

    public void testTextFieldClear() throws Exception {
        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(xpath, "//INPUT[@id='readOnly2']"), "Some Text");
        try {
            ie.textField(xpath, "//INPUT[@name='disabled']").set("Some Text");
            failObjectDisabledException();
        } catch (ObjectDisabledException e) {
        }
        assertRaisesUnknownObjectExceptionForMethodValue(ie.textField(xpath, "//INPUT[@name='missing_field']"));

        ie.textField(xpath, "//INPUT[@name='text1']").clear();
        assertEquals("", ie.textField(xpath, "//INPUT[@name='text1']").value());
    }

    public void testTextFieldSet() throws Exception {
        try {
            ie.textField(xpath, "//INPUT[@name='disabled']").set("Some Text");
            failObjectDisabledException();
        } catch (ObjectDisabledException e) {
        }
        assertRaisesUnknownObjectExceptionForMethodValue(ie.textField(xpath, "//INPUT[@name='missing_field']"));

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(xpath, "//INPUT[@id='readOnly2']"), "Some Text");
        ie.textField(xpath, "//INPUT[@name='text1']").set("watir IE Controller");
        assertEquals("watir IE Controller", ie.textField(xpath, "//INPUT[@name='text1']").value());
    }

//    public void test_JS_Events() throws Exception {
//        ie.textField(xpath , "//INPUT[@name='events_tester']").set("p");
//
// //       # the following line has an extra keypress at the begining, as we mimic the delete key being pressed
//        assertEquals("keypresskeydownkeypresskeyup", ie.textField(xpath, "//TEXTAREA[@name='events_text']").value().replace("\r\n", ""));
//        ie.button(value , "Clear Events Box").click();
//        ie.textField(xpath , "//INPUT[@name='events_tester']").set("ab");
//
////        # the following line has an extra keypress at the begining, as we mimic the delete key being pressed
//        assertEquals("keypresskeydownkeypresskeyupkeydownkeypresskeyup", ie.textField(xpath, "//TEXTAREA[@name='events_text']").value().replace("\r\n", ""));
//    }
//

    public void testPassword() throws Exception {
        ie.textField(xpath, "//INPUT[@name='password1']").set("secret");
        assertEquals("secret", ie.textField(xpath, "//INPUT[@name='password1']").value());

        ie.textField(xpath, "//INPUT[@id='password1']").set("top_secret");
        assertEquals("top_secret", ie.textField(xpath, "//INPUT[@id='password1']").value());
    }


}
