package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.id;
import static watij.finders.SymbolFactory.name;

public class TextareaFieldsTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textArea.html");
    }


    public void testTextareaFieldExists() throws Exception {
//        #test for existance of 4 text area
        assertTrue(ie.textField(name, "txtMultiLine1").exists());
        assertTrue(ie.textField(name, "txtMultiLine2").exists());
        assertTrue(ie.textField(name, "txtMultiLine3").exists());
        assertTrue(ie.textField(name, "txtReadOnly").exists());

        assertTrue(ie.textField(id, "txtMultiLine1").exists());
        assertTrue(ie.textField(id, "txtMultiLine2").exists());
        assertTrue(ie.textField(id, "txtMultiLine3").exists());
        assertTrue(ie.textField(id, "txtReadOnly").exists());
//        #test for missing
        assertFalse(ie.textField(name, "missing").exists());
        assertFalse(ie.textField(name, "txtMultiLine4").exists());
    }

    public void testTextareaToString() throws Exception {
        //# from a bug reported by Zeljko Filipin
        // assertTrue_nothing_raised() { ie.textField(id,"txtMultiLine3").to_s  }
    }

    public void testTextareaField() throws Exception {
        //# test for read only method
        assertFalse(ie.textField(name, "txtMultiLine1").readOnly());
        assertTrue(ie.textField(name, "txtReadOnly").readOnly());
        //# test for enabled() method
        assertFalse(ie.textField(name, "txtDisabled").enabled());
        assertTrue(ie.textField(id, "txtMultiLine1").enabled());


        TextField t1 = ie.textField(name, "txtMultiLine1");
        assertTrue(t1.verifyContains("Hello World"));
        assertTrue(t1.verifyContains("/el/"));
        TextField t2 = ie.textField(name, "txtMultiLine2");
        assertTrue(t2.verifyContains("/IE/"));

        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(name, "NoName"), ("No field to get a value of"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(id, "noID"), ("No field to get a value of"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(name, "txtNone"), ("No field to get a value of"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(name, "NoName"), (" Some Text"));

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(id, "txtReadOnly"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(name, "txtDisabled"), " Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(name, "missing_field"), "Some Text");

        ie.textField(name, "txtMultiLine1").append(" Some Text");
        assertEquals("Hello World Some Text", ie.textField(name, "txtMultiLine1").getContents());

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(id, "txtReadOnly"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(name, "txtDisabled"), " Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(name, "missing_field"), "Some Text");

        ie.textField(name, "txtMultiLine1").set("watir IE Controller");
        assertEquals("watir IE Controller", ie.textField(name, "txtMultiLine1").getContents());

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(id, "txtReadOnly"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(name, "txtDisabled"), " Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(name, "missing_field"), "Some Text");

        ie.textField(name, "txtMultiLine2").clear();
        assertEquals("", ie.textField(name, "txtMultiLine2").getContents());
    }
}
