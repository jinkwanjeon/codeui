package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.xpath;

public class CheckboxesXpathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "checkboxes1.html");
    }

    public void testCheckboxProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodId(ie.checkbox(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodName(ie.checkbox(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodDisabled(ie.checkbox(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodType(ie.checkbox(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodValue(ie.checkbox(xpath, "//INPUT[@name='noName']"));

        assertEquals("1", ie.checkbox(xpath, "//INPUT[@name='box4']").value());
        assertEquals("3", ie.checkbox(xpath, "//INPUT[@name='box4' and @value='3']").value());
        assertEquals("checkbox", ie.checkbox(xpath, "//INPUT[@name='box4' and @value='3']").type());
        assertEquals(false, ie.checkbox(xpath, "//INPUT[@name='box4' and @value='3']").disabled());
        assertEquals("", ie.checkbox(xpath, "//INPUT[@name='box4' and @value='3']").id());

        assertEquals("box4-value5", ie.checkbox(xpath, "//INPUT[@name='box4' and @value='5']").title());
        assertEquals("", ie.checkbox(xpath, "//INPUT[@name='box4' and @value='4']").title());
    }

    public void testCheckboxExists() throws Exception {
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='1']").exists());
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='22']").exists());
    }

    public void testCheckboxEnabled() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.checkbox(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.checkbox(xpath, "//INPUT[@id='noName']"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='6']"));

        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box1']").enabled());
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box2']").enabled());

        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='4']").enabled());
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='5']").enabled());
    }

    public void testCheckboxIsSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodIsSet(ie.checkbox(xpath, "//INPUT[@name='noName']"));

        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box1']").isSet());
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box2']").isSet());
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box3']").isSet());

        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='2']").isSet());
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='1']").isSet());
    }

    public void testCheckboxClear() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClear(ie.checkbox(xpath, "//INPUT[@name='noName']"));

        ie.checkbox(xpath, "//INPUT[@name='box1']").clear();
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box1']").isSet());

        assertRaisesDisabledObjectExceptionForMethodClear(ie.checkbox(xpath, "//INPUT[@name='box2']"));
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box2']").isSet());

        ie.checkbox(xpath, "//INPUT[@name='box3']").clear();
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box3']").isSet());

        ie.checkbox(xpath, "//INPUT[@name='box4' and @value='1']").clear();
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='1']").isSet());
    }

    public void testCheckboxGetState() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodIsSet(ie.checkbox(xpath, "//INPUT[@name='noName']"));

        assertEquals(false, ie.checkbox(xpath, "//INPUT[@name='box1']").getState());
        assertEquals(true, ie.checkbox(xpath, "//INPUT[@name='box3']").getState());

        // # checkboxes that have the same name but different values
        assertEquals(false, ie.checkbox(xpath, "//INPUT[@name='box4' and @value='2']").getState());
        assertEquals(true, ie.checkbox(xpath, "//INPUT[@name='box4' and @value='1']").getState());
    }

    public void testCheckboxSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodSet(ie.checkbox(xpath, "//INPUT[@name='noName']"));

        ie.checkbox(xpath, "//INPUT[@name='box1']").set();
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box1']").isSet());

        assertRaisesDisabledObjectExceptionForMethodSet(ie.checkbox(xpath, "//INPUT[@name='box2']"));

        ie.checkbox(xpath, "//INPUT[@name='box3']").set();
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box3']").isSet());

        // # checkboxes that have the same name but different values
        ie.checkbox(xpath, "//INPUT[@name='box4' and @value='3']").set();
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box4' and @value='3']")
                .isSet());

        // # test set using the optinal true/false
        // # assumes the checkbox is already checked
        ie.checkbox(xpath, "//INPUT[@name='box1']").set(false);
        assertFalse(ie.checkbox(xpath, "//INPUT[@name='box1']").isSet());

        ie.checkbox(xpath, "//INPUT[@name='box1']").set(true);
        assertTrue(ie.checkbox(xpath, "//INPUT[@name='box1']").isSet());

    }
}
