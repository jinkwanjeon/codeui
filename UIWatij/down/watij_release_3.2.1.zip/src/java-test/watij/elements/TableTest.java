package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;
import watij.runtime.UnknownObjectException;

public class TableTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "table1.html");
    }

    public void testTableExists() throws Exception {
        assertTrue(!ie.table(id, "missingTable").exists());
        assertTrue(!ie.table(32).exists());

        assertTrue(ie.table(id, "t1").exists());
        assertTrue(ie.table(id, "/t/").exists());
        assertTrue(!ie.table(id, "/missing_table/").exists());

        assertTrue(ie.table(0).exists());
        assertTrue(ie.table(1).exists());
    }

    public void testRows() throws Exception {
        try {
            ie.table(id, "missingTable").rowCount();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        try {
            ie.table(66).rowCount();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

        assertEquals(2, ie.table(0).rowCount());
        assertEquals(2, ie.table(0).rows().length());

        assertEquals(5, ie.table(id, "t1").rowCount());  //# 4 rows and a header
        assertEquals(5, ie.table(1).rowCount());  //# same table as above, just accessed by index;
        assertEquals(5, ie.table(id, "t1").rows().length());

        //# test the each iterator on rows - ie, go through each cell
        TableRow row = ie.table(1).row(1);
        int count = 0;
        for (TableCell cell : row.cells()) {
            //#  cell.flash   # this line commented out to speed up the test
            if (count == 0) {
                assertEquals("Row 1 Col1", cell.text().trim());
            } else if (count == 1) {
                assertEquals("Row 1 Col2", cell.text().trim());
            }
            count += 1;
        }
        assertEquals(2, count);
        assertEquals(2, ie.table(0).row(1).columnCount());
    }

    public void testDynamicTables() throws Exception {
        Table t = ie.table(id, "t1");
        assertEquals(5, t.rowCount());

        ie.button(value, "add row").click();
        assertEquals(5, t.rowCount()); //should stay same...need to refresh
        t = ie.table(id, "t1");
        assertEquals(6, t.rowCount()); //after refresh should get additional row
    }

    public void testColumns() throws Exception {
        try {
            ie.table(id, "missingTable").columnCount();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        try {
            ie.table(77).columnCount();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertEquals(2, ie.table(0).columnCount());
        assertEquals(1, ie.table(id, "t1").columnCount());  // # row one has 1 cell with a colspan of 2
    }
//
//      public void test_to_a
//        table1Expected = [ ["Row 1 Col1" , "Row 1 Col2"] ,[ "Row 2 Col1" , "Row 2 Col2"] ]
//        assertEquals(table1Expected, ie.table(index , 1).to_a )
//      }
//

    public void testLinksAndImagesInTable() throws Exception {
        Table table = ie.table(id, "pic_table");
        Image image = table.cell(0, 1).image(0);
        assertEquals(106, image.width());

        assertEquals(106, ie.cell(xpath, "//TABLE[@id='pic_table']//TR[1]/TD[2]").image(0).width());

        Link link = table.cell(0, 3).link(0);
        assertEquals("Google", link.innerText());
    }

    public void test_cell_directly() throws Exception {
        assertTrue(ie.cell(id, "cell1").exists());
        assertTrue(!ie.cell(id, "no_exist").exists());
        assertEquals("Row 1 Col1", ie.cell(id, "cell1").text().trim());

        // # not really cell directly, but just to show another way of geting the cell
        assertEquals("Row 1 Col1", ie.table(0).cell(0, 0).text().trim());
    }

    public void test_row_directly() throws Exception {
        assertTrue(ie.row(id, "row1").exists());
        assertTrue(!ie.row(id, "no_exist").exists());

        assertEquals("Row 2 Col1", ie.row(id, "row1").cell(0).text().trim());
    }

    public void test_row_iterator() throws Exception {
        Table t = ie.table(0);
        int count = 0;
        for (TableRow row : t.rows()) {
            if (count == 0) {
                assertEquals("Row 1 Col1", row.cell(0).text().trim());
                assertEquals("Row 1 Col2", row.cell(1).text().trim());
            } else if (count == 1) {
                assertEquals("Row 2 Col1", row.cell(0).text().trim());
                assertEquals("Row 2 Col2", row.cell(1).text().trim());
            }
            count += 1;
        }
    }

    public void test_cell_collection() throws Exception {
        Table t = ie.table(0);
        int count = 0;

        for (TableCell c : t.cells()) {
            if (count == 0) {
                assertEquals("Row 1 Col1", c.text().trim());
            } else if (count == 1) {
                assertEquals("Row 1 Col2", c.text().trim());
            } else if (count == 2) {
                assertEquals("Row 2 Col1", c.text().trim());
            } else if (count == 3) {
                assertEquals("Row 2 Col2", c.text().trim());
            }
            count++;
        }
    }

    public void test_table_body() throws Exception {
        assertEquals(1, ie.table(0).bodies().length());
        assertEquals(3, ie.table(id, "body_test").bodies().length());

        int count = 0;
        String compareText = null;
        for (TableBody n : ie.table(id, "body_test").bodies()) {

            // # do something better here!
            // # n.flash # this line commented out to speed up the test

            if (count == 0) {
                compareText = "This text is in the FRST TBODY.";
            } else if (count == 1) {
                compareText = "This text is in the SECOND TBODY.";
            } else if (count == 2) {
                compareText = "This text is in the THIRD TBODY.";
            }

            assertEquals(compareText, n.cell(0, 0).text().trim());  // # this is the 1st cell of the first row of this particular body;

            count += 1;
        }
        assertEquals(count, ie.table(id, "body_test").bodies().length());

        assertEquals("This text is in the THIRD TBODY.", ie.table(id, "body_test").body(2).cell(0, 0).text().trim());

        //  # iterate through all the rows in a table body
        count = 0;
        for (TableRow row : ie.table(id, "body_test").body(1).rows()) {
            //  # row.flash    # this line commented out, to speed up the tests
            if (count == 0) {
                assertEquals("This text is in the SECOND TBODY.", row.cell(0).text().trim());
            } else if (count == 1) {
                assertEquals("This text is also in the SECOND TBODY.", row.cell(0).text().trim());
            }
            count += 1;
        }
    }

     public void testTableHead() throws Exception {
        assertEquals("This text is in the TH. ",ie.table(id,"th_test").rows().get(0).cell(0).innerText());
     }

//        ie.goto(htmlRoot + "simple_table.html")
//      }
//

    public void test_simple_table_access() throws Exception {
        ie.goTo(HTML_ROOT + "simple_table.html");
        Table table = ie.table(0);

        assertEquals("Row 3 Col1", table.cell(2, 0).text().trim());
        assertEquals("Row 1 Col1", table.cell(0, 0).text().trim());
        assertEquals("Row 3 Col2", table.cell(2, 1).text().trim());
        assertEquals(2, table.columnCount());
    }
//    }
//    class TC_Tables_Buttons < TestUnitTestCase
//      include Watir
//
//      public void setup
//        ie.goto(htmlRoot + "simple_table_buttons.html")
//      }
//

    public void test_simple_table_buttons() throws Exception {
        ie.goTo(HTML_ROOT + "simple_table_buttons.html");
        Table table = ie.table(0);

        table.cell(0, 0).button(0).click();
        assertTrue(ie.textField(name, "confirmtext").verifyContains("/CLICK1/"));
        table.cell(1, 0).button(0).click();
        assertTrue(ie.textField(name, "confirmtext").verifyContains("/CLICK2/"));

        table.cell(0, 0).button(id, "b1").click();
        assertTrue(ie.textField(name, "confirmtext").verifyContains("/CLICK1/"));

        try {
            table.cell(0, 0).button(id, "b_missing").click();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

        table.cell(2, 0).button(1).click();
        assertTrue(ie.textField(name, "confirmtext").verifyContains("/TOO/"));

        table.cell(2, 0).button(value, "Click too").click();
        assertTrue(ie.textField(name, "confirmtext").verifyContains("/TOO/"));

        ie.table(0).cell(3, 0).textField(0).set("123");
        assertTrue(ie.textField(1).verifyContains("123"));

        //# check when a cell contains 2 objects

        //# if there were 2 different html objects in the same cell, some weird things happened ( button caption could change for example)
        assertEquals("Click ->", ie.table(0).cell(4, 0).textField(0).value());
        ie.table(0).cell(4, 0).textField(0).click();
        assertEquals("Click ->", ie.table(0).cell(4, 0).textField(0).value());

        ie.table(0).cell(4, 0).button(0).click();
        assertEquals("", ie.table(0).cell(4, 0).textField(0).value());
    }

    public void test_simple_table_gif() throws Exception {
        ie.goTo(HTML_ROOT + "simple_table_buttons.html");
        Table table = ie.table(1);

        assertMatches("/1.gif/", table.cell(0, 0).image(0).src());
        assertMatches("/2.gif/", table.cell(0, 1).image(0).src());
        assertMatches("/3.gif/", table.cell(0, 2).image(0).src());

        assertMatches("/1.gif/", table.cell(2, 0).image(0).src());
        assertMatches("/2.gif/", table.cell(2, 1).image(0).src());
        assertMatches("/3.gif/", table.cell(2, 2).image(0).src());

        table = ie.table(2);
        assertMatches("/1.gif/", table.cell(0, 0).image(0).src());
        assertMatches("/2.gif/", table.cell(0, 0).image(1).src());
        assertMatches("/3.gif/", table.cell(0, 0).image(2).src());

        assertMatches("/1.gif/", table.cell(2, 0).image(0).src());
        assertMatches("/2.gif/", table.cell(2, 0).image(1).src());
        assertMatches("/3.gif/", table.cell(2, 0).image(2).src());
    }


    public void test_table_with_hidden_or_visible_rows() throws Exception {
        ie.goTo(HTML_ROOT + "simple_table_buttons.html");
        ie.bringToFront();
        Table t = ie.table(id, "show_hide");

        //# expand the table
        for (TableRow r : t.rows()) {
            Image image = r.cell(0).image(src, "/plus/");
            if (image.exists()) {
                image.click();
            }
        }

        //# shrink rows 1,2,3
        for (TableRow r : t.rows()) {
            Image image = r.cell(0).image(src, "/minus/");
            if (image.exists()) {
                image.click();
            }
        }
    }

    //! support this later - finding parent table
//      public void test_table_from_element() throws Exception {
//        ie.goTo(HTML_ROOT + "simple_table_buttons.html");
//          Button button = ie.button(id, "b1");
//        Table table = Table.create_from_element(ie, button)
//
//        table[2][1].button(1).click
//        assertTrue(ie.textField(name, "confirmtext").verifyContains(/CLICK2/i))
//      }
//    }

    //! support this later...may do this differently
//      public void test_get_columnvalues_single_column() throws Exception {
//        ie.goTo(HTML_ROOT + "simple_table_columns.html");
//        assertEquals(new String[]{"R1C1", "R2C1", "R3C1"}, ie.table(0).columnValues(0));
//      }

    //

    public void test_colspan() throws Exception {
        ie.goTo(HTML_ROOT + "simple_table_columns.html");
        assertEquals(2, ie.table(2).cell(1, 0).colspan());
        assertEquals(1, ie.table(2).cell(0, 0).colspan());
        assertEquals(3, ie.table(2).cell(3, 0).colspan());
    }

    //! support this later...may do this differently
//      public void test_get_columnvalues_multiple_column
//        assertEquals(["R1C1", "R2C1", "R3C1"], ie.table(2).column_values(1))
//        assertEquals(["R1C3", "R2C3", "R3C3"], ie.table(2).column_values(3))
//      }

    //! support this later...may do this differently
//      public void test_get_columnvalues_with_colspan
//        assertEquals(["R1C1", "R2C1", "R3C1", "R4C1", "R5C1", "R6C2"], ie.table(3).column_values(1))
//       (2..4).each{|x|assert_raises(UnknownCellException){ie.table(3).column_values(x)}}
//      }

    //! support this later...may do this differently
//      public void test_get_rowvalues_full_row
//        assertEquals(["R1C1", "R1C2", "R1C3"], ie.table(3).row_values(1))
//      }

    //! support this later...may do this differently
//      public void test_get_rowvalues_with_colspan
//        assertEquals(["R2C1", "R2C2"], ie.table(3).row_values(2))
//      }

    //! support this later...may do this differently
//      public void test_getrowvalues_with_rowspan
//        assertEquals(["R5C1", "R5C2", "R5C3"], ie.table(3).row_values(5))
//        assertEquals(["R6C2", "R6C3"], ie.table(3).row_values(6))
//      }
//    }
//

    public void test_complex_table_access() throws Exception {
        ie.goTo(HTML_ROOT + "complex_table.html");
        Table table = ie.table(0);

        assertEquals("subtable1 Row 1 Col1", table.cell(0, 0).table(0).cell(0, 0).text().trim());
        assertEquals("subtable1 Row 1 Col2", table.cell(0, 0).table(0).cell(0, 1).text().trim());
        assertEquals("subtable2 Row 1 Col2", table.cell(1, 0).table(0).cell(0, 1).text().trim());
        assertEquals("subtable2 Row 1 Col1", table.cell(1, 0).table(0).cell(0, 0).text().trim());
    }

//    public void testUpload() throws Exception {
//        ie.goTo("http://web23.viux.com/CFX_ImageInfoMX/uploadtest.cfm");
//        ie.fileField(name, "filename").set("C:/wow.png");
//    }

}
