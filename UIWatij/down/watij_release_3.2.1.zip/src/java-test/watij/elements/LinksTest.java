package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;
import watij.utilities.StringUtils;
import watij.utilities.Utils;


/**
 * Created by IntelliJ IDEA.
 * <p/>
 * Date Apr 20, 2006
 * Time 62947 PM
 * To change this template use File | Settings | File Templates.
 */
public class LinksTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "links1.html");
    }

    public void testNewLinkExists() throws Exception {
        assertTrue(ie.link(text, "test1").exists());
        assertTrue(ie.link(text, "/(?i:TEST)/").exists());
    }

    //!?  Cannot reproduce this test in Java - no variants
//        public void test_bad_attribute
//            assert_raises(MissingWayOfFindingObjectException) { ie.link(bad_attribute, 199).click }
//            begin
//                ie.link(bad_attribute, 199).click
//            rescue MissingWayOfFindingObjectException => e
//                assertEquals "bad_attribute is an unknown way of finding a <A> element (199)", e.to_s
//            }
//        }

    public void testMissingLinksDontExist() throws Exception {
        assertFalse(ie.link(text, "missing").exists());
        assertFalse(ie.link(text, "/miss/").exists());
    }

    public void testLinkExists() throws Exception {
        assertTrue(ie.link(text, "test1").exists());
        assertTrue(ie.link(text, "/(?i:TEST)/").exists());
        assertFalse(ie.link(text, "missing").exists());
        assertFalse(ie.link(text, "/miss/").exists());

//            # this assert we have to build up the path
//            #  this is what it looks like if you do a to_s on the link  file///C/watir_bonus/unitTests/html/links1.HTML
//            # but what we get back from $htmlRoot is a mixed case, so its almost impossible for use to test this correctly
//            # assertTrue(ie.link(url,'file///C/watir_bonus/unitTests/html/links1.HTML' ).exists())

        assertTrue(ie.link(url, "/link_pass.html/").exists());
        assertFalse(ie.link(url, "alsomissing.html").exists());

        assertTrue(ie.link(id, "link_id").exists());
        assertFalse(ie.link(id, "alsomissing").exists());

        assertTrue(ie.link(id, "/_id/").exists());
        assertFalse(ie.link(id, "/ alsomissing /").exists());

        assertTrue(ie.link(name, "link_name").exists());
        assertFalse(ie.link(name, "alsomissing").exists());

        assertTrue(ie.link(name, "/_n/").exists());
        assertFalse(ie.link(name, "/missing/").exists());

        assertTrue(ie.link(title, "/ti/").exists());
        assertTrue(ie.link(title, "link_title").exists());

        assertFalse(ie.link(title, "/missing/").exists());

        assertTrue(ie.link(url, "/_pass/").exists());
        assertFalse(ie.link(url, "/dont_exist/").exists());
    }

    public void testLinkClick() throws Exception {
        ie.link(text, "test1").click();
        assertTrue(ie.text().contains("Links2-Pass"));
    }

    public void testLink2Click() throws Exception {
        ie.link(url, "/link_pass.html/").click();
        assertTrue(ie.text().contains("Links3-Pass"));
    }

    public void testLink3Click() throws Exception {
        ie.link(0).click();
        assertTrue(ie.text().contains("Links2-Pass"));
    }

    public void testLink4Click() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClick(ie.link(199));
    }

    public void test_link_properties() throws Exception {
        //    assert_raises(UnknownObjectException  , "UnknownObjectException  was supposed to be thrown" ) {   ie.link(199).href }
        assertRaisesUnknownObjectExceptionForMethodValue(ie.link(199));
        assertRaisesUnknownObjectExceptionForMethodInnerText(ie.link(199));
        assertRaisesUnknownObjectExceptionForMethodName(ie.link(199));
        assertRaisesUnknownObjectExceptionForMethodId(ie.link(199));
        assertRaisesUnknownObjectExceptionForMethodDisabled(ie.link(199));
        assertRaisesUnknownObjectExceptionForMethodType(ie.link(199));
        //   assertRaisesUnknownObjectExceptionForMethodClassName();

        assertTrue(StringUtils.matchesOrEquals("/links2/", ie.link(0).href()));

        assertTrue(Utils.isEmpty(ie.link(0).value()));
        assertEquals("test1", ie.link(0).innerText());
        assertEquals("", ie.link(0).name());
        assertEquals("", ie.link(0).id());
        assertEquals(false, ie.link(0).disabled());
        assertEquals("", ie.link(0).className());
        assertEquals("link_class_1", ie.link(1).className());

        assertEquals("link_id", ie.link(5).id());
        assertEquals("link_name", ie.link(6).name());

        assertEquals("", ie.link(6).title());

        assertEquals("link_title", ie.link(7).title());
    }

    public void test_link_iterator() throws Exception {
        assertEquals(9, ie.links().length());
        assertEquals("Link Using a name", ie.links().get(6).innerText());

        int i = 0;
        for (Link link : ie.links()) {
            assertEquals(ie.link(i).href(), link.href());
            assertEquals(ie.link(i).id(), link.id());
            assertEquals(ie.link(i).name(), link.name());
            assertEquals(ie.link(i).innerText(), link.innerText());
            i += 1;
        }
    }

//    def test_div_xml_bug
//           $ie.goto($htmlRoot + "div_xml.html")
//           assert_nothing_raised {$ie.link(:text, 'Create').exists? }
//       end
//
//
//    class TC_Frame_Links < TestUnitTestCase
//        include Watir
//
//        public void setup()
//            ie.goto($htmlRoot + "frame_links.html")
//        }
//
//        public void test_new_frame_link_exists
//            assert(exists(){ie.frame("buttonFrame").link(text, "test1")})
//        }
//        public void xtest_missing_frame_links_dont_exist
//            assertFalse(exists(){ie.frame("buttonFrame").link(text, "missing")})
//            assertFalse(exists(){ie.frame("missing").link(text, "test1")})
//        }
//
//        public void test_links_in_frames
//            assert(ie.frame("buttonFrame").link(text, "test1").exists())
//            assertFalse(ie.frame("buttonFrame").link(text, "missing").exists())
//
//            assert_raises(UnknownObjectException, "UnknownObjectException  was supposed to be thrown" ) { ie.frame("buttonFrame").link(199).href }
//            assert_match(/links2/, ie.frame("buttonFrame").link(0).href)
//
//            count =0
//            ie.frame("buttonFrame").links.each do |l|
//                count+=1
//            }
//
//            assertEquals( 9 , count)
//        }
//    }
//
//    require 'unittests/iostring'
//    class TC_showlinks < TestUnitTestCase
//        include MockStdoutTestCase
//
//        public void test_showLinks
//            ie.goto($htmlRoot + "links1.html")
//            $stdout = @mockout
//            ie.showLinks
//            expected = [/^index name +id +href + text\/src$/,
//                get_path_regex(1, "links2.html","test1"),
//                get_path_regex(2, "link_pass.html","test1"),
//                get_path_regex(3, "pass3.html", " / file///#{$myDir.downcase}/html/images/button.jpg"),
//                get_path_regex(4, "textarea.html", "new window"),
//                get_path_regex(5, "textarea.html", "new window"),
//                get_path_regex(6, "links1.html", "link using an id", "link_id"),
//                get_path_regex(7, "links1.html", "link using a name", "link_name"),
//                get_path_regex(8, "links1.html", "link using a title"),
//                get_path_regex(9, "pass.html", "image and a text link / file///#{$myDir.downcase}/html/images/triangle.jpg")]
//            items = @mockout.split(/\n/).collect {|s|s.downcase.strip}
//            expected.each_with_index{|regex, x| assert_match(regex, items[x])}
//        }
//
//        public void get_path_regex(idx, name, inner, nameid="")
//            Regexp.new("^#{idx} +#{nameid} +file///#{$myDir.downcase}/html/#{name} *#{inner}$")
//        }


}
