package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.xpath;

public class TextAreaFieldsXpathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textArea.html");
    }


    public void testTextareaFieldExists() throws Exception {
        //#test for existance of 4 text area
        assertTrue(ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']").exists());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine2']").exists());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine3']").exists());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@name='txtReadOnly']").exists());

        assertTrue(ie.textField(xpath, "//TEXTAREA[@id='txtMultiLine1']").exists());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@id='txtMultiLine2']").exists());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@id='txtMultiLine3']").exists());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@id='txtReadOnly']").exists());
        //#test for missing 
        assertFalse(ie.textField(xpath, "//TEXTAREA[@name='missing']").exists());
        assertFalse(ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine4']").exists());
    }

//    public void testtextarea_to_s
//        # bug reported by Zeljko Filipin
//        # assert_nothing_raised() { ie.textField(xpath , "//TEXTAREA[@id='txtMultiLine3']").to_s  }
//        # The above assertion fails. No property or method called maxlength
//    end

    public void testTextareaField() throws Exception {
        //# test for read only method
        assertFalse(ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']").readOnly());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@name='txtReadOnly']").readOnly());

        //# test for enabled? method
        assertFalse(ie.textField(xpath, "//TEXTAREA[@name='txtDisabled']").enabled());
        assertTrue(ie.textField(xpath, "//TEXTAREA[@id='txtMultiLine1']").enabled());


        TextField t1 = ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']");
        assertTrue(t1.verifyContains("Hello World"));
        assertTrue(t1.verifyContains("/el/"));
        TextField t2 = ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine2']");
        assertTrue(t2.verifyContains("/IE/"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(xpath, "//TEXTAREA[@name='NoName']"), "No field to get value of");
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(xpath, "//TEXTAREA[@id='noID']"), "No field to get value of");

        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='txtNone']"), "Some Text");

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@id='txtReadOnly']"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='txtDisabled']"), "Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='missing_field']"), "Some Text");

        ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']").append(" Some Text");
        assertEquals("Hello World Some Text", ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']").value());

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@id='txtReadOnly']"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='txtDisabled']"), "Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='missing_field']"), "Some Text");

        ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']").set("watir IE Controller");
        assertEquals("watir IE Controller", ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine1']").value());

        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@id='txtReadOnly']"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='txtDisabled']"), "Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(xpath, "//TEXTAREA[@name='missing_field']"), "Some Text");

        ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine2']").clear();
        assertEquals("", ie.textField(xpath, "//TEXTAREA[@name='txtMultiLine2']").value());

    }
}

