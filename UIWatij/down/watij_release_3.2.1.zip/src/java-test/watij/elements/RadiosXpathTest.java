package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.xpath;

public class RadiosXpathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "radioButtons1.html");
    }

    public void testRadioExists() throws Exception {
        assertTrue(ie.radio(xpath, "//INPUT[@name='box1']").exists());
        assertTrue(ie.radio(xpath, "//INPUT[@id='box5']").exists());

        assertFalse(ie.radio(xpath, "//INPUT[@name='missingname']").exists());
        assertFalse(ie.radio(xpath, "//INPUT[@id='missingid']").exists());
    }

    public void testRadio_Enabled() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.radio(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.radio(xpath, "//INPUT[@id='noName']"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.radio(xpath, "//INPUT[@name='box4' and @value='6']"));

        assertFalse(ie.radio(xpath, "//INPUT[@name='box2']").enabled());
        assertTrue(ie.radio(xpath, "//INPUT[@id='box5']").enabled());
        assertTrue(ie.radio(xpath, "//INPUT[@name='box1']").enabled());
    }

    public void testLittle() throws Exception {
        assertFalse(ie.button(xpath, "//INPUT[@name='foo']").enabled());
    }

    public void testOnClick() throws Exception {
        assertFalse(ie.button(xpath, "//INPUT[@name='foo']").enabled());
        ie.radio(xpath, "//INPUT[@name='box5' and @value='1']").set();
        assertTrue(ie.button(xpath, "//INPUT[@name='foo']").enabled());

        ie.radio(xpath, "//INPUT[@name='box5' and @value='2']").set();
        assertFalse(ie.button(xpath, "//INPUT[@name='foo']").enabled());
    }

    public void testRadioIsSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodIsSet(ie.radio(xpath, "//INPUT[@name='noName']"));

        assertFalse(ie.radio(xpath, "//INPUT[@name='box1']").isSet());

        assertTrue(ie.radio(xpath, "//INPUT[@name='box3']").isSet());
        assertFalse(ie.radio(xpath, "//INPUT[@name='box2']").isSet());

        assertTrue(ie.radio(xpath, "//INPUT[@name='box4' and @value='1']").isSet());
        assertFalse(ie.radio(xpath, "//INPUT[@name='box4' and @value='2']").isSet());
    }

    public void testRadioClear() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClear(ie.radio(xpath, "//INPUT[@name='noName']"));

        ie.radio(xpath, "//INPUT[@name='box1']").clear();
        assertFalse(ie.radio(xpath, "//INPUT[@name='box1']").isSet());

        assertRaisesDisabledObjectExceptionForMethodClear(ie.radio(xpath, "//INPUT[@name='box2']"));
        assertFalse(ie.radio(xpath, "//INPUT[@name='box2']").isSet());

        ie.radio(xpath, "//INPUT[@name='box3']").clear();
        assertFalse(ie.radio(xpath, "//INPUT[@name='box3']").isSet());

        ie.radio(xpath, "//INPUT[@name='box4' and @value='1']").clear();
        assertFalse(ie.radio(xpath, "//INPUT[@name='box4' and @value='1']").isSet());
    }

    public void testRadioGetState() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodGetState(ie.radio(xpath, "//INPUT[@name='noName']"));

        assertEquals(false, ie.radio(xpath, "//INPUT[@name='box1']").getState());
        assertEquals(true, ie.radio(xpath, "//INPUT[@name='box3']").getState());

        //# radioes that have the same name but different values
        assertEquals(false, ie.radio(xpath, "//INPUT[@name='box4' and @value='2']").getState());
        assertEquals(true, ie.radio(xpath, "//INPUT[@name='box4' and @value='1']").getState());
    }

    public void testRadioSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodSet(ie.radio(xpath, "//INPUT[@name='noName']"));
        ie.radio(xpath, "//INPUT[@name='box1']").set();
        assertTrue(ie.radio(xpath, "//INPUT[@name='box1']").isSet());

        assertRaisesDisabledObjectExceptionForMethodSet(ie.radio(xpath, "//INPUT[@name='box2']"));

        ie.radio(xpath, "//INPUT[@name='box3']").set();
        assertTrue(ie.radio(xpath, "//INPUT[@name='box3']").isSet());

        //# radioes that have the same name but different values
        ie.radio(xpath, "//INPUT[@name='box4' and @value='3']").set();
        assertTrue(ie.radio(xpath, "//INPUT[@name='box4' and @value='3']").isSet());
    }
}