package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;

public class FormsXPathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "forms2.html");
    }

    public void testFormExists() throws Exception {
        assertTrue(ie.form(xpath, "//FORM[@name='test2']").exists());
        assertFalse(ie.form(xpath, "//FORM[@name='missing']").exists());

        assertTrue(ie.form(xpath, "//FORM[@method='get']").exists());
        assertFalse(ie.form(xpath, "//FORM[@method='missing']").exists());

        assertTrue(ie.form(xpath, "//FORM[@action='pass.html']").exists());
        assertFalse(ie.form(xpath, "//FORM[@action='missing']").exists());
    }

    public void testButtonInForm() throws Exception {
        assertTrue(ie.form(xpath, "//FORM[@name='test2']").button(caption, "Submit").exists());
    }

    public void testForm3Exists() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        assertTrue(ie.form(xpath, "//FORM[@name='test2']").exists());
        assertFalse(ie.form(xpath, "//FORM[@name='missing']").exists());

        assertTrue(ie.form(xpath, "//FORM[@method='get']").exists());
        assertFalse(ie.form(xpath, "//FORM[@method='missing']").exists());

        assertTrue(ie.form(xpath, "//FORM[@action='pass.html']").exists());
        assertFalse(ie.form(xpath, "//FORM[@action='missing']").exists());
    }

    public void testflash1() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");
        ie.form(xpath, "//FORM[@name='test2']").button(caption, "Submit").flash();
    }

    public void testcorrectformfieldisfoundusingformname() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        assertEquals(ie.form(xpath, "//FORM[@name='apple_form']").textField(name, "name").value(), "apple");
        assertEquals(ie.form(xpath, "//FORM[@name='banana_form']").textField(name, "name").value(), "banana");
    }

    public void testusingtextonform() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        ie.form(xpath, "//FORM[@name='apple_form']").textField(name, "name").set("strudel");
        assertEquals(ie.form(0).textField(name, "name").value(), "strudel");
    }

    public void testsubmit() throws Exception {
        ie.goTo(HTML_ROOT + "forms4.html");
        ie.form(xpath, "//FORM[@name='apple_form']").submit();
        assertTrue(ie.containsText("PASS"));
    }

    public void testhidden() throws Exception {
        ie.goTo(HTML_ROOT + "forms3.html");

        assertTrue(ie.form(xpath, "//FORM[@name='has_a_hidden']").hidden(name, "hid1").exists());
        assertTrue(ie.form(xpath, "//FORM[@name='has_a_hidden']").hidden(id, "hidden_1").exists());
        assertFalse(ie.form(xpath, "//FORM[@name='has_a_hidden']").hidden(name, "hidden_44").exists());
        assertFalse(ie.form(xpath, "//FORM[@name='has_a_hidden']").hidden(id, "hidden_55").exists());

        ie.form(xpath, "//FORM[@name='has_a_hidden']").hidden(name, "hid1").set("222");
        ie.form(xpath, "//FORM[@name='has_a_hidden']").hidden(id, "hidden_1").set("333");

        ie.button(value, "Show Hidden").click();

        assertEquals("222", ie.textField(name, "vis1").value());
        assertEquals("333", ie.textField(name, "vis2").value());

    }
}
