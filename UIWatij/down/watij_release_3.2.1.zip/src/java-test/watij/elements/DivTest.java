package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;

public class DivTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "div.html");
    }

    public void testDivs() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClick(ie.div(id, "div77"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.div(title, "div77"));

        assertTrue(ie.textField(name, "text1").verifyContains("0"));
        ie.div(id, "div3").click();
        assertTrue(ie.textField(name, "text1").verifyContains("1"));
        ie.div(id, "div4").click();
        assertTrue(ie.textField(name, "text1").verifyContains("0"));
    }

    public void testDivProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodText(ie.div(id, "div77"));
        assertRaisesUnknownObjectExceptionForMethodText(ie.div(title, "div77"));

        assertEquals("This div has an onClick that increments text1",
                ie.div(id, "div3").text().trim());
        assertEquals("This text is in a div with an id of div1 and title of test1",
                ie.div(title, "Test1").text().trim());

        assertRaisesUnknownObjectExceptionForMethodClassName(ie.div(id, "div77"));
        assertEquals("blueText", ie.div(id, "div2").className());
        assertEquals("", ie.div(id, "div1").className());

        assertRaisesUnknownObjectExceptionForMethodClassName(ie.div(44));
        assertEquals("div1", ie.div(0).id());
        assertEquals("", ie.div(0).className());
        assertEquals("blueText", ie.div(1).className());
        assertEquals("", ie.div(1).value());
        assertEquals(false, ie.div(1).disabled());
        //assertEquals(null, ie.div(index , 2).name());
        assertEquals("div2", ie.div(1).id());
    }

    public void testDivIterator() throws Exception {
        assertEquals(7, ie.divs().length());
        assertEquals("div1", ie.divs().get(0).id());

        int j = 0;
        Divs divs = ie.divs();
        for (Div div : divs) {
            //assertEquals(ie.div(j).name(), div.name());
            assertEquals(ie.div(j).id(), div.id());
            assertEquals(ie.div(j).className(), div.className());
            j++;
        }
        assertEquals(j, ie.divs().length());
    }

    public void test_objects_in_div() throws Exception {
        assertTrue(ie.div(id, "buttons1").button(0).exists());
        assertFalse(ie.div(id, "buttons1").button(2).exists());
        assertTrue(ie.div(id, "buttons1").button(name, "b1").exists());

        assertTrue(ie.div(id, "buttons2").button(0).exists());
        assertTrue(ie.div(id, "buttons2").button(1).exists());
        assertFalse(ie.div(id, "buttons1").button(2).exists());

        ie.div(id, "buttons1").button(0).click();

        assertEquals("button1", ie.div(id, "text_fields1").textField(0).value());

        assertEquals(3, ie.div(id, "text_fields1").textFields().length());
    }

//	    #---- Span Tests ---

    public void testSpans() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClick(ie.span(id, "span77"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.span(title, "span77"));

        assertTrue(ie.textField(name, "text2").verifyContains("0"));
        ie.span(id, "span3").click();
        assertTrue(ie.textField(name, "text2").verifyContains("1"));
        ie.span(id, "span4").click();
        assertTrue(ie.textField(name, "text2").verifyContains("0"));
    }

    public void testSpanProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodText(ie.span(id, "span77"));
        assertRaisesUnknownObjectExceptionForMethodText(ie.span(title, "span77"));

        assertEquals("This span has an onClick that increments text2",
                ie.span(id, "span3").text().trim());
        assertEquals("This text is in a span with an id of span1 and title of test2",
                ie.span(title, "Test2").text().trim());

        assertRaisesUnknownObjectExceptionForMethodClassName(ie.span(id, "span77"));
        assertEquals("blueText", ie.span(id, "span2").className());
        assertEquals("", ie.span(id, "span1").className());

        assertRaisesUnknownObjectExceptionForMethodClassName(ie.span(44));
        assertEquals("span1", ie.span(0).id());
        assertEquals("", ie.span(0).className());
        assertEquals("blueText", ie.span(1).className());
        assertEquals("", ie.span(1).value());
        assertEquals(false, ie.span(1).disabled());
        //assertEquals(null, ie.span(index , 2).name());
        assertEquals("span2", ie.span(1).id());
    }

    public void testSpanIterator() throws Exception {
        assertEquals(7, ie.spans().length());
        assertEquals("span1", ie.spans().get(0).id());

        int j = 0;
        Spans spans = ie.spans();
        for (Span span : spans) {
            //assertEquals(ie.span(j).name(), span.name());
            assertEquals(ie.span(j).id(), span.id());
            assertEquals(ie.span(j).className(), span.className());
            j++;
        }
        assertEquals(j, ie.spans().length());
    }


    public void test_objects_in_span() throws Exception {
        assertTrue(ie.span(id, "buttons1").button(0).exists());
        assertFalse(ie.span(id, "buttons1").button(2).exists());
        assertTrue(ie.span(id, "buttons1").button(name, "b1").exists());

        assertTrue(ie.span(id, "buttons2").button(0).exists());
        assertTrue(ie.span(id, "buttons2").button(1).exists());
        assertFalse(ie.span(id, "buttons1").button(2).exists());

        ie.span(id, "buttons1").button(0).click();

        assertEquals("button1", ie.span(id, "text_fields1").textField(0).value());

        assertEquals(3, ie.span(id, "text_fields1").textFields().length());
    }
//	    
//	    def test_p
//	        assert(ie.p(id, 'number1').exists())
//	        assert(ie.p(:2).exists())
//	        assert(ie.p(:title, 'test_3').exists())
//	        
//	        assertFalse(ie.p(id, 'missing').exists())
//	        assertFalse(ie.p(:8).exists())
//	        assertFalse(ie.p(:title, 'test_55').exists())
//	        
//	        assert_raises( UnknownObjectException) {ie.p(id , 'missing').class_name }
//	        assert_raises( UnknownObjectException) {ie.p(id , 'missing').text }
//	        assert_raises( UnknownObjectException) {ie.p(id , 'missing').title }
//	        assert_raises( UnknownObjectException) {ie.p(id , 'missing').to_s }
//	        assert_raises( UnknownObjectException) {ie.p(id , 'missing').disabled }
//	        
//	        assertEquals(  'redText' , ie.p(:index,1).class_name)
//	        assertEquals(  'P_tag_1' , ie.p(:index,1).title)
//	        assertEquals(  'This text is in a p with an id of number2' , ie.p(:index,2).text)
//	    end
//	    
//	    def test_p_iterator
//	        assertEquals( 3, ie.ps.length)
//	        assertEquals( 'italicText', ie.ps[2].class_name)
//	        assertEquals( 'number3', ie.ps[3].id)
//	        
//	        count=1
//	        ie.ps.each do |p|
//	            assertEquals('number'+count.to_s , p.id)
//	            count+=1
//	        end
//	        assertEquals( count-1 ,  ie.ps.length)
//	    end
//	end

}
