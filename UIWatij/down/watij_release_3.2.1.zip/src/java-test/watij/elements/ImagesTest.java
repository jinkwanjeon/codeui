package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;

public class ImagesTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "images1.html");
    }

    // public void setup
    // ie.goto(htmlRoot + "images1.html")
    // @saved_img_path = build_path("sample.img.dat");
    // clean_saved_image
    // }
    //
    // public void teardown
    // clean_saved_image
    // }
    //

    public void testImageExists() throws Exception {
        assertTrue(!ie.image(name, "missing_name").exists());
        assertTrue(ie.image(name, "circle").exists());
        assertTrue(ie.image(name, "/circ/").exists());

        assertTrue(!ie.image(id, "missing_id").exists());
        assertTrue(ie.image(id, "square").exists());
        assertTrue(ie.image(id, "/squ/").exists());

        assertTrue(!ie.image(src, "missingsrc.gif").exists());

        // assertTrue(ie.image(src,
        // "file///#{myDir}/html/images/triangle.jpg").exists());
        assertTrue(ie.image(src, "/triangle/").exists());

        assertTrue(ie.image(alt, "circle").exists());
        assertTrue(ie.image(alt, "/cir/").exists());

        assertTrue(!ie.image(alt, "triangle").exists());
        assertTrue(!ie.image(alt, "/tri/").exists());

        assertTrue(ie.image(title, "square_image").exists());
        assertTrue(!ie.image(title, "pentagram").exists());
    }

    public void testImageClick() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClick(ie.image(name, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.image(id, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.image(src, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.image(alt, "no_image_with_this"));

        // # test for bug 1882
        ie.textField(name, "text1").clear();
        ie.button(value, "/Pos/").click();
        assertEquals("clicked", ie.textField(name, "text1").value());
        // # test for disabled button
        assertTrue(!ie.image(name, "disabler_test").disabled());
        ie.button(name, "disable_img").click();

        assertTrue(ie.image(name, "disabler_test").disabled());
        ie.button(name, "disable_img").click();

        ie.image(src, "/button/").click();
        assertTrue(ie.text().contains("PASS"));
    }

    public void testImageHasLoaded() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(name, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(id, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(src, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(alt, "no_image_with_this"));

        assertFalse(ie.image(name, "themissingimage").hasLoaded());
        assertTrue(ie.image(name, "circle").hasLoaded());

        assertTrue(ie.image(alt, "circle").hasLoaded());
        assertTrue(ie.image(alt, "/cir/").hasLoaded());
    }

    public void testImageProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(name, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(id, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(src, "no_image_with_this"));
        assertRaisesUnknownObjectExceptionForMethodHasLoaded(ie.image(82));

        assertRaisesUnknownObjectExceptionForMethodName(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodId(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodSrc(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodValue(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodHeight(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodWidth(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodFileCreatedDate(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodFileSize(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodAlt(ie.image(82));
        assertRaisesUnknownObjectExceptionForMethodTitle(ie.image(82));

        assertEquals("", ie.image(1).name());
        assertEquals("square", ie.image(1).id());
        assertTrue(ie.image(1).src().contains("square"));
        assertEquals("", ie.image(1).value());
        assertEquals(88, ie.image(1).height());
        assertEquals(88, ie.image(1).width());

        // # this line fails, as the date is when it is installed on the local
        // oc, not the date the file was really created
        // #assert_equal( "03/10/2005" , ie.image(1).fileCreatedDate )
        assertEquals(788, ie.image(1).fileSize());
        // # tool tips alt text + title
        assertEquals("circle", ie.image(5).alt());
        assertEquals("", ie.image(1).alt());
        assertEquals("square_image", ie.image(id, "square").title());
        //
        // //# TODO to string tests -- output should be verified!
        // ie.image(name , "circle").to_s
        // ie.image(index , 2).to_s
    }

    public void testImageIterator() throws Exception {
        assertEquals(6, ie.images().length());
        assertEquals("", ie.images().get(1).name());
        assertEquals("square", ie.images().get(1).id());
        assertTrue(ie.images().get(1).src().contains("square.jpg"));

        int i = 0;
        Images images = ie.images();

        for (Image image : images) {
            assertEquals(ie.image(i).id(), image.id());
            assertEquals(ie.image(i).name(), image.name());
            assertEquals(ie.image(i).src(), image.src());
            assertEquals(ie.image(i).height(), image.height());
            assertEquals(ie.image(i).width(), image.width());

            i += 1;
        }
        assertEquals(i, ie.images().length());
    }

    // public void test_save_local_image
    // ie.images[1].save(build_windows_path("sample.img.dat"))
    // assert(File.compare(@saved_img_path, ie.images[1].src.gsub(/^file\/\/\//,
    // '')))
    // }
    //
    // public void clean_saved_image
    // File.delete(@saved_img_path) if (File.exists()(@saved_img_path))
    // }
    //
    // public void build_windows_path(part)
    // build_path(part).gsub(/\//, "\\")
    // }
    //
    // public void build_path(part)
    // "#{myDir}/#{part}"
    // }
    // }

}
