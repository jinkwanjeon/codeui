package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.xpath;

public class ButtonsXpathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "buttons1.html");
    }

    public void testProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodId(ie.button(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodName(ie.button(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodDisabled(ie.button(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodType(ie.button(xpath, "//INPUT[@name='noName']"));
        assertRaisesUnknownObjectExceptionForMethodValue(ie.button(xpath, "//INPUT[@name='noName']"));

        assertEquals("b1", ie.button(xpath, "//INPUT[@id='b2']").name());
        assertEquals("b2", ie.button(xpath, "//INPUT[@id='b2']").id());
        assertEquals("button", ie.button(xpath, "//INPUT[@id='b2']").type());

    }

    public void testButtonUsingDefault() throws Exception {
        //# since most of the time, a button will be accessed based on its caption, there is a default way of accessing it....
        assertRaisesUnknownObjectExceptionForMethodClick(ie.button(xpath, "//INPUT[@value='Missing Caption']"));
        ie.button(xpath, "//INPUT[@value='Click Me']").click();
        assert(ie.text().contains("PASS"));
    }


    public void testButtonClickOnly() throws Exception {
        ie.button(xpath, "//INPUT[@value='Click Me']").click();
        assertTrue(ie.text().contains("PASS"));
    }

    public void testButtonClick() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClick(ie.button(xpath, "//INPUT[@value='Missing Caption']"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.button(xpath, "//INPUT[@id='MissingId']"));

        assertRaisesObjectDisabledExceptionForMethodClick(ie.button(xpath, "//INPUT[@value='Disabled Button']"));
        ie.button(xpath, "//INPUT[@value='Click Me']").click();
        assertTrue(ie.text().contains("PASS"));
    }

    public void testButtonExists() throws Exception {
        assertTrue(ie.button(xpath, "//INPUT[@value='Click Me']").exists());
        assertTrue(ie.button(xpath, "//INPUT[@value='Submit']").exists());
        assertTrue(ie.button(xpath, "//INPUT[@name='b1']").exists());
        assertTrue(ie.button(xpath, "//INPUT[@id='b2']").exists());

        assertFalse(ie.button(xpath, "//INPUT[@value='Missing Caption']").exists());
        assertFalse(ie.button(xpath, "//INPUT[@name='missingname']").exists());
        assertFalse(ie.button(xpath, "//INPUT[@id='missingid']").exists());

    }

    public void testButtonEnabled() throws Exception {
        assertTrue(ie.button(xpath, "//INPUT[@value='Click Me']").enabled());
        assertFalse(ie.button(xpath, "//INPUT[@value='Disabled Button']").enabled());
        assertFalse(ie.button(xpath, "//INPUT[@name='b4']").enabled());
        assertFalse(ie.button(xpath, "//INPUT[@id='b5']").enabled());
    }
}


