package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.name;
import static watij.finders.SymbolFactory.xpath;

public class DivXpathTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "div.html");
    }

    public void testDivs() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClick(ie.div(xpath, "//DIV[@id='div77']"));
        assertRaisesUnknownObjectExceptionForMethodClick(ie.div(xpath, "//DIV[@title='div77']"));

        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("0"));
        ie.div(xpath, "//DIV[@id='div3']").click();
        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("1"));
        ie.div(xpath, "//DIV[@id='div4']").click();
        assertTrue(ie.textField(xpath, "//INPUT[@name='text1']").verifyContains("0"));
    }

    public void testDivProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodText(ie.div(xpath, "//DIV[@id='div77']"));
        assertRaisesUnknownObjectExceptionForMethodText(ie.div(xpath, "//DIV[@title='div77']"));

        assertEquals("This div has an onClick that increments text1", ie.div(xpath, "//DIV[@id='div3']").text().trim());
        assertEquals("This text is in a div with an id of div1 and title of test1",
                ie.div(xpath, "//DIV[@title='Test1']").text().trim());

        assertRaisesUnknownObjectExceptionForMethodClassName(ie.div(xpath, "//DIV[@id='div77']"));
        assertEquals("blueText", ie.div(xpath, "//DIV[@id='div2']").className());
        assertEquals("", ie.div(xpath, "//DIV[@id='div1']").className());
    }

    public void testobjects_in_div() throws Exception {

        assertTrue(ie.div(xpath, "//DIV[@id='buttons1']").button(0).exists());
        assertFalse(ie.div(xpath, "//DIV[@id='buttons1']").button(2).exists());
        assertTrue(ie.div(xpath, "//DIV[@id='buttons1']").button(name, "b1").exists());

        assertTrue(ie.div(xpath, "//DIV[@id='buttons2']").button(0).exists());
        assertTrue(ie.div(xpath, "//DIV[@id='buttons2']").button(1).exists());
        assertFalse(ie.div(xpath, "//DIV[@id='buttons1']").button(2).exists());

        ie.div(xpath, "//DIV[@id='buttons1']").button(0).click();

        assertEquals("button1", ie.div(xpath, "//DIV[@id='text_fields1']").textField(0).value());

        assertEquals(3, ie.div(xpath, "//DIV[@id='text_fields1']").textFields().length());
    }

    public void testSpanProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodText(ie.span(xpath, "//SPAN[@id='span77']"));
        assertRaisesUnknownObjectExceptionForMethodText(ie.span(xpath, "//SPAN[@title='span77']"));

        assertEquals("This span has an onClick that increments text2",
                ie.span(xpath, "//SPAN[@id='span3']").text().trim());
        assertEquals("This text is in a span with an id of span1 and title of test2",
                ie.span(xpath, "//SPAN[@title='Test2']").text().trim());

        assertRaisesUnknownObjectExceptionForMethodClassName(ie.span(xpath, "//SPAN[@id='span77']"));
        assertEquals("blueText", ie.span(xpath, "//SPAN[@id='span2']").className());
        assertEquals("", ie.span(xpath, "//SPAN[@id='span1']").className());
    }


    public void testObjectsInSpan() throws Exception {

        assertTrue(ie.span(xpath, "//SPAN[@id='buttons1']").button(0).exists());
        assertFalse(ie.span(xpath, "//SPAN[@id='buttons1']").button(2).exists());
        assertTrue(ie.span(xpath, "//SPAN[@id='buttons1']").button(name, "b1").exists());

        assertTrue(ie.span(xpath, "//SPAN[@id='buttons2']").button(0).exists());
        assertTrue(ie.span(xpath, "//SPAN[@id='buttons2']").button(1).exists());
        assertFalse(ie.span(xpath, "//SPAN[@id='buttons1']").button(2).exists());

        ie.span(xpath, "//SPAN[@id='buttons1']").button(0).click();

        assertEquals("button1", ie.span(xpath, "//SPAN[@id='text_fields1']").textField(0).value());

        assertEquals(3, ie.span(xpath, "//SPAN[@id='text_fields1']").textFields().length());
    }

    public void testP() throws Exception {
        //P tag has not yet been implemented

//		assertTrue(ie.p(xpath, "//P[@id='number1']").exists());
//		assertTrue(ie.p(xpath, "//P[@title='test_3']").exists());
//
//		assertFalse(ie.p(xpath, "//P[@id='missing']").exists());
//		assertFalse(ie.p(xpath, "//P[@title='test_55']").exists());
//
//		assertRaisesUnknownObjectExceptionForMethodClassName(ie.p(xpath, "//P[@id='missing']"));
//		assertRaisesUnknownObjectExceptionForMethodText(ie.p(xpath, "//P[@id='missing']"));
//		assertRaisesUnknownObjectExceptionForMethodTitle(ie.p(xpath, "//P[@id='missing']"));
//		assertRaisesUnknownObjectExceptionForMethodToString(ie.p(xpath, "//P[@id='missing']"));
//		assertRaisesUnknownObjectExceptionForMethodDisabled(ie.p(xpath, "//P[@id='missing']"));
    }
}
