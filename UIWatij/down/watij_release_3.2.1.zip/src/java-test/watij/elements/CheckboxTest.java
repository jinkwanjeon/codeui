package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;

public class CheckboxTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "checkboxes1.html");
    }

    public void testCheckboxProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodId(ie.checkbox(name, "noName"));
        assertRaisesUnknownObjectExceptionForMethodName(ie.checkbox(name, "noName"));
        assertRaisesUnknownObjectExceptionForMethodDisabled(ie.checkbox(name, "noName"));
        assertRaisesUnknownObjectExceptionForMethodType(ie.checkbox(name, "noName"));
        assertRaisesUnknownObjectExceptionForMethodValue(ie.checkbox(name, "noName"));

        assertEquals("box1", ie.checkbox(0).name());
        assertEquals("", ie.checkbox(0).id());
        assertEquals("checkbox", ie.checkbox(0).type());
        assertEquals("on", ie.checkbox(0).value());
        assertEquals(false, ie.checkbox(0).disabled());
        assertEquals("check_box_style", ie.checkbox(name, "box1").className());
        assertEquals("", ie.checkbox(name, "box2").className());
        assertEquals("1", ie.checkbox(name, "box4").value());
        assertEquals("3", ie.checkbox(name, "box4", 3).value());
        assertEquals("checkbox", ie.checkbox(name, "box4", 3).type());
        assertEquals(false, ie.checkbox(name, "box4", 3).disabled());
        assertEquals("", ie.checkbox(name, "box4", 3).id());
        assertEquals("box4-value5", ie.checkbox(name, "box4", 5).title());
        assertEquals("", ie.checkbox(name, "box4", 4).title());
    }

    public void testOnClick() throws Exception {
        assertFalse(ie.button(value, "foo").enabled());
        ie.checkbox(name, "box5").set();
        assertTrue(ie.button(value, "foo").enabled());

        ie.checkbox(name, "box5").clear();
        assertFalse(ie.button(value, "foo").enabled());

        ie.checkbox(name, "box5").clear();
        assertFalse(ie.button(value, "foo").enabled());
    }

    public void testCheckboxExists() throws Exception {
        assertTrue(ie.checkbox(name, "box1").exists());
        assertFalse(ie.checkbox(name, "missing").exists());

        assertTrue(ie.checkbox(name, "box4", 1).exists());
        assertFalse(ie.checkbox(name, "box4", 22).exists());
    }

    public void testCheckboxEnabled() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.checkbox(name, "noName"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.checkbox(id, "noName"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.checkbox(name, "box4", 6));

        assertTrue(ie.checkbox(name, "box1").enabled());
        assertFalse(ie.checkbox(name, "box2").enabled());

        assertTrue(ie.checkbox(name, "box4", 4).enabled());
        assertFalse(ie.checkbox(name, "box4", 5).enabled());
    }

    public void testCheckboxIsSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodIsSet(ie.checkbox(name, "noName"));

        assertFalse(ie.checkbox(name, "box1").isSet());
        assertFalse(ie.checkbox(name, "box2").isSet());
        assertTrue(ie.checkbox(name, "box3").isSet());

        assertFalse(ie.checkbox(name, "box4", 2).isSet());
        assertTrue(ie.checkbox(name, "box4", 1).isSet());
    }

    public void testCheckboxClear() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClear(ie.checkbox(name, "noName"));

        ie.checkbox(name, "box1").clear();
        assertFalse(ie.checkbox(name, "box1").isSet());

        assertRaisesDisabledObjectExceptionForMethodClear(ie.checkbox(name, "box2"));

        assertFalse(ie.checkbox(name, "box2").isSet());

        ie.checkbox(name, "box3").clear();
        assertFalse(ie.checkbox(name, "box3").isSet());

        ie.checkbox(name, "box4", 1).clear();
        assertFalse(ie.checkbox(name, "box4", 1).isSet());
    }

    public void testCheckboxGetState() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodGetState(ie.checkbox(name, "noName"));

        assertEquals(false, ie.checkbox(name, "box1").getState());
        assertEquals(true, ie.checkbox(name, "box3").getState());

        // # checkboxes that have the same name() but different values
        assertEquals(false, ie.checkbox(name, "box4", 2).getState());
        assertEquals(true, ie.checkbox(name, "box4", 1).getState());
    }

    public void testCheckboxSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodSet(ie.checkbox(name, "noName"));

        ie.checkbox(name, "box1").set();
        assertTrue(ie.checkbox(name, "box1").isSet());

        assertRaisesDisabledObjectExceptionForMethodSet(ie.checkbox(name, "box2"));

        ie.checkbox(name, "box3").set();
        assertTrue(ie.checkbox(name, "box3").isSet());

        //# checkboxes that have the same name() but different value()s
        ie.checkbox(name, "box4", 3).set();
        assertTrue(ie.checkbox(name, "box4", 3).isSet());

        //# test set using the optinal true/false
        //# assumes the checkbox is already checked
        ie.checkbox(name, "box1").set(false);
        assertFalse(ie.checkbox(name, "box1").isSet());

        ie.checkbox(name, "box1").set(true);
        assertTrue(ie.checkbox(name, "box1").isSet());

    }

    public void testCheckboxIterator() throws Exception {
        assertEquals(11, ie.checkboxes().length());
        assertEquals("box1", ie.checkboxes().get(0).name());

        int i = 0;
        Checkboxes checkboxes = ie.checkboxes();
        for (Checkbox c : checkboxes) {
            assertEquals(ie.checkbox(i).name(), c.name());
            assertEquals(ie.checkbox(i).id(), c.id());
            assertEquals(ie.checkbox(i).value(), c.value());
            i += 1;
        }
        assertEquals(i, checkboxes.length());

    }
}
