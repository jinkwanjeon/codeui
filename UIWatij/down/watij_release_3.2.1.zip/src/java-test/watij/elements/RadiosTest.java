package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;

public class RadiosTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "radioButtons1.html");
    }

    public void testRadioExists() throws Exception {
        assertTrue(ie.radio(name, "box1").exists());
        assertTrue(ie.radio(id, "box5").exists());

        assertFalse(ie.radio(name, "missingname").exists());
        assertFalse(ie.radio(id, "missingid").exists());
    }

    public void testRadioClass() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClassName(ie.radio(name,
                "noName"));
        assertEquals("radio_style", ie.radio(name, "box1").className());
        assertEquals("", ie.radio(id, "box5").className());

    }

    public void testRadioEnabled() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.radio(name,
                "noName"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.radio(id,
                "noName"));
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.radio(name,
                "box4", 6));

        assertFalse(ie.radio(name, "box2").enabled());
        assertTrue(ie.radio(id, "box5").enabled());
        assertTrue(ie.radio(name, "box1").enabled());

    }

    public void testLittle() throws Exception {
        assertFalse(ie.button(value, "foo").enabled());
    }

    public void testOnClick() throws Exception {
        assertFalse(ie.radio(name, "box5").isSet());
        assertFalse(ie.button(value, "foo").enabled());

        // first click the button is enabled and the radio is set
        ie.radio(name, "box5", 1).set();
        assertTrue(ie.button(value, "foo").enabled());

        // second click the button is disabled and the radio is still set
        ie.radio(name, "box5", 1).set();
        assertTrue(ie.radio(name, "box5", 1).isSet());
        assertFalse(ie.button(value, "foo").enabled());

        // third click the button is enabled and the radio is still set
        ie.radio(name, "box5", 1).set();
        assertTrue(ie.radio(name, "box5", 1).isSet());
        assertTrue(ie.button(value, "foo").enabled());

        // click the radio with a value of 2 , button is disabled and the radio
        // is still set
        ie.radio(name, "box5", 2).set();
        assertFalse(ie.radio(name, "box5", 1).isSet());
        assertTrue(ie.radio(name, "box5", 2).isSet());
        assertFalse(ie.button(value, "foo").enabled());
    }

    public void testRadioIsSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodIsSet(ie.radio(name,
                "noName"));
        assertFalse(ie.radio(name, "box1").isSet());
        assertTrue(ie.radio(name, "box3").isSet());
        assertFalse(ie.radio(name, "box2").isSet());
        assertTrue(ie.radio(name, "box4", 1).isSet());
        assertFalse(ie.radio(name, "box4", 2).isSet());
    }

    public void testRadioClear() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClear(ie.radio(name,
                "noName"));

        ie.radio(name, "box1").clear();
        assertFalse(ie.radio(name, "box1").isSet());

        assertRaisesDisabledObjectExceptionForMethodClear(ie
                .radio(name, "box2"));
        assertFalse(ie.radio(name, "box2").isSet());

        ie.radio(name, "box3").clear();
        assertFalse(ie.radio(name, "box2").isSet());

        ie.radio(name, "box4", 1).clear();
        assertFalse(ie.radio(name, "box4", 1).isSet());

    }

    public void testRadioGetState() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodGetState(ie.radio(name,
                "noName"));

        assertEquals(false, ie.radio(name, "box1").getState());
        assertEquals(true, ie.radio(name, "box3").getState());

        // radioes that have the same name but different values
        assertEquals(false, ie.radio(name, "box4", 2).getState());
        assertEquals(true, ie.radio(name, "box4", 1).getState());

    }

    public void testRadioSet() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodSet(ie.radio(name, "noName"));
        ie.radio(name, "box1").set();
        assertTrue(ie.radio(name, "box1").isSet());

        assertRaisesDisabledObjectExceptionForMethodSet(ie.radio(name, "box2"));

        ie.radio(name, "box3").set();
        assertTrue(ie.radio(name, "box3").isSet());

        // radioes that have the same name but different values
        ie.radio(name, "box4", 3).set();
        assertTrue(ie.radio(name, "box4", 3).isSet());

    }

    public void testRadioProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodValue(ie.radio(999));
        assertRaisesUnknownObjectExceptionForMethodName(ie.radio(999));
        assertRaisesUnknownObjectExceptionForMethodId(ie.radio(999));
        assertRaisesUnknownObjectExceptionForMethodType(ie.radio(999));

        assertEquals("on", ie.radio(0).value());
        assertEquals("box1", ie.radio(0).name());
        assertEquals("", ie.radio(0).id());
        assertEquals("radio", ie.radio(0).type());

        assertEquals(false, ie.radio(0).disabled());
        assertEquals(true, ie.radio(2).disabled());

        assertEquals("box5", ie.radio(1).id());
        assertEquals("", ie.radio(1).name());

        assertEquals("box4-value5", ie.radio(name, "box4", 5).title());
        assertEquals("", ie.radio(name, "box4", 4).title());

    }

    public void testRadioIterators() throws Exception {
        Radios radios = ie.radios();
        assertEquals(11, radios.length());
        assertEquals("box5", radios.get(1).id());
        assertEquals(true, radios.get(2).disabled());
        assertEquals(false, radios.get(0).disabled());

        int i = 0;
        for (Radio radio : radios) {
            assertEquals(ie.radio(i).name(), radio.name());
            assertEquals(ie.radio(i).id(), radio.id());
            assertEquals(ie.radio(i).value(), radio.value());
            assertEquals(ie.radio(i).disabled(), radio.disabled());
            i += 1;

        }
        assertEquals(i, radios.length());
    }
}
