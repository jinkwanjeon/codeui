package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.id;
import static watij.finders.SymbolFactory.name;

public class FileFieldTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "fileupload.html");
        ie.bringToFront();
    }


    public void testFileFieldExists() throws Exception {
        //#test for existance of 4 file area
        assertTrue(ie.fileField(name, "file1").exists());
        assertTrue(ie.fileField(id, "file2").exists());
        //#test for missing
        assertTrue(!ie.fileField(name, "missing").exists());
        assertTrue(!ie.fileField(name, "totallybogus").exists());

        assertEquals("", ie.fileField(name, "file1").get());

        //#pop one open and put something in it.
        ie.fileField(name, "file1").set(HTML_ROOT + "fileupload.html");

        assertEquals(HTML_ROOT + "fileupload.html", ie.fileField(name, "file1").get());
        //#click the upload button
        ie.button(name, "upload").click();

        assertTrue(ie.containsText("PASS"));
    }

    public void testIterator() throws Exception {
        assertEquals(6, ie.fileFields().length());
    }

}
