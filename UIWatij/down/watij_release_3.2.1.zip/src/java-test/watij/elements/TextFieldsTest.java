package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.id;
import static watij.finders.SymbolFactory.name;

/**
 * Created by IntelliJ IDEA.
 * <p/>
 * Date Apr 17, 2006
 * Time 84855 PM
 * To change this template use File | Settings | File Templates.
 */
public class TextFieldsTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textfields1.html");
    }

    public void testTextFieldExists() throws Exception {

        assertTrue(ie.textField(name, "text1").exists());
        assertFalse(ie.textField(name, "missing").exists());

        assertTrue(ie.textField(id, "text2").exists());
        assertFalse(ie.textField(id, "alsomissing").exists());

//        assertTrue(ie.textField(beforeText, "This Text After").exists());
//        assertTrue(ie.textField(afterText, "This Text Before").exists());
//
//        assertTrue(ie.textField(beforeText, "/after/i").exists());
//        assertTrue(ie.textField(afterText, "/before/i").exists());
    }

//
//    def test_text_field_dragContentsTo
//        ie.textField(name, "text1").dragContentsTo(:id, "text2")
//        assertEquals(ie.textField(name, "text1").getContents, "")
//        assertEquals(ie.textField(:id, "text2").getContents, "goodbye allHello World")
//    end
//

    public void testTextFieldVerifyContains() throws Exception {
        assertTrue(ie.textField(name, "text1").verifyContains("Hello World"));
        assertTrue(ie.textField(name, "text1").verifyContains("/Hello\\sW/"));
        assertFalse(ie.textField(name, "text1").verifyContains("Ruby"));
        assertFalse(ie.textField(name, "text1").verifyContains(" / R / "));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(name, "NoName"), "No field to get a value of");
        assertTrue(ie.textField(id, "text2").verifyContains("goodbye all"));
        assertRaisesUnknownObjectExceptionForMethodVerifyContains(ie.textField(id, "noID"), "No field to get a value of");
    }

    public void testTextFieldEnabled() throws Exception {
        assertFalse(ie.textField(name, "disabled").enabled());
        assertTrue(ie.textField(name, "text1").enabled());
        assertTrue(ie.textField(id, "text2").enabled());
    }

    public void testTextFieldReadonly() throws Exception {
        assertFalse(ie.textField(name, "disabled").readOnly());
        assertTrue(ie.textField(name, "readOnly").readOnly());
        assertTrue(ie.textField(id, "readOnly2").readOnly());
    }

    public void testTextFieldGetContents() throws Exception {
        //        assert_raises(UnknownObjectException) { ie.textField(name, "missing_field").append("Some Text") }
        assertRaisesUnknownObjectExceptionForMethodId(ie.textField(name, "missing_field"));
        assertEquals("Hello World", ie.textField(name, "text1").getContents());
    }

//    def test_text_field_to_s
//        expected = [
//            build_to_s_regex("type", "text"),
//            build_to_s_regex("id", ""),
//            build_to_s_regex("name", "text1"),
//            build_to_s_regex("value", "Hello World"),
//            build_to_s_regex("disabled", "false"),
//            build_to_s_regex("length", "20"),
//            build_to_s_regex("max length", "2147483647"),
//            build_to_s_regex("read only", "false")
//        ]
//        items = ie.textField(0).to_s.split(/\n/)
//        expected.each_with_index{|regex, x| assert(regex =~ items[x]) }
//        expected[1] = build_to_s_regex("id", "text2")
//        expected[2] = build_to_s_regex("name", "")
//        expected[3] = build_to_s_regex("value", "goodbye all")
//        items = ie.textField(1).to_s.split(/\n/)
//        expected.each_with_index{|regex, x| assert(regex =~ items[x]) }
//        assert_raises(UnknownObjectException) { ie.textField(999).to_s }
//    end
//
//    def build_to_s_regex(lhs, rhs)
//        Regexp.new("^#{lhs}: +#{rhs}$")
//    end
//

    public void testTextFieldAppend() throws Exception {
        assertRaisesObjectReadOnlyExceptionForMethodAppend(ie.textField(id, "readOnly2"), "Some Text");
        assertRaisesObjectDisabledExceptionForMethodAppend(ie.textField(name, "disabled"), "Some Text");
        assertRaisesUnknownObjectExceptionForMethodAppend(ie.textField(name, "missing_field"), "Some Text");

        ie.textField(name, "text1").append(" Some Text");
        assertEquals("Hello World Some Text", ie.textField(name, "text1").getContents());
    }

    public void testTextFieldClear() throws Exception {
        ie.textField(name, "text1").clear();
        assertEquals("", ie.textField(name, "text1").getContents());
    }

    public void testTextFieldSet() throws Exception {
        ie.textField(name, "text1").set("watij IE Controller");
        assertEquals("watij IE Controller", ie.textField(name, "text1").value());
    }

    public void testTextFieldProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodValue(ie.textField(199));
        assertRaisesUnknownObjectExceptionForMethodName(ie.textField(199));
        assertRaisesUnknownObjectExceptionForMethodId(ie.textField(199));
        assertRaisesUnknownObjectExceptionForMethodDisabled(ie.textField(199));
        assertRaisesUnknownObjectExceptionForMethodType(ie.textField(199));

        assertEquals("Hello World", ie.textField(0).value());
        assertEquals("text", ie.textField(0).type());
        assertEquals("text1", ie.textField(0).name());
        assertEquals("", ie.textField(0).id());
        assertEquals(false, ie.textField(0).disabled());

        assertEquals("", ie.textField(1).name());
        assertEquals("text2", ie.textField(1).id());

        assertTrue(ie.textField(2).disabled());

        assertEquals("This used to test :afterText", ie.textField(name, "aftertest").title());
        assertEquals("", ie.textField(0).title());
    }


    public void testTextFieldIterators() throws Exception {
        assertEquals(12, ie.textFields().length());

        // watij is 0 based, so this is the first text field
        assertEquals("Hello World", ie.textFields().get(0).value());
        assertEquals("text1", ie.textFields().get(0).name());
        assertEquals("password", ie.textFields().get(ie.textFields().length() - 1).type());

        TextFields textFields = ie.textFields();
        int i;
        for (i = 0; i < textFields.length(); i++) {
            TextField t = textFields.get(i);
            assertEquals(ie.textField(i).value(), t.value());
            assertEquals(ie.textField(i).id(), t.id());
            assertEquals(ie.textField(i).name(), t.name());
        }
        assertEquals(i, ie.textFields().length());
    }

//        public void testJSEvents() {
//            ie.textField(name, 'events_tester').set('p')

//            # the following line has an extra keypress at the begining, as we mimic the delete key being pressed
//            assertEquals( "keypresskeydownkeypresskeyup" , ie.textField(name , 'events_text').value.gsub("\r\n" , "")  )
//            ie.button(:value , "Clear Events Box").click
//            ie.textField(name , 'events_tester').set('ab')

//            # the following line has an extra keypress at the begining, as we mimic the delete key being pressed
//            assertEquals( "keypresskeydownkeypresskeyupkeydownkeypresskeyup" , ie.textField(name , 'events_text').value.gsub("\r\n" , "") )
//        }

    public void testPassword() throws Exception {
        ie.textField(name, "password1").set("secret");
        assertEquals("secret", ie.textField(name, "password1").value());

        ie.textField(id, "password1").set("top_secret");
        assertEquals("top_secret", ie.textField(id, "password1").value());
    }


    public void testLabelsIterator() throws Exception {
        assertEquals(3, ie.labels().length());
        assertEquals("Label For this Field", ie.labels().get(0).innerText().trim());
        assertEquals("Password With ID ( the text here is a label for it )", ie.labels().get(2).innerText());

        int count = 0;
        for (Label l : ie.labels()) {
            count += 1;
        }
        assertEquals(count, ie.labels().length());
    }

    public void testLabelProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodInnerText(ie.label(20));
        assertRaisesUnknownObjectExceptionForMethodFor(ie.label(20));
        assertRaisesUnknownObjectExceptionForMethodName(ie.label(20));
        assertRaisesUnknownObjectExceptionForMethodType(ie.label(20));
        assertRaisesUnknownObjectExceptionForMethodId(ie.label(20));

        assertFalse(ie.label(10).exists());
        assertFalse(ie.label(id, "missing").exists());
        assertTrue(ie.label(0).exists());

        assertEquals("", ie.label(0).id());
        assertFalse(ie.label(0).disabled());
        assertTrue(ie.label(0).enabled());

        assertEquals("label2", ie.label(1).id());

        assertEquals("Password With ID ( the text here is a label for it )", ie.label(2).innerText());
        assertEquals("password1", ie.label(2).htmlFor());
    }
}
