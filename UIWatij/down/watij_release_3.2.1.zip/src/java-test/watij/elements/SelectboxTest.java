package watij.elements;

import watij.WatijTestCase;
import static watij.finders.SymbolFactory.*;
import watij.runtime.NoValueFoundException;
import watij.runtime.UnknownObjectException;

/**
 * Created by IntelliJ IDEA.
 * <p/>
 * Date Apr 20, 2006
 * Time 91541 PM
 * To change this template use File | Settings | File Templates.
 */
public class SelectboxTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "selectBoxes1.html");
    }

    public void testSelectListExists() throws Exception {
        assertTrue(ie.selectList(name, "sel1").exists());
        assertFalse(ie.selectList(name, "missing").exists());
        assertFalse(ie.selectList(id, "missing").exists());
    }

    public void testSelectListEnabled() throws Exception {
        assertTrue(ie.selectList(name, "sel1").enabled());
        //in watir test this is ie.selectList....!? why?
        assertRaisesUnknownObjectExceptionForMethodEnabled(ie.selectList(name, "NoName"));
        assertFalse(ie.selectList(id, "selectbox_4").enabled());
    }

    public void testSelectListClassName() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodClassName(ie.selectList(name, "missing"));
        assertEquals("list_style", ie.selectList(name, "sel1").className());
        //in watir test this is ie.selectList....!? why?
        assertEquals("", ie.selectList(name, "sel2").className());
    }


    public void testOptionTextSelect() throws Exception {
        try {
            ie.selectList(name, "sel1").option(text, "missing item").select();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

        try {
            ie.selectList(name, "sel1").option(text, "/missing/").select();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

        try {
            ie.selectList(name, "sel1").option(id, "Option 1").select();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

//       the select method keeps any currently selected items - use the clear selection method first
        ie.selectList(name, "sel1").clearSelection();
        ie.selectList(name, "sel1").option(text, "Option 1").select();
        assertEquals("[Option 1]", ie.selectList(name, "sel1").getSelectedItems().toString());
    }


    public void testOptionClassName() throws Exception {
        try {
            ie.selectList(name, "sel1").option(text, "missing item").className();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertEquals("option_style", ie.selectList(name, "sel2").option(value, "o2").className());
        assertEquals("", ie.selectList(name, "sel2").option(value, "o1").className());

    }

    public void testSelectListGetAllContents() throws Exception {
        try {
            ie.selectList(name, "NoName").getAllContents();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertEquals("[Option 1, Option 2, Option 3, Option 4]",
                ie.selectList(name, "sel1").getAllContents().toString());
    }

    public void testSelectListGetSelectedItems() throws Exception {
        try {
            ie.selectList(name, "NoName").getSelectedItems();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertEquals("[Option 3]", ie.selectList(name, "sel1").getSelectedItems().toString());
        assertEquals("[Option 3, Option 6]", ie.selectList(name, "sel2").getSelectedItems().toString());
    }

    public void testClearSelection() throws Exception {
        try {
            ie.selectList(name, "NoName").clearSelection();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

//            # the box sel1 has no ability to have a de-selected item
        assertEquals("[Option 3]", ie.selectList(name, "sel1").getSelectedItems().toString());

        ie.selectList(name, "sel2").clearSelection();
        assertEquals("[]", ie.selectList(name, "sel2").getSelectedItems().toString());
    }

    public void testSelectListSelect() throws Exception {
        try {
            ie.selectList(name, "sel1").select("missing item");
            failNoValueFoundException();
        } catch (NoValueFoundException e) {
        }

        try {
            ie.selectList(name, "sel1").select("/missing/");
            failNoValueFoundException();
        } catch (NoValueFoundException e) {
        }
//            # the select method keeps any currently selected items - use the clear selectcion method first
        ie.selectList(name, "sel1").clearSelection();
        ie.selectList(name, "sel1").select("Option 1");
        assertEquals("[Option 1]", ie.selectList(name, "sel1").getSelectedItems().toString());

        ie.selectList(name, "sel1").clearSelection();
        ie.selectList(name, "sel1").select("/2/");
        assertEquals("[Option 2]", ie.selectList(name, "sel1").getSelectedItems().toString());

        ie.selectList(name, "sel2").clearSelection();
        ie.selectList(name, "sel2").select("/2/");
        ie.selectList(name, "sel2").select("/4/");
        assertEquals("[Option 2, Option 4]", ie.selectList(name, "sel2").getSelectedItems().toString());

//            # these are to test the onchange event
//            # the event shouldnt get fired, as this is the selected item
        ie.selectList(name, "sel3").select("/3/");
        assertFalse(ie.text().contains("PASS"));
    }

    public void testSelectListSelect2() throws Exception {
//            # the event should get fired
        ie.selectList(name, "sel3").select("/2/");
        assertTrue(ie.text().contains("PASS"));
    }

    public void testSelectListSelectUsingValue() throws Exception {

        try {
            ie.selectList(name, "NoName").getSelectedItems();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }

        try {
            ie.selectList(name, "sel1").selectValue("missing item");
            failNoValueFoundException();
        } catch (NoValueFoundException e) {
        }

        try {
            ie.selectList(name, "sel1").selectValue("/missing/");
            failNoValueFoundException();
        } catch (NoValueFoundException e) {
        }

//            # the select method keeps any currently selected items - use the clear selectcion method first
        ie.selectList(name, "sel1").clearSelection();
        ie.selectList(name, "sel1").selectValue("o1");
        assertEquals("[Option 1]", ie.selectList(name, "sel1").getSelectedItems().toString());

        ie.selectList(name, "sel1").clearSelection();
        ie.selectList(name, "sel1").selectValue("/2/");
        assertEquals("[Option 2]", ie.selectList(name, "sel1").getSelectedItems().toString());

        ie.selectList(name, "sel2").clearSelection();
        ie.selectList(name, "sel2").selectValue("/4/");
        ie.selectList(name, "sel2").selectValue("/2/");
        assertEquals("[Option 2, Option 4]",
                ie.selectList(name, "sel2").getSelectedItems().toString());

//            # these are to test the onchange event
//            # the event shouldnt get fired, as this is the selected item
        ie.selectList(name, "sel3").selectValue("/3/");
        assertFalse(ie.text().contains("PASS"));
    }

    public void testSelectListSelectUsingValue2() throws Exception {
//            # the event should get fired
        ie.selectList(name, "sel3").selectValue("/2/");
        assertTrue(ie.text().contains("PASS"));
    }

    public void testSelectListProperties() throws Exception {
        assertRaisesUnknownObjectExceptionForMethodValue(ie.selectList(199));
        assertRaisesUnknownObjectExceptionForMethodName(ie.selectList(199));
        assertRaisesUnknownObjectExceptionForMethodId(ie.selectList(199));
        assertRaisesUnknownObjectExceptionForMethodDisabled(ie.selectList(199));
        assertRaisesUnknownObjectExceptionForMethodType(ie.selectList(199));
        assertRaisesUnknownObjectExceptionForMethodValue(ie.selectList(199));

        assertEquals("o3", ie.selectList(0).value());
        assertEquals("sel1", ie.selectList(0).name());
        assertEquals("", ie.selectList(0).id());
        assertEquals("select-one", ie.selectList(0).type());
        assertEquals("select-multiple", ie.selectList(1).type());

        ie.selectList(0).select("/1/");
        assertEquals("o1", ie.selectList(0).value());

        assertFalse(ie.selectList(0).disabled());
        assert(ie.selectList(3).disabled());
        assert(ie.selectList(id, "selectList_4").disabled());
    }

    public void testSelectListIterator() throws Exception {
        assertEquals(4, ie.selectLists().length());
        assertEquals("o3", ie.selectLists().get(0).value());
        assertEquals("sel1", ie.selectLists().get(0).name());
        assertEquals("select-one", ie.selectLists().get(0).type());
        assertEquals("select-multiple", ie.selectLists().get(1).type());

        int i = 0;
        SelectLists selectLists = ie.selectLists();
        for (SelectList l : selectLists) {
            assertEquals(ie.selectList(i).name(), l.name());
            assertEquals(ie.selectList(i).id(), l.id());
            assertEquals(ie.selectList(i).type(), l.type());
            assertEquals(ie.selectList(i).value(), l.value());
            i += 1;
        }
        assertEquals(i, ie.selectLists().length());
    }

    public void testOptionsText() throws Exception {
        ie.goTo(HTML_ROOT + "select_tealeaf.html");
        ie.selectList(name, "op_numhits").option(text, ">=").select();
        assertTrue(ie.selectList(name, "op_numhits").option(text, ">=").selected());
    }
}
