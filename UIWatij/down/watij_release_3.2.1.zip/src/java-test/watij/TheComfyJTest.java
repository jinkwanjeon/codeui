package watij;

import junit.framework.TestCase;

public class TheComfyJTest extends TestCase {
    public void testDummy() throws Exception {
        assertTrue(true);
    }
//    public static final String HTML_ROOT = System.getProperty("HTML_ROOT");
////    public static final String HTML_ROOT = "D:\\Work\\Native Resource Issue\\";
//
//    IWebBrowser2 iWebBrowser2;
//    static List<IWebBrowser2> childBrowsers = new ArrayList<IWebBrowser2>();
//
//    protected void setUp() throws Exception
//    {
//        iWebBrowser2 = createBrowser();
//    }
//
//    protected void tearDown() throws Exception
//    {
//    }
//
//    public void testComfyJChildBrowser_NRC_ON() throws Exception
//    {
//        doTestChildBrowser();
//    }
//
////    public void testComfyJChildBrowser_NRC_OFF() throws Exception
////    {
////        NativeResourceCollector nrc = NativeResourceCollector.getInstance();
////        nrc.stop();
////        doTestChildBrowser();
////    }
//
//    private void doTestChildBrowser() throws Exception
//    {
//        iWebBrowser2.navigate(new BStr(HTML_ROOT + "new_browser.html"),
//                new Variant(),
//                new Variant(),
//                new Variant(),
//                new Variant());
//
//        while (iWebBrowser2.getReadyState().getValue() != tagREADYSTATE.READYSTATE_COMPLETE)
//        {
//            Thread.sleep(200);
//        }
//
//        Runnable runnable = new Runnable()
//        {
//            public void run()
//            {
//                try
//                {
//                    IHTMLDocument2 doc2 = (IHTMLDocument2) IUnknownBinder.bind(new IHTMLDocument2Impl(IUnknownBinder.bind(iWebBrowser2.getDocument())));
//                    while (!"complete".equalsIgnoreCase(doc2.getReadyState().getValue()))
//                    {
//                        Thread.sleep(200);
//                    }
//
//                    IHTMLDocument3 doc3 = (IHTMLDocument3) IUnknownBinder.bind(new IHTMLDocument3Impl(doc2));
//                    IHTMLElementCollection ihtmlElementCollection = (IHTMLElementCollection) IUnknownBinder.bind(doc3.getElementsByTagName(new BStr("a")));
//                    System.out.println("ihtmlElementCollection = " + ihtmlElementCollection.invokeGetLength().getValue());
//                    IHTMLElement ihtmlElement = (IHTMLElement) IUnknownBinder.bind(new IHTMLElementImpl(IUnknownBinder.bind((ihtmlElementCollection.item(new Variant(1), new Variant())))));
//                    ihtmlElement.click();
//                    System.out.println("childBrowsers " + childBrowsers.size());
//                    final IWebBrowser2 childBrowser1 = (IWebBrowser2) IUnknownBinder.bind(childBrowsers.get(childBrowsers.size() - 1));
//
//                    waitUntilBrowserInitialized(childBrowser1);
//
//                    childBrowser1.navigate(new BStr(HTML_ROOT + "new_browser.html"),
//                            new Variant(),
//                            new Variant(),
//                            new Variant(),
//                            new Variant());
//                    while (childBrowser1.getReadyState().getValue() != tagREADYSTATE.READYSTATE_COMPLETE)
//                    {
//                        Thread.sleep(200);
//                    }
//
//                    doc2 = (IHTMLDocument2) IUnknownBinder.bind(new IHTMLDocument2Impl(IUnknownBinder.bind(childBrowser1.getDocument())));
//                    while (!"complete".equalsIgnoreCase(doc2.getReadyState().getValue()))
//                    {
//                        Thread.sleep(200);
//                    }
//                    doc3 = (IHTMLDocument3) IUnknownBinder.bind(new IHTMLDocument3Impl(doc2));
//                    ihtmlElementCollection = (IHTMLElementCollection) IUnknownBinder.bind(doc3.getElementsByTagName(new BStr("a")));
//                    System.out.println("child1 Browser ihtmlElementCollection = " + ihtmlElementCollection.invokeGetLength().getValue());
//
//
//                }
//                catch (Exception e)
//                {
//                    e.printStackTrace();
//                }
//            }
//        };
//        OleMessageLoop.invokeAndWait(runnable);
//    }
//
//    private static void waitUntilBrowserInitialized(IWebBrowser2 browser) throws Exception
//    {
//        while (true)
//        {
//            long readyState = browser.getReadyState().getValue();
//            if (readyState == tagREADYSTATE.READYSTATE_COMPLETE)
//            {
//                break;
//            }
//            else
//            {
//                Thread.sleep(100);
//            }
//        }
//    }
//
//    private static void setupListener(final IWebBrowser2 iWebBrowser2) throws Exception
//    {
//        IClassFactoryServer server = (new IClassFactoryServer(DWebBrowserEvents2Handler.class));
//
//        server.registerInterface(IDispatch.class, new IDispatchVTBL(server));
//        server.registerInterface(DWebBrowserEvents2.class, new IDispatchVTBL(server));
//        server.setDefaultInterface(IDispatch.class);
//
//        IClassFactory factory = server.createIClassFactory();
//
//        // Create instance of DWebBrowserEvents2Handler with a class factory
//        IDispatchImpl handler = new IDispatchImpl();
//        factory.createInstance(null, handler.getIID(), handler);
//
//        // Create IConnectionPointContainer to ActiveX object, which is embedded
//        //into OleContainer
//        IConnectionPointContainer connectionPointContainer = (IConnectionPointContainer) IUnknownBinder.bind(new IConnectionPointContainerImpl(iWebBrowser2));
//        // Find a necessary connection point
//        IConnectionPoint connectionPoint = (IConnectionPoint) IUnknownBinder.bind(connectionPointContainer.findConnectionPoint(new IID(DWebBrowserEvents2.INTERFACE_IDENTIFIER)));
//
//        // Advise our handler
//        Int32 int32 = connectionPoint.advise(handler);
//    }
//
//    private static void createChildBrowser() throws Exception
//    {
//        childBrowsers.add(createBrowser());
//    }
//
//    private static IWebBrowser2 createBrowser() throws Exception
//    {
//        IWebBrowser2 iWebBrowser2 = (IWebBrowser2) new IUnknownBinder(new Createable()
//        {
//            public IUnknown create() throws Exception
//            {
//                return InternetExplorer.create(ClsCtx.LOCAL_SERVER);
//            }
//        }).bind();
//
//        setupListener(iWebBrowser2);
//
//        iWebBrowser2.setVisible(VariantBool.TRUE);
//        return iWebBrowser2;
//    }
//
//
//    private static class IUnknownBinder
//    {
//        Exception exception;
//        IUnknown iUnknown;
//        Createable creatable;
//
//        public IUnknownBinder(Createable creatable)
//        {
//            this.creatable = creatable;
//        }
//
//        public IUnknown bind() throws Exception
//        {
//            OleMessageLoop.getInstance().doInvokeAndWait(new Runnable()
//            {
//                public void run()
//                {
//                    try
//                    {
//                        iUnknown = creatable.create();
//                    }
//                    catch (Exception e)
//                    {
//                        exception = e;
//                    }
//                }
//            });
//            if (exception != null)
//            {
//                throw exception;
//            }
//            return bind(iUnknown);
//        }
//
//        public static IUnknown bind(IUnknown iUnknown) throws Exception
//        {
//            return OleMessageLoop.getInstance().bindObject(iUnknown);
//        }
//    }
//
//    private static interface Createable
//    {
//        IUnknown create() throws Exception;
//    }
//
//    public static class DWebBrowserEvents2Handler extends DWebBrowserEvents2Server
//    {
//
//        public DWebBrowserEvents2Handler(CoClassMetaInfo coClassMetaInfo)
//        {
//            super(coClassMetaInfo);
//        }
//
//        public void progressChange(Int32 /*[in]*/ Progress, Int32 /*[in]*/ ProgressMax)
//        {
//            System.out.println("progressChange: " + Progress + " " + ProgressMax);
//        }
//
//
//        public void newWindow2(com.jniwrapper.win32.automation.IDispatch iDispatch, com.jniwrapper.win32.automation.types.VariantBool variantBool)
//        {
//            System.out.println("newWindow2");
//
//        }
//
//        public void newWindow3(IDispatch /*[in,out]*/ ppDisp, VariantBool /*[in,out]*/ Cancel, UInt32 /*[in]*/ dwFlags, BStr /*[in]*/ bstrUrlContext, BStr /*[in]*/ bstrUrl)
//        {
//            System.out.println("newWindow3");
//            try
//            {
//                createChildBrowser();
//                IWebBrowser2 browser = childBrowsers.get(childBrowsers.size() - 1);
//
//                browser = (IWebBrowser2) IUnknownBinder.bind(browser);
//
//
//                browser.setRegisterAsBrowser(VariantBool.TRUE);
//                ((IDispatchImpl) ppDisp).setValue(browser);
//            }
//            catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//    }
}
