package watij;

import watij.runtime.ie.IE;

public class OpenCloseTest extends WatijTestCase {

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    public void testWhetherJavComRuntimeOrRpcErrorHappens() throws Exception {
        for (int i = 0; i < 20; i++) {
            IE ie = new IE();
            ie.start();
            ie.close();
        }
    }

}


