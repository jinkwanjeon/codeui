package watij;

public class ScreenModeTest extends WatijTestCase {

    public void setUp() throws Exception {
        super.setUp();
        ie.goTo("about:blank");
    }

    protected void tearDown() throws Exception {
        ie.fullScreen(false);
        ie.theatreMode(false);
        super.tearDown();    //To change body of overridden methods use File | Settings | File Templates.
    }

    public void testVisible() throws Exception {
        assertFalse(ie.fullScreen());
        ie.fullScreen(true);
        assertTrue(ie.fullScreen());
    }

    public void testFullScreen() throws Exception {
        assertFalse(ie.fullScreen());
        ie.fullScreen(true);
        assertTrue(ie.fullScreen());
    }

    public void testTheatreMode() throws Exception {
        assertFalse(ie.theatreMode());
        ie.theatreMode(true);
        assertTrue(ie.theatreMode());
    }


}
