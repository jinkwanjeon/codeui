package watij;

public class PageContainsTextTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "textsearch.html");
    }

    public void testTextFound() throws Exception {
        assertTrue(ie.containsText("slings and arrows of outrageous fortune"));
    }

    public void testTextNotFound() throws Exception {
        assertFalse(ie.containsText("So are they all, all honourable men"));
    }

    public void testRegexFound() throws Exception {
        assertTrue(ie.containsText("/bodkin.*fardels/"));
    }

    public void testRegexNotFound() throws Exception {
        assertFalse(ie.containsText("/winding.*watch.*wit/"));
    }

    public void testMatchRegexFound() throws Exception {
        if (ie.containsText("/Messages ([0-9]+)/")) {

        }
    }

    //containsText returns a boolean.
//	                
//	    def test_match_regexp_found
//	    	$~ = $ie.contains_text(/Messages ([0-9]+)/)
//	        assert_equal('42', $1)
//	    end
//
    //java cant test bad arguments...it just wont compile for this scenario
//	    def test_bad_search_argument
//	        assert_raises(ArgumentError) do
//	            $ie.contains_text()
//	        end
//	        assert_raises(MissingWayOfFindingObjectException) do
//	            $ie.contains_text(nil)
//	        end
//	        assert_raises(MissingWayOfFindingObjectException) do
//	            $ie.contains_text(42)
//	        end
//	    end
//	                        
//	end
}
