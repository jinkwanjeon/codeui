package watij;

import java.io.File;

public class ScreenCaptureTest extends WatijTestCase {
    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "buttons1.html");
    }

    public void testScreenCaptureDefaultFormat() throws Exception {
        String pngFileName = "C:/testButtons.png";
        File file = new File(pngFileName);
        if (file.exists()) {
            file.delete();
        }
        ie.screenCapture(pngFileName);
        assertTrue(file.exists());
    }

    public void testWindowCaptureDefaultFormat() throws Exception {
        String pngFileName = "C:/testButtons2.png";
        File file = new File(pngFileName);
        if (file.exists()) {
            file.delete();
        }
        ie.windowCapture(pngFileName);
        assertTrue(file.exists());
    }

    public void testScreenCaptureBmpFormat() throws Exception {
        String bmpFileName = "C:/testButtons.bmp";
        File file = new File(bmpFileName);
        if (file.exists()) {
            file.delete();
        }
        ie.screenCapture(bmpFileName, "bmp");
        assertTrue(file.exists());
    }

    public void testWindowCaptureBmpFormat() throws Exception {
        String bmpFileName = "C:/testButtons2.bmp";
        File file = new File(bmpFileName);
        if (file.exists()) {
            file.delete();
        }
        ie.windowCapture(bmpFileName, "bmp");
        assertTrue(file.exists());
    }
}
