package watij;

import watij.elements.Frame;
import static watij.finders.SymbolFactory.id;
import static watij.finders.SymbolFactory.name;
import watij.runtime.UnknownObjectException;

public class FrameNestedTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "nestedFrames.html");
    }


    public void testFrame() throws Exception {
        try {
            ie.frame("missingFrame").button(id, "b2").enabled();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        Frame frame2 = ie.frame("nestedFrame").frame("subFrame");
        try {
            frame2.button(id, "b2");
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
        assertTrue(ie.frame("nestedFrame").frame("senderFrame").button(name, "sendIt").enabled());
        ie.frame("nestedFrame").frame("senderFrame").textField(0).set("Hello");
        ie.frame("nestedFrame").frame("senderFrame").button(name, "sendIt").click();
        assertTrue(ie.frame("nestedFrame").frame("receiverFrame").textField(name, "receiverText").verifyContains("Hello"));
    }


}
