package watij;

import watij.elements.*;
import static watij.finders.FinderFactory.*;
import static watij.finders.SymbolFactory.*;
import watij.finders.BaseFinder;
import watij.finders.Finder;
import watij.finders.DecendantFinder;
import watij.runtime.ie.IE;
import org.w3c.dom.Element;

import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class SandboxTest extends WatijTestCase {

    public void testDummy() throws Exception {
        assertTrue(true);
    }


//     public void testRetrieveHotelData() throws Exception {
//         File file = new File("c:\\hoteldata.txt");
//         if (file.exists()) {
//             file.delete();
//         }
//         BufferedWriter out = new BufferedWriter(new FileWriter(file));
//         ie.goTo("http://www.concierge.com/tools/hotelfinder");
//         Options regions = ie.selectList(name, "selectedRegion").options();
//         for (Option region : regions) {
//             System.out.println("region = " + region.text());
//             region.select();
//             Options destinations = ie.selectList(name,"selectedDestination").options();
//             for (Option destination : destinations) {
//                 System.out.println("destination = " + destination.text());
//                 if (destination.text().contains("Select One")) {
//                     continue;
//                 }
//                 destination.select();
//                 ie.executeScript("document.hotelFinder.target='_blank';document.hotelFinder.submit();");
//                 IE childBrowser = ie.childBrowser();
//                 childBrowser.waitUntilReady();
//                 Divs results = childBrowser.divs(attribute("class", "resultsName"));
//                 System.out.println("******************results.length() = " + results.length());
//                 for (Div result : results) {
//                     System.out.println("result = " + result.innerText());
//                     out.write(result.innerText()+"\n");
//                     out.flush();
//                 }
//
//                 childBrowser.close();
//             }
//         }
//         out.close();
//     }

//    public void testTable() throws Exception {
//        //ie.goTo("http://www.cnn.com/");
//        ie.bringToFront();
//        ie.goTo("http://www.kernel.org/");
//
//        System.out.println("nb tables:" + ie.tables().length());
//        for (Table table : ie.tables()) {
//            System.out.println("nb row:" + table.rowCount());
//            System.out.println("nb col:" + table.columnCount());
//            for (TableCell tableCell : table.cells()) {
//                System.out.print(tableCell.html().length() + ",");
//            }
//            System.out.println("");
//            System.out.println("");
//        }
//
//    }


//    public void testMySabreDownload() throws Exception {
//        ie.goTo("https://my.cert.sabre.com");
//        ie.textField(name("SABID")).set("sg0893178");
//        ie.textField(name("pass")).set("40bjts");
//        ie.link(id("signInButton")).click();
//        Thread.sleep(5000);
//        //ie.fileDownloadDialog("https://my.cert.sabre.com/jars/mysabre.zip").save("c:\\mysabre.zip");
//        ie.link("Destination Details").click();
////        HtmlElement htmlElement = ie.frame(id("virtualpage_alt_iframe")).htmlElement(tag("NOBR"),text("Weather"));
////        assertTrue(htmlElement.exists());
////        htmlElement.htmlElements(new Finder() {
////            public List<Element> find(List<Element> elements) throws Exception {
////                return elements;
////            }
////            public List<Element> find(Element element) throws Exception {
////                return new DecendantFinder().find((Element)element.getParentNode().getParentNode());
////            }
////        }).image(src("/editEN/")).click();
////        Thread.sleep(2000);
//        ie.frame(id("virtualpage_alt_iframe")).link("Home").click();
//    }

//    public void testSandbox() throws Exception {
//        ie.goTo("C:\\temp\\htmltest\\litest.html");
//        assertTrue(ie.htmlElement(attribute("class","butAsReportedData")).exists());
//        assertTrue(ie.htmlElements(id,"hover").htmlElement(attribute("class","butAsReportedData")).exists());
//    }
//
//    public void testSecurityAlert() throws Exception {
//        ie.sendKeys("Security Alert", "%y", false);
//        ie.goTo("https://denton.dev.sabre.com/");
//    }

//    public static void main(String[] Args) throws Exception {
//        ie.start();
//        ie.goTo("C:\\Projects\\Watij\\watij\\trunk\\res\\html\\buttons1.html");
//        ie.bringToFront();
//        try {
//            ie.button(name("b1"), id("b2"), value("Click Me")).flash();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

}
