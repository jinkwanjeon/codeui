package watij;

public class MinMaxTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "pass.html");
    }

    public void testMinimum() throws Exception {
        ie.minimize();
    }

    public void testMaximum() throws Exception {
        ie.maximize();
    }

    public void testRestore() throws Exception {
        ie.maximize();
        ie.restore();
    }

    public void testFront() throws Exception {
//		assertTrue(ie.isFront());
//		IE ie2 = new IE();
//		ie2.start(HTML_ROOT + "blankpage.html");
//		assertTrue(ie2.isFront());
//		assertFalse(ie.isFront());
//		ie.bringToFront();
//		assertTrue(ie.isFront());
//		ie2.close();
//
    }
}
