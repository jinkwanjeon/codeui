package watij;

import static watij.finders.SymbolFactory.id;
import static watij.finders.SymbolFactory.name;
import watij.runtime.UnknownObjectException;

public class FrameMultiTest extends WatijTestCase {

    protected void setUp() throws Exception {
        super.setUp();
        ie.goTo(HTML_ROOT + "frame_multi.html");
    }

    public void testFrameWithNoName() throws Exception {

        try {
            ie.frame(name, "missingFrame").button(id, "b2").enabled();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
    }

    public void testFrameById() throws Exception {
        try {
            ie.frame(id, "missingFrame").button(id, "b2").enabled();
            failUnknownObjectException();
        } catch (UnknownObjectException e) {
        }
    }
}
