package watij;

import watij.runtime.ie.IE;
import watij.runtime.ie.IEUtil;

public class CloseAllBrowsersTest extends WatijTestCase {

    public void testCloseAllBrowsers() throws Exception {
        int originalNumberBrowsers = IEUtil.browserCount();
        int numberToCreate = 5;
        for (int i = 0; i < numberToCreate; i++) {
            new IE().start();
        }
        assertEquals(originalNumberBrowsers + numberToCreate, IEUtil.browserCount());
        Thread.sleep(1000);
        IEUtil.closeAllBrowsers();
        Thread.sleep(1000);
        assertEquals(0, IEUtil.browserCount());
    }

    protected void tearDown() throws Exception {
        initIEForTesting();
    }
}
