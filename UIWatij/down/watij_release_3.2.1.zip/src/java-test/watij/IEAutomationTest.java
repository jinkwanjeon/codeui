package watij;

import junit.framework.TestCase;

public class IEAutomationTest extends TestCase {

    public void testDummy() throws Exception {
        assertTrue(true);
    }

//    public void testSetBrowser() throws Exception {
//        IEAutomation ie1 = new IEAutomation();
//        ie1.setVisible(true);
//        setupEventHandler(ie1);
//        ie1.navigate("http://www.yahoo.com");
//        ie1.waitReady();
//
////        IEAutomation ie2 = new IEAutomation((IWebBrowser2)ie1.getBrowserPeer());
//        IEAutomation ie2 = new IEAutomation();
//        ie2.close();
//        attach("/Yahoo/", false, ie2);
//        setupEventHandler(ie2);
//        ie2.navigate("http://www.google.com");
//        ie2.waitReady();
//        System.out.println("ie2.getDocument().getTitle() = " + ie2.getDocument().getTitle());
//        ie2.close();
//    }
//
//    protected void setupEventHandler(IEAutomation ieAutomation) {
//        IE.IEEventHandler ieEventHandler = new IE.IEEventHandler(null);
//        ieAutomation.addIEApplicationEventListener(ieEventHandler);
//        ieAutomation.setEventHandler(ieEventHandler);
//        ieAutomation.addNewWindowListener(ieEventHandler);
//        ieAutomation.addNavigationListener(ieEventHandler);
//    }
//
//    protected static void attach(final String titleOrUrl, final boolean url, IEAutomation ieAutomation) throws Exception {
//
//        OleMessageLoop oleMessageLoop = ieAutomation.getOleMessageLoop();
//        class AttachBrowserAction implements BrowserAction {
//            IWebBrowser2 browser = null;
//            public boolean perform(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception {
//                if (url && StringUtils.matchesOrEquals(titleOrUrl, iWebBrowser2.getLocationURL().getValue())) {
//                    Debug.getInstance().println("Found Visible Browser By URL**");
//                    browser = iWebBrowser2;
//                    return false;
//                } else {
//                    IDispatch document = (IDispatch) oleMessageLoop.bindObject(iWebBrowser2.getDocument());
//                    IHTMLDocument2 ihtmlDocument2 = (IHTMLDocument2) oleMessageLoop.bindObject(new IHTMLDocument2Impl(document));
//                    if (StringUtils.matchesOrEquals(titleOrUrl, ihtmlDocument2.getTitle().getValue())) {
//                        Debug.getInstance().println("Found Visible Browser By Title**");
//                        browser = iWebBrowser2;
//                        return false;
//                    }
//                }
//                return true;
//            }
//        };
//
//        AttachBrowserAction attachBrowserAction = new AttachBrowserAction();
//        executeOnAllBrowsers(attachBrowserAction, oleMessageLoop);
//
//        if (attachBrowserAction.browser == null) {
//            throw new NoMatchingWindowFoundException("Could not find browser");
//        }
//        ieAutomation.setBrowser(attachBrowserAction.browser);
//    }
//
//    protected static void executeOnAllBrowsers(BrowserAction browserAction, OleMessageLoop oleMessageLoop) throws Exception {
//
//        IWebBrowser2 browser;
//        IShellWindows iShellWindows = (IShellWindows) IEUtil.bind(oleMessageLoop, new IUnknownFactory() {
//            public IUnknown create() throws Exception {
//                return ShellWindows.create(ClsCtx.INPROC_SERVER);
//            }
//        });
//
//        int count = (int) iShellWindows.getCount().getValue();
//        Debug.getInstance().println("Number Browsers Found by ShellWindows = " + count);
//
//        for (int i = count - 1; i >= 0; i--) {
//            Debug.getInstance().println("Trying Browser " + i);
//            IDispatch item = (IDispatch) oleMessageLoop.bindObject(iShellWindows.item(new Variant(i)));
//            if (item.isNull()) {
//                browser = null;
//                continue;
//            }
//            browser = (IWebBrowser2) oleMessageLoop.bindObject(new IWebBrowser2Impl(item));
//            try {
//                IDispatch document = (IDispatch) oleMessageLoop.bindObject(browser.getDocument());
//                oleMessageLoop.bindObject(new IHTMLDocument2Impl(document));
//            } catch (Throwable t) {
//                Debug.handleException(t);
//                browser = null;
//                continue;
//            }
//            if (!browserAction.perform(browser, oleMessageLoop)) {
//                break;
//            };
//        }
//    }
//
//    static interface BrowserAction {
//        boolean perform(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception;
//    }

//    static List<WebBrowser> childWebBrowsers = new ArrayList<WebBrowser>();
//
//    public static final String HTML_ROOT = System.getProperty("HTML_ROOT");
//
//    public void testChildBrowser() throws Exception {
//        for (int i = 0; i < 10; i++) {
//            doTestChildBrowser();
//        }
//    }
//
//    public void doTestChildBrowser() throws Exception {
////        IEAutomation ieAutomation = new IEAutomation();
////
////        ieAutomation.addIEApplicationEventListener(new IEApplicationEventAdapter() {
////            public void onQuit() {
////                System.out.println("onQuit");
////            }
////
////            public void onVisible(boolean visible) {
////                System.out.println("onVisible: " + visible);
////            }
////
////
////        });
////
////        ieAutomation.addNavigationListener(new NavigationEventAdapter() {
////            public void entireDocumentCompleted(WebBrowser webBrowser, String url) {
////                System.out.println("entireDocumentCompleted: url = " + url);
////            }
////
////        });
////
////        ieAutomation.addNewWindowListener(new NewWindowEventListener() {
////
////            public void windowOpened(WebBrowser webBrowser) {
////                childWebBrowsers.add(webBrowser);
////            }
////        });
////
////        ieAutomation.setVisible(true);
////        ieAutomation.navigate(HTML_ROOT + "new_browser.html");
////        ieAutomation.waitReady();
////        assertTrue(ieAutomation.getContent().contains("New Browser Launcher"));
////
////        HTMLDocument htmlDocument = ieAutomation.getDocument();
////        NodeList nodeList = htmlDocument.getElementsByTagName("a");
////        HTMLElement htmlElement = (HTMLElement) nodeList.item(1);
////        htmlElement.click();
////
////        while (childWebBrowsers.size() == 0) {
////            System.out.println(".");
////        }
////        WebBrowser childBrowser = childWebBrowsers.get(0);
////        childBrowser.waitReady();
////        assertTrue(childBrowser.getContent().contains("Self-closer"));
////        childBrowser.close();
////        ieAutomation.close();
//
//
//        IEAutomation ieAutomation = new IEAutomation();
//        setupAdaptors(ieAutomation);
//
//        ieAutomation.setVisible(true);
//        ieAutomation.navigate(HTML_ROOT + "new_browser.html");
//        ieAutomation.waitReady();
//        assertTrue(ieAutomation.getContent().contains("New Browser Launcher"));
//
//        HTMLDocument htmlDocument = ieAutomation.getDocument();
//        NodeList nodeList = htmlDocument.getElementsByTagName("a");
//        HTMLElement htmlElement = (HTMLElement) nodeList.item(1);
//        ieAutomation.trackChildren();
//        htmlElement.click();
//
//        WebBrowser childBrowser = ieAutomation.waitChildCreation();
//        childBrowser.waitReady();
//        System.out.println("childBrowser = " + childBrowser.getContent());
//        assertTrue(childBrowser.getContent().contains("Self-closer"));
//
//        childBrowser.close();
//        ieAutomation.close();
//
//    }
//
//    private void setupAdaptors(IEAutomation ieAutomation) {
//        ieAutomation.addIEApplicationEventListener(new IEApplicationEventAdapter() {
//            public void onQuit() {
//                System.out.println("onQuit");
//            }
//
//            public void onVisible(boolean visible) {
//                System.out.println("onVisible: " + visible);
//            }
//        });
//
//        ieAutomation.addNavigationListener(new NavigationEventAdapter() {
//            public void entireDocumentCompleted(WebBrowser webBrowser, String url) {
//                System.out.println("entireDocumentCompleted: url = " + url);
//            }
//        });
//
//        ieAutomation.addNewWindowListener(new NewWindowEventListener() {
//            public void windowOpened(WebBrowser webBrowser) {
//                setupAdaptors((IEAutomation)webBrowser);
//                childWebBrowsers.add(webBrowser);
//            }
//        });
//    }
}
