package watij;

import junit.framework.TestCase;

public class TeamDevComfyJTest extends TestCase {

    public void testDummy() throws Exception {
        assertTrue(true);
    }

//    public static final String HTML_ROOT = System.getProperty("HTML_ROOT");
//
//    IWebBrowser2 iWebBrowser2;
//    static List<IWebBrowser2> childBrowsers = new ArrayList<IWebBrowser2>();
//
//    protected void setUp() throws Exception {
//        OleFunctions.oleInitialize();
//        OleMessageLoop.invokeAndWait(new Runnable() {
//            public void run() {
//                try {
//                    iWebBrowser2 = createBrowser();
//                }
//                catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//    }
//
//    protected void tearDown() throws Exception {
//        OleFunctions.oleUninitialize();
//    }
//
//    public void testComfyJChildBrowser_NRC_ON() throws Exception {
//        doTestChildBrowser();
//    }
//
//    public void testComfyJChildBrowser_NRC_OFF() throws Exception {
//        NativeResourceCollector nrc = NativeResourceCollector.getInstance();
//        nrc.stop();
//        doTestChildBrowser();
//    }
//
//    private void doTestChildBrowser() throws Exception {
//        Runnable runnable = new Runnable() {
//            public void run() {
//                try {
//                    iWebBrowser2.navigate(new BStr(HTML_ROOT + "new_browser.html"),
//                            new Variant(),
//                            new Variant(),
//                            new Variant(),
//                            new Variant());
//
//                    System.out.println("tagREADYSTATE.READYSTATE_COMPLETE = " + tagREADYSTATE.READYSTATE_COMPLETE);
//
//                    while (iWebBrowser2.getReadyState().getValue() != tagREADYSTATE.READYSTATE_COMPLETE) {
//
//                        System.out.println("iWebBrowser2.getReadyState().getValue() = " + iWebBrowser2.getReadyState().getValue());
//
//                        Thread.sleep(200);
//                    }
//                    IHTMLDocument2 doc2 = new IHTMLDocument2Impl(iWebBrowser2.getDocument());
//                    while (!"complete".equalsIgnoreCase(doc2.getReadyState().getValue())) {
//                        Thread.sleep(200);
//                    }
//
//                    System.out.println("1");
//
//                    IHTMLDocument3 doc3 = new IHTMLDocument3Impl(doc2);
//                    IHTMLElementCollection ihtmlElementCollection = doc3.getElementsByTagName(new BStr("a"));
//                    System.out.println("ihtmlElementCollection = " + ihtmlElementCollection.invokeGetLength().getValue());
//
//                    System.out.println("2");
//
//                    IHTMLElement ihtmlElement = new IHTMLElementImpl(ihtmlElementCollection.item(new Variant(1), new Variant()));
//
//                    System.out.println("3");
//
//                    ihtmlElement.click();
//                    System.out.println("childBrowsers " + childBrowsers.size());
//                    IWebBrowser2 childBrowser1 = childBrowsers.get(childBrowsers.size() - 1);
//
//                    System.out.println("4");
//
//                    waitUntilBrowserInitialized(childBrowser1);
//
//                    System.out.println("5");
//
//
//                    childBrowser1.navigate(new BStr(HTML_ROOT + "new_browser.html"),
//                            new Variant(),
//                            new Variant(),
//                            new Variant(),
//                            new Variant());
//
//                    while (childBrowser1.getReadyState().getValue() != tagREADYSTATE.READYSTATE_COMPLETE) {
//                        Thread.sleep(200);
//                    }
//
//
//                    doc2 = new IHTMLDocument2Impl(childBrowser1.getDocument());
//                    while (!"complete".equalsIgnoreCase(doc2.getReadyState().getValue())) {
//                        Thread.sleep(200);
//                    }
//
//
//                    doc3 = new IHTMLDocument3Impl(doc2);
//                    ihtmlElementCollection = doc3.getElementsByTagName(new BStr("a"));
//                    System.out.println("child1 Browser ihtmlElementCollection = " + ihtmlElementCollection.invokeGetLength().getValue());
//                }
//                catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        };
//        OleMessageLoop.invokeAndWait(runnable);
//    }
//
//    private static void waitUntilBrowserInitialized(final IWebBrowser2 browser) throws Exception {
//        Runnable runnable = new Runnable() {
//            public void run() {
//                while (true) {
//                    try {
//                        browser.stop();
//                        browser.getBusy();
//
//
//                        if (browser.isNull() || browser.getBusy().getBooleanValue()) {
//                            Thread.sleep(20);
//                            continue;
//                        }
//                    }
//                    catch (Throwable t) {
//                        t.printStackTrace();
//                        continue;
//                    }
//                    break;
//                }
//            }
//        };
//        OleMessageLoop.invokeAndWait(runnable);
//    }
//
//    private static void setupListener(IWebBrowser2 iWebBrowser2) {
//
//        // Create class factory server for our DWebBrowserEvents2Impl
//        IClassFactoryServer server = new IClassFactoryServer(DWebBrowserEvents2Handler.class);
//        server.registerInterface(IDispatch.class, new IDispatchVTBL(server));
//        server.registerInterface(DWebBrowserEvents2.class, new IDispatchVTBL(server));
//        server.setDefaultInterface(IDispatch.class);
//
//        IClassFactory factory = server.createIClassFactory();
//
//        // Create instance of DWebBrowserEvents2Handler with a class factory
//        IDispatchImpl handler = new IDispatchImpl();
//        factory.createInstance(null, handler.getIID(), handler);
//
//        // Create IConnectionPointContainer to ActiveX object, which is embedded
//        //into OleContainer
//        IConnectionPointContainer connectionPointContainer = new IConnectionPointContainerImpl(iWebBrowser2);
//        // Find a necessary connection point
//        IConnectionPoint connectionPoint = connectionPointContainer.findConnectionPoint(new IID(DWebBrowserEvents2.INTERFACE_IDENTIFIER));
//
//        // Advise our handler
//        Int32 int32 = connectionPoint.advise(handler);
//    }
//
//    private static void createChildBrowser() throws Exception {
//        childBrowsers.add(createBrowser());
//    }
//
//    private static IWebBrowser2 createBrowser() throws Exception {
//        IWebBrowser2 iWebBrowser2 = InternetExplorer.create(ClsCtx.LOCAL_SERVER);
//        setupListener(iWebBrowser2);
//        iWebBrowser2.setVisible(VariantBool.TRUE);
//        return iWebBrowser2;
//    }
//
//    public static class DWebBrowserEvents2Handler extends DWebBrowserEvents2Server {
//
//        public DWebBrowserEvents2Handler(CoClassMetaInfo coClassMetaInfo) {
//            super(coClassMetaInfo);
//        }
//
//        public void progressChange(Int32 /*[in]*/ Progress, Int32 /*[in]*/ ProgressMax) {
//            System.out.println("progressChange: " + Progress + " " + ProgressMax);
//        }
//
//        public void newWindow3(IDispatch /*[in,out]*/ ppDisp, VariantBool /*[in,out]*/ Cancel, UInt32 /*[in]*/ dwFlags, BStr /*[in]*/ bstrUrlContext, BStr /*[in]*/ bstrUrl) {
//            try {
//                createChildBrowser();
//                IWebBrowser2 browser = childBrowsers.get(childBrowsers.size() - 1);
//                browser.setRegisterAsBrowser(VariantBool.TRUE);
//                ((IDispatchImpl) ppDisp).setValue(browser);
//            }
//            catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
}