package watij;

import junit.framework.TestCase;
import watij.elements.*;
import watij.runtime.NavigationException;
import watij.runtime.ObjectDisabledException;
import watij.runtime.ObjectReadOnlyException;
import watij.runtime.UnknownObjectException;
import watij.runtime.ie.IE;
import watij.utilities.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 8:49:26 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class WatijTestCase extends TestCase {

    public static final String HTML_ROOT = System.getProperty("HTML_ROOT");
    public static IE ie;

    static {
        try {
            initIEForTesting();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    protected void finalize() throws Throwable {
//        ie.close();
//    }

    protected static void initIEForTesting() throws Exception {
        // perform the "global" set up logic
        IE throwAway = new IE();
        throwAway.start();
        Thread.sleep(1000); //this is so the proxy popup get stuck on the throw away browser
        ie = new IE();
        ie.start();
        ie.bringToFront();
        // perform the "global" tear down logic
//        NativeResourceCollector nrc = NativeResourceCollector.getInstance();
//        nrc.addShutdownAction(new Thread(new Runnable() {
//            public void run() {
//                try {
//                    ie.close();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }));
    }

    protected void setUp() throws Exception {
        ie.bringToFront();
    }
//
//    protected void tearDown() throws Exception {
//        ie.close();
//    }

    protected void assertRaisesUnknownObjectExceptionForMethodId(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.id();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodValue(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.value();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodName(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.name();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodDisabled(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.disabled();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodType(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.type();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodInnerText(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.innerText();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodFor(Label label) throws Exception {
        try {
            label.htmlFor();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodVerifyContains(TextField textField, String what) throws Exception {
        try {
            textField.verifyContains(what);
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodClick(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.click();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodClassName(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.className();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodEnabled(HtmlElement htmlElement) throws Exception {
        try {
            htmlElement.enabled();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodIsSet(RadioCheckCommon common) throws Exception {
        try {
            common.isSet();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodSet(RadioCheckCommon common) throws Exception {
        try {
            common.set();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodClear(RadioCheckCommon common) throws Exception {
        try {
            common.clear();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodGetState(RadioCheckCommon common) throws Exception {
        try {
            common.getState();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodHasLoaded(Image image) throws Exception {
        try {
            image.hasLoaded();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodValue(Image image) throws Exception {
        try {
            image.value();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodHeight(Image image) throws Exception {
        try {
            image.height();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodWidth(Image image) throws Exception {
        try {
            image.width();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodFileCreatedDate(Image image) throws Exception {
        try {
            image.fileCreatedDate();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodFileSize(Image image) throws Exception {
        try {
            image.fileSize();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodAlt(Image image) throws Exception {
        try {
            image.alt();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodTitle(Image image) throws Exception {
        try {
            image.title();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodSrc(Image image) throws Exception {
        try {
            image.src();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodAppend(TextField field, String data) throws Exception {
        try {
            field.append(data);
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodText(Div div) throws Exception {
        try {
            div.text();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesUnknownObjectExceptionForMethodText(Span span) throws Exception {
        try {
            span.text();
            failUnknownObjectException();
        } catch (UnknownObjectException e1) {
        }
    }

    protected void assertRaisesDisabledObjectExceptionForMethodClear(RadioCheckCommon common) throws Exception {
        try {
            common.clear();
            failObjectDisabledException();
        } catch (ObjectDisabledException e1) {
        }
    }

    protected void assertRaisesDisabledObjectExceptionForMethodSet(RadioCheckCommon common) throws Exception {
        try {
            common.set();
            failObjectDisabledException();
        } catch (ObjectDisabledException e1) {
        }
    }

    protected void assertRaisesObjectDisabledExceptionForMethodClick(HtmlElement element) throws Exception {
        try {
            element.click();
            failObjectDisabledException();
        } catch (ObjectDisabledException e1) {
        }
    }

    protected void assertRaisesObjectReadOnlyExceptionForMethodAppend(TextField field, String text) throws Exception {
        try {
            field.append(text);
            failReadOnlyException();
        } catch (ObjectReadOnlyException e1) {
        }
    }

    protected void assertRaisesObjectDisabledExceptionForMethodAppend(TextField field, String text) throws Exception {
        try {
            field.append(text);
            failObjectDisabledException();
        } catch (ObjectDisabledException e1) {
        }
    }

    protected void assertRaisesNavigationException(IE ie, String nav) throws Exception {
        try {
            ie.goTo(nav);
            failNavigationException();
        } catch (NavigationException e1) {
        }
    }

    protected void failUnknownObjectException() {
        fail("Should have thrown UnknownObjectException");
    }

    protected void failObjectDisabledException() {
        fail("Should have thrown ObjectDisabledException");
    }

    protected void failMissingWayOfFindingObjectException() {
        fail("Should have thrown MissingWayOfFindingObjectException");
    }

    protected void failNoValueFoundException() {
        fail("Should have thrown NoValueFoundException");
    }

    protected void failNavigationException() {
        fail("Should have thrown NavigationException");
    }

    protected void failReadOnlyException() {
        fail("Should have thrown ReadOnlyException");
    }


    protected void assertMatches(String regex, String match) {
        assertTrue(StringUtils.matchesOrContains(regex, match));
    }
}
