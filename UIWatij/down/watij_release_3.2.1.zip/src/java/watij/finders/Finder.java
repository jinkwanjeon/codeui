package watij.finders;

import org.w3c.dom.Element;

import java.util.List;

public interface Finder {
    List<Element> find(List<Element> elements) throws Exception;

    List<Element> find(Element element) throws Exception;
}
