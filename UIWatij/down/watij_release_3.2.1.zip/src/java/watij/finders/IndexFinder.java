package watij.finders;

import org.w3c.dom.Element;

import java.util.List;
import java.util.ArrayList;

public class IndexFinder implements Finder {

    int index;

    public IndexFinder(int index) {
        this.index = index;
    }

    public List<Element> find(List<Element> elements) throws Exception {
        ArrayList<Element> list = new ArrayList<Element>();
        list.add(elements.get(index));
        return list;
    }

    public List<Element> find(Element element) throws Exception {
        return find(new DecendantFinder().find(element));
    }
}
