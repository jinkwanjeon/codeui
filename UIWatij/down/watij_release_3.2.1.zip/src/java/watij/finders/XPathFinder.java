package watij.finders;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.util.ArrayList;
import java.util.List;

public class XPathFinder implements Finder, Symbol {

    String what;

    public XPathFinder() {
    }

    public XPathFinder(String what) {
        this.what = what;
    }

    public Finder newFinder(String what) throws Exception {
        return new XPathFinder(what);
    }

    public List<Element> find(Element element) throws Exception {
        List<Element> list = new ArrayList<Element>();
        javax.xml.xpath.XPath xpath = XPathFactory.newInstance().newXPath();
        NodeList nodeList = (NodeList) xpath.evaluate(what, element, XPathConstants.NODESET);
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                list.add((Element) node);
            }
        }
        return list;
    }

    public List<Element> find(List<Element> elements) throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }
}
