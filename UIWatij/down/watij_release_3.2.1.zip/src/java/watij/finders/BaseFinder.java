package watij.finders;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseFinder implements Finder, Matcher {

    public List<Element> find(List<Element> elements) throws Exception {
        List<Element> newList = new ArrayList<Element>();
        for (int i = 0; i < elements.size(); i++) {
            Element element = elements.get(i);
            if (matches(element)) {
                newList.add(element);
            }
        }
        return newList;
    }

    public List<Element> find(Element element) throws Exception {
        return find(new DecendantFinder().find(element));
    }
}
