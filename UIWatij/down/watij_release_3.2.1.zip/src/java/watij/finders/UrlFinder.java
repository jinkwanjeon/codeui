package watij.finders;

public class UrlFinder extends AttributeFinder implements Symbol {

    public UrlFinder(String name) {
        super(name);
    }

    public UrlFinder(String name, String what) {
        super(name, what);
    }
}
