package watij.finders;

import watij.WatijBrowser;

public interface BrowserMatcher extends Finder {
    boolean matches(WatijBrowser watijBrowser) throws Exception;
}
