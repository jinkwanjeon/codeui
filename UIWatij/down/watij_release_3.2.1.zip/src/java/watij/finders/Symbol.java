package watij.finders;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 13, 2006
 * Time: 8:00:24 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Symbol {
    Finder newFinder(String what) throws Exception;
}
