package watij.finders;

import org.w3c.dom.Element;

public interface Matcher {
    boolean matches(Element element) throws Exception;
}
