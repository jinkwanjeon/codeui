package watij.finders;

public class TitleFinder extends AttributeFinder {
    public TitleFinder(String name) {
        super(name);
    }

    public TitleFinder(String name, String what) {
        super(name, what);
    }
}
