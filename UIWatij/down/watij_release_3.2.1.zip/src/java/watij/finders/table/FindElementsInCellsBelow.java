package watij.finders.table;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;

public class FindElementsInCellsBelow {

    public List<Element> find(Element element) throws Exception {
        List<Element> filteredList = new ArrayList<Element>();
//        List belowElements = new Cell(element).below();
//        List belowDecendantElements = new FindDecendantElements().find(belowElements);
//        filteredList.addAll(belowDecendantElements);
        return filteredList;
    }

}
