package watij.finders.table;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;

public class FindElementsInCellsAfter {


    public List<Element> find(Element element) throws Exception {
        List<Element> filteredList = new ArrayList<Element>();
//        List rightElements = new Cell(element).right();
//        List rightDecendantElements = new FindDecendantElements().find(rightElements);
//        filteredList.addAll(rightDecendantElements);
        return filteredList;
    }

}
