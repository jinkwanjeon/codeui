package watij.finders.table;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;

public class FindElementsInCellsBefore {

    public List<Element> find(Element element) throws Exception {
        List<Element> filteredList = new ArrayList<Element>();
//        List leftElements = new Cell(element).left();
//        List leftDecendantElements = new FindDecendantElements().find(leftElements);
//        filteredList.addAll(leftDecendantElements);
        return filteredList;
    }

}
