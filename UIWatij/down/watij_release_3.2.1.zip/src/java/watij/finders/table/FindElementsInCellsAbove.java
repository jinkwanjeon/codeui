package watij.finders.table;

import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;

public class FindElementsInCellsAbove {

    public List<Element> find(Element element) throws Exception {
        List<Element> filteredList = new ArrayList<Element>();
//        List aboveElements = new Cell(element).above();
//        List aboveDecendantElements = new FindDecendantElements().find(aboveElements);
//        filteredList.addAll(aboveDecendantElements);
        return filteredList;
    }
}
