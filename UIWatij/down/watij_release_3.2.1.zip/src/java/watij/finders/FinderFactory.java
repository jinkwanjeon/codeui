package watij.finders;

public class FinderFactory {


    public static Finder attribute(String name, String value) {
        return new AttributeFinder(name, value);
    }

    public static Finder index(int index) {
        return new IndexFinder(index);
    }

    public static Finder tag(String tagName) {
        return new TagFinder(tagName);
    }

    public static Finder text(String text) {
        return new TextFinder(text);
    }

    public static Finder xpath(String expression) {
        return new XPathFinder(expression);
    }

    public static Finder name(String value) {
        return attribute("name", value);
    }

    public static Finder url(String value) {
        return new UrlFinder("href", value);
    }

    public static Finder href(String value) {
        return attribute("href", value);
    }

    public static Finder id(String value) {
        return attribute("id", value);
    }

    public static Finder value(String value) {
        return attribute("value", value);
    }

    public static Finder caption(String value) {
        return attribute("value", value);
    }

    public static Finder title(String value) {
        return new TitleFinder("title", value);
    }

    public static Finder alt(String value) {
        return attribute("alt", value);
    }

    public static Finder src(String value) {
        return attribute("src", value);
    }

    public static Finder action(String value) {
        return attribute("action", value);
    }

    public static Finder method(String value) {
        return attribute("method", value);
    }
}
