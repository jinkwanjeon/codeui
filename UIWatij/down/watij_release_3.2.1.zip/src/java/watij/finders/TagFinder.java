package watij.finders;

import org.w3c.dom.Element;
import watij.utilities.Utils;

public class TagFinder extends BaseFinder implements Symbol {

    String what;

    public TagFinder() {
    }

    public TagFinder(String what) {
        this.what = what;
    }

    public Finder newFinder(String what) throws Exception {
        return new TagFinder(what);
    }

    public boolean matches(Element element) throws Exception {
        return (Utils.isEmpty(what) || what.equalsIgnoreCase(element.getTagName()));
    }
}