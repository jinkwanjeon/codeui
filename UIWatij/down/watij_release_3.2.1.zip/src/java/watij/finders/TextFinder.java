package watij.finders;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import watij.utilities.StringUtils;
import watij.utilities.Utils;


/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 6:40:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class TextFinder extends BaseFinder implements Symbol {

    String what;

    public TextFinder() {
    }

    public TextFinder(String what) {
        this.what = what;
    }

    public Finder newFinder(String what) throws Exception {
        return new TextFinder(what);
    }

    public boolean matches(Element element) throws Exception {
        String elementText = innerText(element);
        return Utils.isEmpty(what) || (!Utils.isEmpty(elementText) && StringUtils.matchesOrEquals(what, elementText));
    }

    private String innerText(Element element) {
        StringBuffer sBuf = new StringBuffer();
        decendantInnerText(element,sBuf);
        return sBuf.toString();
    }

    private void decendantInnerText(Node node, StringBuffer sBuf) {
        NodeList nodeList = node.getChildNodes();
        int size = nodeList.getLength();
        for (int i = 0; i < size; i++) {
            Node child = nodeList.item(i);
            if (child != null && child.getNodeType() == Node.TEXT_NODE) {
                sBuf.append(child.getNodeValue());
                decendantInnerText(child,sBuf);
            }
        }
    }
}
