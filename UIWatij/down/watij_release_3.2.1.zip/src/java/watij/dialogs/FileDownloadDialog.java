package watij.dialogs;

public interface FileDownloadDialog extends Dialog {
    void open() throws Exception;
    void cancel() throws Exception;
    void save(String fullPathAndFileName) throws Exception;
    void closeThisDialogBoxWhenDownloadCompletes(boolean close) throws Exception;
    void waitUntilDownloadComplete() throws Exception;
    void close() throws Exception;
}
