package watij.dialogs;

public interface AlertDialog extends Dialog {
    void ok() throws Exception;
}
