package watij.dialogs;

public interface Dialog {
    String text() throws Exception;
    String title() throws Exception;
    void quit() throws Exception;
    boolean exists() throws Exception;
}
