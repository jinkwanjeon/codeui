package watij.dialogs;

public interface PromptDialog extends ConfirmDialog {
    void value(String text) throws Exception;
    String value() throws Exception;
}
