package watij.dialogs;

import watij.Container;

public interface ModalDialog extends Container {
    void close() throws Exception;
}
