package watij.dialogs;

public interface ConfirmDialog extends AlertDialog {
    void cancel() throws Exception;
}
