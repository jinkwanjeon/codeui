package watij;

import watij.elements.*;
import watij.finders.Finder;
import watij.finders.Symbol;

public interface HtmlFinder {

    TextFields textFields(Finder... finder) throws Exception;

    TextField textField(Finder... finder) throws Exception;

    TextField textField(Finder finder) throws Exception;

    TextFields textFields() throws Exception;

    TextField textField(Symbol how, String what) throws Exception;

    TextFields textFields(Symbol how, String what) throws Exception;

    TextField textField(int index) throws Exception;

    Hiddens hiddens(Finder... finder) throws Exception;

    Hidden hidden(Finder... finder) throws Exception;

    Hiddens hiddens() throws Exception;

    Hidden hidden(Symbol how, String what) throws Exception;

    Hiddens hiddens(Symbol how, String what) throws Exception;

    Hidden hidden(int index) throws Exception;

    Buttons buttons(Finder... finder) throws Exception;

    Button button(Finder... finder) throws Exception;

    Buttons buttons() throws Exception;

    Button button(Symbol how, String what) throws Exception;

    Buttons buttons(Symbol how, String what) throws Exception;

    Button button(int index) throws Exception;

    Button button(String value) throws Exception;

    Labels labels(Finder... finder) throws Exception;

    Label label(Finder... finder) throws Exception;

    Labels labels() throws Exception;

    Label label(Symbol how, String what) throws Exception;

    Labels labels(Symbol how, String what) throws Exception;

    Label label(int index) throws Exception;

    Label label(String text) throws Exception;

    Links links(Finder... finder) throws Exception;

    Link link(Finder... finder) throws Exception;

    Links links() throws Exception;

    Link link(Symbol how, String what) throws Exception;

    Links links(Symbol how, String what) throws Exception;

    Link link(int index) throws Exception;

    Link link(String text) throws Exception;

    Radios radios(Finder... finder) throws Exception;

    Radio radio(Finder... finder) throws Exception;

    Radios radios() throws Exception;

    Radio radio(Symbol how, String what) throws Exception;

    Radios radios(Symbol how, String what) throws Exception;

    Radio radio(int index) throws Exception;

    Radio radio(Symbol how, String what, String value) throws Exception;

    Radio radio(Symbol how, String what, int value) throws Exception;

    Checkboxes checkboxes(Finder... finder) throws Exception;

    Checkbox checkbox(Finder... finder) throws Exception;

    Checkboxes checkboxes() throws Exception;

    Checkbox checkbox(Symbol how, String what) throws Exception;

    Checkboxes checkboxes(Symbol how, String what) throws Exception;

    Checkbox checkbox(int index) throws Exception;

    Checkbox checkbox(Symbol how, String what, String value) throws Exception;

    Checkbox checkbox(Symbol how, String what, int value) throws Exception;

    SelectLists selectLists(Finder... finder) throws Exception;

    SelectList selectList(Finder... finder) throws Exception;

    SelectLists selectLists() throws Exception;

    SelectList selectList(Symbol how, String what) throws Exception;

    SelectLists selectLists(Symbol how, String what) throws Exception;

    SelectList selectList(int index) throws Exception;

    SelectList selectList(String value) throws Exception;

    Images images(Finder... finder) throws Exception;

    Image image(Finder... finder) throws Exception;

    Images images() throws Exception;

    Image image(Symbol how, String what) throws Exception;

    Images images(Symbol how, String what) throws Exception;

    Image image(int index) throws Exception;

    Divs divs(Finder... finder) throws Exception;

    Div div(Finder... finder) throws Exception;

    Divs divs() throws Exception;

    Div div(Symbol how, String what) throws Exception;

    Divs divs(Symbol how, String what) throws Exception;

    Div div(int index) throws Exception;

    Spans spans(Finder... finder) throws Exception;

    Span span(Finder... finder) throws Exception;

    Spans spans() throws Exception;

    Span span(Symbol how, String what) throws Exception;

    Spans spans(Symbol how, String what) throws Exception;

    Span span(int index) throws Exception;

    Frames frames(Finder... finder) throws Exception;

    Frame frame(Finder... finder) throws Exception;

    Frames frames() throws Exception;

    Frame frame(Symbol how, String what) throws Exception;

    Frames frames(Symbol how, String what) throws Exception;

    Frame frame(int index) throws Exception;

    Frame frame(String name) throws Exception;

    Forms forms(Finder... finder) throws Exception;

    Form form(Finder... finder) throws Exception;

    Forms forms() throws Exception;

    Form form(Symbol how, String what) throws Exception;

    Forms forms(Symbol how, String what) throws Exception;

    Form form(int index) throws Exception;

    Form form(String name) throws Exception;

    FileFields fileFields(Finder... finder) throws Exception;

    FileField fileField(Finder... finder) throws Exception;

    FileFields fileFields() throws Exception;

    FileField fileField(Symbol how, String what) throws Exception;

    FileFields fileFields(Symbol how, String what) throws Exception;

    FileField fileField(int index) throws Exception;

    Tables tables(Finder... finder) throws Exception;

    Table table(Finder... finder) throws Exception;

    Tables tables() throws Exception;

    Table table(Symbol how, String what) throws Exception;

    Tables tables(Symbol how, String what) throws Exception;

    Table table(int index) throws Exception;

    TableRows rows(Finder... finder) throws Exception;

    TableRow row(Finder... finder) throws Exception;

    TableRows rows() throws Exception;

    TableRow row(Symbol how, String what) throws Exception;

    TableRows rows(Symbol how, String what) throws Exception;

    TableRow row(int index) throws Exception;

    TableCells cells(Finder... finder) throws Exception;

    TableCell cell(Finder... finder) throws Exception;

    TableCells cells() throws Exception;

    TableCell cell(Symbol how, String what) throws Exception;

    TableCells cells(Symbol how, String what) throws Exception;

    TableCell cell(int index) throws Exception;

    TableBodies bodies(Finder... finder) throws Exception;

    TableBody body(Finder... finder) throws Exception;

    TableBodies bodies() throws Exception;

    TableBody body(Symbol how, String what) throws Exception;

    TableBodies bodies(Symbol how, String what) throws Exception;

    TableBody body(int index) throws Exception;

    Options options(Finder... finder) throws Exception;

    Option option(Finder... finder) throws Exception;

    Options options() throws Exception;

    Option option(Symbol how, String what) throws Exception;

    Options options(Symbol how, String what) throws Exception;

    Option option(int index) throws Exception;

    HtmlElements htmlElements(Finder... finder) throws Exception;

    HtmlElement htmlElement(Finder... finder) throws Exception;

    HtmlElements htmlElements() throws Exception;

    HtmlElement htmlElement(Symbol how, String what) throws Exception;

    HtmlElements htmlElements(Symbol how, String what) throws Exception;

    HtmlElement htmlElement(int index) throws Exception;
}
