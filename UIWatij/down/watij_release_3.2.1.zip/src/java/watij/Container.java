package watij;

import org.w3c.dom.Element;
import watij.elements.HtmlElements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 14, 2006
 * Time: 6:34:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Container extends HtmlFinder {

    String html() throws Exception;

    Object getOLEDocument() throws Exception;

    Element element() throws Exception;

    HtmlElements decendants() throws Exception;

    HtmlElements xpath(String expression) throws Exception;
}


