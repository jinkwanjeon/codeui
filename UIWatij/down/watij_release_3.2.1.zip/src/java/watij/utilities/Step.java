package watij.utilities;

public class Step implements Output {

    int count = 0;
    Output output;
    String prefix;

    public Step(String prefix, Output output) {
        this.prefix = prefix;
        this.output = output;
    }

    public Step(Output output) {
        this("Step", output);
    }

    public void println(String string) {
        output.println(prefix + " " + (++count) + ": " + string);
    }

    public static Step getInstance() {
        return new Step(new Output() {
            public void println(String string) {
                System.out.println(string);
            }
        });
    }

    public static Step getInstance(String prefix) {
        return new Step(prefix, new Output() {
            public void println(String string) {
                System.out.println(string);
            }
        });
    }
}
