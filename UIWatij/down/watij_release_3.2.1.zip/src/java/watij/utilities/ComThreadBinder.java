package watij.utilities;

import com.jniwrapper.win32.com.IUnknown;

public interface ComThreadBinder {
    IUnknown bind(IUnknownFactory iUnknownFactory) throws Exception;

    IUnknown bind(IUnknown iUnknown) throws Exception;
}
