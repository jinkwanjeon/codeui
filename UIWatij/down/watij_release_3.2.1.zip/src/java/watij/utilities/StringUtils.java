package watij.utilities;

import java.util.regex.Pattern;

public class StringUtils {

    public static boolean matchesOrEquals(String pattern, String match) {
        if (pattern.matches("^/.*/$")) {
            return Pattern.compile(unstripPattern(pattern)).matcher(match).find();
        } else if (pattern.matches("^/.*/([i])$")) {
            pattern = pattern.substring(0, pattern.length() - 1);
            return Pattern.compile(unstripPattern(pattern), Pattern.CASE_INSENSITIVE).matcher(match).find();
        } else {
            return match.equalsIgnoreCase(pattern);
        }
    }

    private static String unstripPattern(String pattern) {
        if (pattern.length() == 2 && pattern.equals("//")) {
            return "";
        } else {
            return pattern.substring(1, pattern.length() - 1);
        }
    }

    public static boolean matchesOrContains(String pattern, String match) {
        if (pattern.matches("^/.*/$")) {
            return Pattern.compile(unstripPattern(pattern)).matcher(match).find();

        } else if (pattern.matches("^/.*/([i])$")) {
            pattern = pattern.substring(0, pattern.length() - 1);
            return Pattern.compile(unstripPattern(pattern), Pattern.CASE_INSENSITIVE).matcher(match).find();
        } else {
            return match.contains(pattern);
        }
    }
}
