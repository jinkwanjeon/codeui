package watij.utilities;

/**
 * This enumeration lists all the resources available in the WatijResources bundle
 * @author Anson Mayers
 * @since 8.0
 */
public enum WatijResources {
    IEConfirmDialog_Cancel("IEConfirmDialog_Cancel"),
    IEFileDownloadDialog_Cancel("IEFileDownloadDialog_Cancel"),
    IEFileDownloadDialog_Close("IEFileDownloadDialog_Close"),
    IEFileDownloadDialog_Open("IEFileDownloadDialog_Open"),
    IEFileDownloadDialog_CloseWhenComplete("IEFileDownloadDialog_CloseWhenComplete"),
    IEFileDownloadDialog_Save("IEFileDownloadDialog_Save"),
    IEFileDownloadDialog_Title_DownloadComplete("IEFileDownloadDialog_Title_DownloadComplete"),
    IEFileDownloadDialog_Title_FileDownload("IEFileDownloadDialog_Title_FileDownload"),
    IEFileDownloadDialog_Title_SaveAs("IEFileDownloadDialog_Title_SaveAs"),
    IEFileField_ChooseFile("IEFileField_ChooseFile"),
    IEPromptDialog_Title_ExplorerUserPrompt("IEPromptDialog_Title_ExplorerUserPrompt");

    private String key;

    WatijResources(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
