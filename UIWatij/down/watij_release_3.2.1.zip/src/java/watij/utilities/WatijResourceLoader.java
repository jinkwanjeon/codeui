/* Copyright (c) 2006, CA Inc.  All rights reserved */
package watij.utilities;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * This API encasulates retrieving strings from the Watij resource bundle
 * @author Anson Mayers
 * @since 8.0
 */
public class WatijResourceLoader {

    private static final Locale runtimeLocale = new Locale(System.getProperty("browser.ui.locale", "en_US"));
    private static final ResourceBundle bundle = ResourceBundle.getBundle("watij.WatijResources", runtimeLocale);

    /**
     * Returns a resource appropriate to the runtime locale, which is selected using the JVM property
     * "browser.ui.locale", which should be set to a valid locale string, such as "en_US".
     * @param resourceId_ the key to look up in the resource bundle
     * @return the value associated for the key localized to the browser.ui.locale
     */
    public static String getString(WatijResources resourceId_)
    {
        return bundle.getString(resourceId_.getKey());
    }
}
