package watij.utilities;

import com.jniwrapper.win32.com.IUnknown;

public interface IUnknownFactory {
    IUnknown create() throws Exception;
}
