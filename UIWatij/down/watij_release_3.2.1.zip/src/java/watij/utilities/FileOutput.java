package watij.utilities;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Map;

public class FileOutput implements Output {

    PrintWriter printWriter;
    File file;
    static Map hash = new Hashtable();

    public FileOutput(String fileName) throws Exception {
        this.file = new File("c:\\" + fileName + ".txt");
        if (hash.get(file) == null && file.exists()) {
            file.delete();
        }
        this.printWriter = new PrintWriter(new FileWriter(file, true));
        hash.put(file, this);
    }

    public void println(String string) {
        printWriter.println(string);
        printWriter.flush();
    }

    public void delete() {
        file.delete();
    }
}
