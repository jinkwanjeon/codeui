package watij.utilities;

public interface Output {
    void println(String string);
}
