package watij.utilities;

public class Utils {

    public static String replace(String srcStr, String searchSubStr, String replaceSubStr) {
        String result = srcStr;
        while (result.indexOf(searchSubStr) != -1) {
            int startIndex = result.indexOf(searchSubStr);
            result = result.substring(0, startIndex) + replaceSubStr + result.substring(startIndex + searchSubStr.length(), result.length());
        }
        return result;
    }

    public static boolean isEmpty(String string) {
        return string == null || string.length() == 0;
    }

    public static boolean isEmpty(Object object) {
        return object == null || object.toString().length() == 0;
    }
}