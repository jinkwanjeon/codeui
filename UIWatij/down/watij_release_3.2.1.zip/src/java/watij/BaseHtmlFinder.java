package watij;

import org.w3c.dom.Element;
import watij.elements.*;
import watij.finders.Finder;
import watij.finders.FinderFactory;
import watij.finders.Symbol;
import watij.finders.SymbolFactory;
import watij.utilities.Debug;

import java.util.List;
import java.util.ArrayList;

public abstract class BaseHtmlFinder implements HtmlFinder {

    protected abstract HtmlElementFactory htmlElementFactory() throws Exception;

    public abstract List<Element> elements() throws Exception;

    protected HtmlElements find(Element element,Finder... finder) throws Exception {
        return find(finder[0].find(element),1,finder);
    }

    protected HtmlElements find(List<Element> elements, Finder... finder) throws Exception {
        return find(elements, 0, finder);
    }

    protected HtmlElements find(List<Element> elements, int startIndex, Finder... finder) throws Exception {
        for (int i = startIndex; i < finder.length; i++) {
            elements = finder[i].find(elements);
        }
        return new HtmlElements(elements, htmlElementFactory());
    }

    public TextFields textFields(Finder... finder) throws Exception {
        return htmlElements(finder).textFields();
    }

    public TextField textField(Finder... finder) throws Exception {
        return textFields(finder).get(0);
    }

    public TextField textField(Finder finder) throws Exception {
        return textFields(finder).get(0);
    }

    public TextFields textFields() throws Exception {
        return new TextFields(elements(), htmlElementFactory());
    }

    public TextField textField(Symbol how, String what) throws Exception {
        return textFields(how, what).get(0);
    }

    public TextFields textFields(Symbol how, String what) throws Exception {
        return htmlElements(how, what).textFields();
    }

    public TextField textField(int index) throws Exception {
        return textFields().get(index);
    }

    public Hiddens hiddens(Finder... finder) throws Exception {
        return htmlElements(finder).hiddens();
    }

    public Hidden hidden(Finder... finder) throws Exception {
        return hiddens(finder).get(0);
    }

    public Hiddens hiddens() throws Exception {
        return new Hiddens(elements(), htmlElementFactory());
    }

    public Hidden hidden(Symbol how, String what) throws Exception {
        return hiddens(how, what).get(0);
    }

    public Hiddens hiddens(Symbol how, String what) throws Exception {
        return htmlElements(how, what).hiddens();
    }

    public Hidden hidden(int index) throws Exception {
        return hiddens().get(index);
    }

    public Buttons buttons(Finder... finder) throws Exception {
        return htmlElements(finder).buttons();
    }

    public Button button(Finder... finder) throws Exception {
        return buttons(finder).get(0);
    }

    public Buttons buttons() throws Exception {
        return new Buttons(elements(), htmlElementFactory());
    }

    public Button button(Symbol how, String what) throws Exception {
        return buttons(how, what).get(0);
    }

    public Buttons buttons(Symbol how, String what) throws Exception {
        return htmlElements(how, what).buttons();
    }

    public Button button(int index) throws Exception {
        return buttons().get(index);
    }

    public Button button(String value) throws Exception {
        return button(FinderFactory.attribute("value", value));
    }

    public Labels labels(Finder... finder) throws Exception {
        return htmlElements(finder).labels();
    }

    public Label label(Finder... finder) throws Exception {
        return labels(finder).get(0);
    }

    public Labels labels() throws Exception {
        return new Labels(elements(), htmlElementFactory());
    }

    public Label label(Symbol how, String what) throws Exception {
        return labels(how, what).get(0);
    }

    public Labels labels(Symbol how, String what) throws Exception {
        return htmlElements(how, what).labels();
    }

    public Label label(int index) throws Exception {
        return labels().get(index);
    }

    public Label label(String text) throws Exception {
        return label(FinderFactory.text(text));
    }

    public Links links(Finder... finder) throws Exception {
        return htmlElements(finder).links();
    }

    public Link link(Finder... finder) throws Exception {
        return links(finder).get(0);
    }

    public Links links() throws Exception {
        return new Links(elements(), htmlElementFactory());
    }

    public Link link(Symbol how, String what) throws Exception {
        return links(how, what).get(0);
    }

    public Links links(Symbol how, String what) throws Exception {
        return htmlElements(how, what).links();
    }

    public Link link(int index) throws Exception {
        return links().get(index);
    }

    public Link link(String text) throws Exception {
        return link(FinderFactory.text(text));
    }

    public Radios radios(Finder... finder) throws Exception {
        return htmlElements(finder).radios();
    }

    public Radio radio(Finder... finder) throws Exception {
        return radios(finder).get(0);
    }

    public Radios radios() throws Exception {
        return new Radios(elements(), htmlElementFactory());
    }

    public Radio radio(Symbol how, String what) throws Exception {
        return radios(how, what).get(0);
    }

    public Radios radios(Symbol how, String what) throws Exception {
        return htmlElements(how, what).radios();
    }

    public Radio radio(int index) throws Exception {
        return radios().get(index);
    }

    public Radio radio(Symbol how, String what, String value) throws Exception {
        return htmlElements(SymbolFactory.value, value).radio(how, what);
    }

    public Radio radio(Symbol how, String what, int value) throws Exception {
        return radio(how, what, "" + value);
    }

    public Checkboxes checkboxes(Finder... finder) throws Exception {
        return htmlElements(finder).checkboxes();
    }

    public Checkbox checkbox(Finder... finder) throws Exception {
        return checkboxes(finder).get(0);
    }

    public Checkboxes checkboxes() throws Exception {
        return new Checkboxes(elements(), htmlElementFactory());
    }

    public Checkbox checkbox(Symbol how, String what) throws Exception {
        return checkboxes(how, what).get(0);
    }

    public Checkboxes checkboxes(Symbol how, String what) throws Exception {
        return htmlElements(how, what).checkboxes();
    }

    public Checkbox checkbox(int index) throws Exception {
        return checkboxes().get(index);
    }

    public Checkbox checkbox(Symbol how, String what, String value) throws Exception {
        return htmlElements(SymbolFactory.value, value).checkbox(how, what);
    }

    public Checkbox checkbox(Symbol how, String what, int value) throws Exception {
        return checkbox(how, what, "" + value);
    }

    public SelectLists selectLists(Finder... finder) throws Exception {
        return htmlElements(finder).selectLists();
    }

    public SelectList selectList(Finder... finder) throws Exception {
        return selectLists(finder).get(0);
    }

    public SelectLists selectLists() throws Exception {
        return new SelectLists(elements(), htmlElementFactory());
    }

    public SelectList selectList(Symbol how, String what) throws Exception {
        return selectLists(how, what).get(0);
    }

    public SelectLists selectLists(Symbol how, String what) throws Exception {
        return htmlElements(how, what).selectLists();
    }

    public SelectList selectList(int index) throws Exception {
        return selectLists().get(index);
    }

    public SelectList selectList(String value) throws Exception {
        return selectList(FinderFactory.attribute("value", value));
    }

    public Images images(Finder... finder) throws Exception {
        return htmlElements(finder).images();
    }

    public Image image(Finder... finder) throws Exception {
        return images(finder).get(0);
    }

    public Images images() throws Exception {
        return new Images(elements(), htmlElementFactory());
    }

    public Image image(Symbol how, String what) throws Exception {
        return images(how, what).get(0);
    }

    public Images images(Symbol how, String what) throws Exception {
        return htmlElements(how, what).images();
    }

    public Image image(int index) throws Exception {
        return images().get(index);
    }

    public Divs divs(Finder... finder) throws Exception {
        return htmlElements(finder).divs();
    }

    public Div div(Finder... finder) throws Exception {
        return divs(finder).get(0);
    }

    public Divs divs() throws Exception {
        return new Divs(elements(), htmlElementFactory());
    }

    public Div div(Symbol how, String what) throws Exception {
        return divs(how, what).get(0);
    }

    public Divs divs(Symbol how, String what) throws Exception {
        return htmlElements(how, what).divs();
    }

    public Div div(int index) throws Exception {
        return divs().get(index);
    }

    public Spans spans(Finder... finder) throws Exception {
        return htmlElements(finder).spans();
    }

    public Span span(Finder... finder) throws Exception {
        return spans(finder).get(0);
    }

    public Spans spans() throws Exception {
        return new Spans(elements(), htmlElementFactory());
    }

    public Span span(Symbol how, String what) throws Exception {
        return spans(how, what).get(0);
    }

    public Spans spans(Symbol how, String what) throws Exception {
        return htmlElements(how, what).spans();
    }

    public Span span(int index) throws Exception {
        return spans().get(index);
    }

    public Frames frames(Finder... finder) throws Exception {
        return htmlElements(finder).frames();
    }

    public Frame frame(Finder... finder) throws Exception {
        return frames(finder).get(0);
    }

    public Frames frames() throws Exception {
        return new Frames(elements(), htmlElementFactory());
    }

    public Frame frame(Symbol how, String what) throws Exception {
        return frames(how, what).get(0);
    }

    public Frames frames(Symbol how, String what) throws Exception {
        return htmlElements(how, what).frames();
    }

    public Frame frame(int index) throws Exception {
        return frames().get(index);
    }

    public Frame frame(String name) throws Exception {
        return frame(FinderFactory.attribute("name", name));
    }

    public Forms forms(Finder... finder) throws Exception {
        return htmlElements(finder).forms();
    }

    public Form form(Finder... finder) throws Exception {
        return forms(finder).get(0);
    }

    public Forms forms() throws Exception {
        return new Forms(elements(), htmlElementFactory());
    }

    public Form form(Symbol how, String what) throws Exception {
        return forms(how, what).get(0);
    }

    public Forms forms(Symbol how, String what) throws Exception {
        return htmlElements(how, what).forms();
    }

    public Form form(int index) throws Exception {
        return forms().get(index);
    }

    public Form form(String name) throws Exception {
        return form(FinderFactory.attribute("name", name));
    }

    public FileFields fileFields(Finder... finder) throws Exception {
        return htmlElements(finder).fileFields();
    }

    public FileField fileField(Finder... finder) throws Exception {
        return fileFields(finder).get(0);
    }

    public FileFields fileFields() throws Exception {
        return new FileFields(elements(), htmlElementFactory());
    }

    public FileField fileField(Symbol how, String what) throws Exception {
        return fileFields(how, what).get(0);
    }

    public FileFields fileFields(Symbol how, String what) throws Exception {
        return htmlElements(how, what).fileFields();
    }

    public FileField fileField(int index) throws Exception {
        return fileFields().get(index);
    }

    public Tables tables(Finder... finder) throws Exception {
        return htmlElements(finder).tables();
    }

    public Table table(Finder... finder) throws Exception {
        return tables(finder).get(0);
    }

    public Tables tables() throws Exception {
        return new Tables(elements(), htmlElementFactory());
    }

    public Table table(Symbol how, String what) throws Exception {
        return tables(how, what).get(0);
    }

    public Tables tables(Symbol how, String what) throws Exception {
        return htmlElements(how, what).tables();
    }

    public Table table(int index) throws Exception {
        return tables().get(index);
    }

    public TableRows rows(Finder... finder) throws Exception {
        return htmlElements(finder).rows();
    }

    public TableRow row(Finder... finder) throws Exception {
        return rows(finder).get(0);
    }

    public TableRows rows() throws Exception {
        return new TableRows(elements(), htmlElementFactory());
    }

    public TableRow row(Symbol how, String what) throws Exception {
        return rows(how, what).get(0);
    }

    public TableRows rows(Symbol how, String what) throws Exception {
        return htmlElements(how, what).rows();
    }

    public TableRow row(int index) throws Exception {
        return rows().get(index);
    }

    public TableCells cells(Finder... finder) throws Exception {
        return htmlElements(finder).cells();
    }

    public TableCell cell(Finder... finder) throws Exception {
        return cells(finder).get(0);
    }

    public TableCells cells() throws Exception {
        return new TableCells(elements(), htmlElementFactory());
    }

    public TableCell cell(Symbol how, String what) throws Exception {
        return cells(how, what).get(0);
    }

    public TableCells cells(Symbol how, String what) throws Exception {
        return htmlElements(how, what).cells();
    }

    public TableCell cell(int index) throws Exception {
        return cells().get(index);
    }

    public TableBodies bodies(Finder... finder) throws Exception {
        return htmlElements(finder).bodies();
    }

    public TableBody body(Finder... finder) throws Exception {
        return bodies(finder).get(0);
    }

    public TableBodies bodies() throws Exception {
        return new TableBodies(elements(), htmlElementFactory());
    }

    public TableBody body(Symbol how, String what) throws Exception {
        return bodies(how, what).get(0);
    }

    public TableBodies bodies(Symbol how, String what) throws Exception {
        return htmlElements(how, what).bodies();
    }

    public TableBody body(int index) throws Exception {
        return bodies().get(index);
    }

    public Options options(Finder... finder) throws Exception {
        return htmlElements(finder).options();
    }

    public Option option(Finder... finder) throws Exception {
        return options(finder).get(0);
    }

    public Options options() throws Exception {
        return new Options(elements(), htmlElementFactory());
    }

    public Option option(Symbol how, String what) throws Exception {
        return options(how, what).get(0);
    }

    public Options options(Symbol how, String what) throws Exception {
        return htmlElements(how, what).options();
    }

    public Option option(int index) throws Exception {
        return options().get(index);
    }

    public HtmlElement htmlElement(Finder... finder) throws Exception {
        return htmlElements(finder).get(0);
    }

    public HtmlElements htmlElements() throws Exception {
        Debug.getInstance().println("Begin BaseHtmlFinder.htmlElements()");
        HtmlElements hs = new HtmlElements(elements(), htmlElementFactory());
        Debug.getInstance().println("End BaseHtmlFinder.htmlElements()");
        return hs;
    }

    public HtmlElement htmlElement(Symbol how, String what) throws Exception {
        return htmlElements(how, what).get(0);
    }

    public HtmlElements htmlElements(Symbol how, String what) throws Exception {
        return htmlElements(how.newFinder(what));
    }

    public HtmlElement htmlElement(int index) throws Exception {
        return htmlElements().get(index);
    }

}
