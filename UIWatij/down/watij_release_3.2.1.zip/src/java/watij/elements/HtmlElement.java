package watij.elements;

import watij.Container;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 3:40:30 PM
 * To change this template use File | Settings | File Templates.
 */
public interface HtmlElement extends Container {

    //attributes
    public boolean disabled() throws Exception;

    public String id() throws Exception;

    public String name() throws Exception;

    public String title() throws Exception;

    public String className() throws Exception;

    public String type() throws Exception;

    public String value() throws Exception;

    public String style() throws Exception;

    //methods
    public void click() throws Exception;

    public void fireEvent(String event) throws Exception;

    public boolean enabled() throws Exception;

    public boolean exists() throws Exception;

    public void flash() throws Exception;

    public void focus() throws Exception;

    public Object getOLEObject() throws Exception;

    public String html() throws Exception;

    //Additional functionality
    public void dblClick() throws Exception;

    public String innerText() throws Exception;

    public String text() throws Exception;

    public void show() throws Exception;
}
