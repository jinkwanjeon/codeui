package watij.elements;

import org.w3c.dom.Element;
import watij.finders.AttributeFinder;
import watij.finders.TagFinder;
import watij.utilities.Utils;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 16, 2006
 * Time: 2:36:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class TextFields extends HtmlElementCollections<TextField> {

    public TextFields(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected TextField get(Element element) throws Exception {
        if (element != null && matchesTextArea(element)) {
            return htmlElementFactory().textArea(element);
        }
        return htmlElementFactory().textField(element);
    }

    private boolean matchesTextArea(Element element) throws Exception {
        return new TagFinder("textarea").matches(element);
    }

    public boolean matches(Element element) throws Exception {

        if (new TagFinder("textarea").matches(element)) {
            return true;
        }
        if (new TagFinder("input").matches(element)) {
            if (Utils.isEmpty(element.getAttribute("type")) ||
                    new AttributeFinder("type", "text").matches(element) ||
                    new AttributeFinder("type", "password").matches(element)) {
                return true;
            }
        }
        return false;
    }

}
