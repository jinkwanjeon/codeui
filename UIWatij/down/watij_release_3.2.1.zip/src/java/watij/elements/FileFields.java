package watij.elements;

import org.w3c.dom.Element;
import watij.finders.AttributeFinder;
import watij.finders.TagFinder;

import java.util.List;

public class FileFields extends HtmlElementCollections<FileField> {

    public FileFields(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected FileField get(Element element) throws Exception {
        return htmlElementFactory().fileField(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("input").matches(element) && new AttributeFinder("type", "file").matches(element);
    }
}

