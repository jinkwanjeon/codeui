package watij.elements;

public interface Table extends TableBody {

}
