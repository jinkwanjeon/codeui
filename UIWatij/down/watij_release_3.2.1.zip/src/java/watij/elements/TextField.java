package watij.elements;

import watij.finders.Symbol;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 3:39:28 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TextField extends HtmlElement {

    public void append(String append) throws Exception;

    public void assertNotReadOnly() throws Exception;

    public void clear() throws Exception;

    public void dragContentsTo(Symbol destinationHow, String destinationWhat) throws Exception;

    public String getContents() throws Exception;

    public int maxLength() throws Exception;

    public boolean readOnly() throws Exception;

    public void set(String value) throws Exception;

    public int size() throws Exception;

    public boolean verifyContains(String what) throws Exception;

    //Additional
    public String get() throws Exception;

}
