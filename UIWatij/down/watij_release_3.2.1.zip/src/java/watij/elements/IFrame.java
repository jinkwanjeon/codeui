package watij.elements;

public interface IFrame extends Frame {
}
