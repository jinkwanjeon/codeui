package watij.elements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:25:28 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RadioCheckCommon extends HtmlElement {

    public boolean checked() throws Exception;

    public void clear() throws Exception;

    public boolean getState() throws Exception;

    public boolean isSet() throws Exception;

    public void set() throws Exception;

}
