package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

public class Options extends HtmlElementCollections<Option> {

    public Options(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Option get(Element element) throws Exception {
        return htmlElementFactory().option(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("option").matches(element);
    }
}
