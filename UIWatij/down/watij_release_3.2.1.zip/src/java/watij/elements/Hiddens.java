package watij.elements;

import org.w3c.dom.Element;
import watij.finders.AttributeFinder;
import watij.finders.TagFinder;

import java.util.List;

public class Hiddens extends HtmlElementCollections<Hidden> {

    public Hiddens(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Hidden get(Element element) throws Exception {
        return htmlElementFactory().hidden(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("input").matches(element) && new AttributeFinder("type", "hidden").matches(element);
    }
}
