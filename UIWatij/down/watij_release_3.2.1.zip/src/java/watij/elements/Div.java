package watij.elements;

public interface Div extends HtmlElement {
}
