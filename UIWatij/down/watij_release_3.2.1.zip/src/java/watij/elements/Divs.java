package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

public class Divs extends HtmlElementCollections<Div> {

    public Divs(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Div get(Element element) throws Exception {
        return htmlElementFactory().div(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("div").matches(element);
    }
}
