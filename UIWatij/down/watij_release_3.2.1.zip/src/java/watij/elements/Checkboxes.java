package watij.elements;

import org.w3c.dom.Element;
import watij.finders.AttributeFinder;
import watij.finders.TagFinder;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:26:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class Checkboxes extends HtmlElementCollections<Checkbox> {

    public Checkboxes(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Checkbox get(Element element) throws Exception {
        return htmlElementFactory().checkbox(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("input").matches(element) && new AttributeFinder("type", "checkbox").matches(element);
    }
}
