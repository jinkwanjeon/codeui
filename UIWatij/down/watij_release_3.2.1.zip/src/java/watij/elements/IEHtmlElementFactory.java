package watij.elements;

import com.jniwrapper.win32.ie.WebBrowser;
import org.w3c.dom.Element;
import watij.runtime.ie.*;

public class IEHtmlElementFactory implements HtmlElementFactory {

    IE ie;

    public IEHtmlElementFactory(IE ie) {
        this.ie = ie;
    }

    public HtmlElement htmlElement(Element element) throws Exception {
        return new IEHtmlElement(element, ie);
    }

    public Button button(Element element) throws Exception {
        return new IEButton(element, ie);
    }

    public Checkbox checkbox(Element element) throws Exception {
        return new IECheckbox(element, ie);
    }

    public Div div(Element element) throws Exception {
        return new IEDiv(element, ie);
    }

    public FileField fileField(Element element) throws Exception {
        return new IEFileField(element, ie);
    }

    public Form form(Element element) throws Exception {
        return new IEForm(element, ie);
    }

    public Frame frame(Element element) throws Exception {
        return new IEFrame(element, ie);
    }

    public Hidden hidden(Element element) throws Exception {
        return new IEHidden(element, ie);
    }

    public IFrame iframe(Element element) throws Exception {
        return new IEIFrame(element, ie);
    }

    public Image image(Element element) throws Exception {
        return new IEImage(element, ie);
    }

    public Label label(Element element) throws Exception {
        return new IELabel(element, ie);
    }

    public Link link(Element element) throws Exception {
        return new IELink(element, ie);
    }

    public Option option(Element element) throws Exception {
        return new IEOption(element, ie);
    }

    public Radio radio(Element element) throws Exception {
        return new IERadio(element, ie);
    }

    public SelectList selectList(Element element) throws Exception {
        return new IESelectList(element, ie);
    }

    public Span span(Element element) throws Exception {
        return new IESpan(element, ie);
    }

    public Table table(Element element) throws Exception {
        return new IETable(element, ie);
    }

    public TableBody tableBody(Element element) throws Exception {
        return new IETableBody(element, ie);
    }

    public TableCell tableCell(Element element) throws Exception {
        return new IETableCell(element, ie);
    }

    public TableRow tableRow(Element element) throws Exception {
        return new IETableRow(element, ie);
    }

    public TextArea textArea(Element element) throws Exception {
        return new IETextArea(element, ie);
    }

    public TextField textField(Element element) throws Exception {
        return new IETextField(element, ie);
    }
}
