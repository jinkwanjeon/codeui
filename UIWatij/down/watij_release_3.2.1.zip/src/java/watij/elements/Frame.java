package watij.elements;

public interface Frame extends HtmlElement {
    public boolean containsText(String textOrRegex) throws Exception;

    public String title() throws Exception;
}
