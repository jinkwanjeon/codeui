package watij.elements;

import org.w3c.dom.Element;

import java.util.List;

public class HtmlElements extends HtmlElementCollections<HtmlElement> {

    public HtmlElements(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected HtmlElement get(Element element) throws Exception {
        return htmlElementFactory().htmlElement(element);
    }

    protected void filter() throws Exception {
        //do nothing...no need to filter
    }

    public boolean matches(Element element) throws Exception {
        return true;
    }
}