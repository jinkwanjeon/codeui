package watij.elements;

public interface Form extends HtmlElement {

    public void submit() throws Exception;
}
