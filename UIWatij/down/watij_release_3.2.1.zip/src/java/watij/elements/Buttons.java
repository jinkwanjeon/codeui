package watij.elements;

import org.w3c.dom.Element;
import watij.finders.AttributeFinder;
import watij.finders.TagFinder;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 5:23:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class Buttons extends HtmlElementCollections<Button> {

    public Buttons(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Button get(Element element) throws Exception {
        return htmlElementFactory().button(element);
    }

    public boolean matches(Element element) throws Exception {
        return (new TagFinder("input").matches(element) && matchesAttribute(element))
                || new TagFinder("button").matches(element);
    }

    protected boolean matchesAttribute(Element element) throws Exception {
        return new AttributeFinder("type", "submit").matches(element) ||
                new AttributeFinder("type", "button").matches(element) ||
                new AttributeFinder("type", "image").matches(element) ||
                new AttributeFinder("type", "reset").matches(element);
    }

}
