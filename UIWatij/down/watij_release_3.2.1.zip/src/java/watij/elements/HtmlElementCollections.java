package watij.elements;

import org.w3c.dom.Element;
import watij.BaseHtmlFinder;
import watij.utilities.Debug;
import watij.finders.Finder;
import watij.finders.Matcher;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 16, 2006
 * Time: 2:36:26 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class HtmlElementCollections<HtmlElement> extends BaseHtmlFinder implements Iterable<HtmlElement>, Matcher {

    HtmlElementFactory htmlElementFactory;
    List<Element> list;

    protected HtmlElementCollections(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        this.list = list;
        this.htmlElementFactory = htmlElementFactory;
        filter();
    }

    protected abstract HtmlElement get(Element element) throws Exception;

    protected HtmlElementFactory htmlElementFactory() {
        return htmlElementFactory;
    }

    public List<Element> elements() throws Exception {
        return list;
    }

    public HtmlElement get(int index) throws Exception {
        return get(index >= list.size() ? null : list.get(index));
    }

    protected void filter() throws Exception {
        List<Element> newList = new ArrayList<Element>();
        for (int i = 0; i < list.size(); i++) {
            Element element = list.get(i);
            if (matches(element)) {
                newList.add(element);
            }
        }
        list = newList;
    }

    public HtmlElements htmlElements(Finder... finder) throws Exception {
        return find(elements(),finder);
    }

    public int length() throws Exception {
        return list.size();
    }

    public Iterator<HtmlElement> iterator() {
        List<HtmlElement> htmlElementList = new ArrayList<HtmlElement>();
        for (Element element : list) {
            try {
                htmlElementList.add(get(element));
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
        return htmlElementList.iterator();
    }

    public void show() {
        System.out.println(toString());
    }

    public void flash() throws Exception {
        ThreadGroup flashGroup = new ThreadGroup("FlashThreadGroup");
        for (int i = 0; i < length(); i++) {
            final int count = i;
            new Thread(flashGroup, new Runnable() {
                public void run() {
                    try {
                        ((watij.elements.HtmlElement) get(count)).flash();
                    } catch (Exception e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                }
            }).start();
        }
        while (flashGroup.activeCount() > 0) {
            Thread.sleep(100);
        }
    }

    public String toString() {
        Debug.getInstance().println("Begin HtmlElementCollections.toString()");
        Debug.getInstance().println("list.size() = "+list.size());
        StringBuffer s = new StringBuffer();
        s.append("\n");
        s.append("[");
        for (int i = 0; i < list.size(); i++) {
            HtmlElement htmlElement = null;
            try {
                htmlElement = get(i);
            } catch (Exception e) {
            }
            Debug.getInstance().println("about to call toString on element i="+i);
            s.append("\t").append(htmlElement.toString());
            if (i < list.size() - 1) {
                s.append(",");
            }
        }
        s.append("\n");
        s.append("]");
        Debug.getInstance().println("End HtmlElementCollections.toString()");
        return s.toString();
    }
}
