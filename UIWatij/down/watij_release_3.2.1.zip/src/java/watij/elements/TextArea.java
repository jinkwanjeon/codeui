package watij.elements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 3:55:30 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TextArea extends TextField {

    public String value() throws Exception;
}
