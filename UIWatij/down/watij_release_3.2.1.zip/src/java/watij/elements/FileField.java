package watij.elements;

public interface FileField extends TextField {

    void set(String value) throws Exception;
}
