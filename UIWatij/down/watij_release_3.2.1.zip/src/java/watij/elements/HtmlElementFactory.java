package watij.elements;

import org.w3c.dom.Element;

public interface HtmlElementFactory {
    HtmlElement htmlElement(Element element) throws Exception;

    Button button(Element element) throws Exception;

    Checkbox checkbox(Element element) throws Exception;

    Div div(Element element) throws Exception;

    FileField fileField(Element element) throws Exception;

    Form form(Element element) throws Exception;

    Frame frame(Element element) throws Exception;

    Hidden hidden(Element element) throws Exception;

    IFrame iframe(Element element) throws Exception;

    Image image(Element element) throws Exception;

    Label label(Element element) throws Exception;

    Link link(Element element) throws Exception;

    Option option(Element element) throws Exception;

    Radio radio(Element element) throws Exception;

    SelectList selectList(Element element) throws Exception;

    Span span(Element element) throws Exception;

    Table table(Element element) throws Exception;

    TableBody tableBody(Element element) throws Exception;

    TableCell tableCell(Element element) throws Exception;

    TableRow tableRow(Element element) throws Exception;

    TextArea textArea(Element element) throws Exception;

    TextField textField(Element element) throws Exception;
}
