package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

public class Images extends HtmlElementCollections<Image> {

    public Images(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Image get(Element element) throws Exception {
        return htmlElementFactory().image(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("img").matches(element);
    }

}
