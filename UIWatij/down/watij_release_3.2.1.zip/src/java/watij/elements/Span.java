package watij.elements;

public interface Span extends HtmlElement {
}
