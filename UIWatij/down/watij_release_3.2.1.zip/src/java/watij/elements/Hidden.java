package watij.elements;

public interface Hidden extends TextField {
}
