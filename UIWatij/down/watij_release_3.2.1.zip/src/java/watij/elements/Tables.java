package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

public class Tables extends HtmlElementCollections<Table> {

    public Tables(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Table get(Element element) throws Exception {
        return htmlElementFactory().table(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("table").matches(element);
    }
}
