package watij.elements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:25:44 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Radio extends RadioCheckCommon {
}
