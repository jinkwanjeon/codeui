package watij.elements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 6:51:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Link extends HtmlElement {
    public String type() throws Exception;

    public String href() throws Exception;

    public boolean linkHasImage() throws Exception;
}
