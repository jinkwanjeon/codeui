package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 12:03:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class Labels extends HtmlElementCollections<Label> {

    public Labels(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Label get(Element element) throws Exception {
        return htmlElementFactory().label(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("label").matches(element);
    }
}
