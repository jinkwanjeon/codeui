package watij.elements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 19, 2006
 * Time: 11:49:57 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Label extends HtmlElement {

    public String type() throws Exception;

    public String htmlFor() throws Exception;
}
