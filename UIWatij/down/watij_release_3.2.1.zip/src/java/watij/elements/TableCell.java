package watij.elements;

public interface TableCell extends HtmlElement {
    public int colspan() throws Exception;
}
