package watij.elements;

public interface TableRow extends HtmlElement {
    public int columnCount() throws Exception;

    public TableCell cell(int cellIndex) throws Exception;
}
