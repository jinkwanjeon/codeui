package watij.elements;

public interface Image extends HtmlElement {

    public String alt() throws Exception;

    public String type() throws Exception;

    public String fileCreatedDate() throws Exception;

    public String src() throws Exception;

    public int fileSize() throws Exception;

    public int height() throws Exception;

    public int width() throws Exception;

    public boolean hasLoaded() throws Exception;

    public void save(String path) throws Exception;
}
