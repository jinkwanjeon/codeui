package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 7:05:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class Links extends HtmlElementCollections<Link> {
    public Links(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Link get(Element element) throws Exception {
        return htmlElementFactory().link(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("a").matches(element);
    }
}
