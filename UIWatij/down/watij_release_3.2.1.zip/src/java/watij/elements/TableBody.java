package watij.elements;

public interface TableBody extends HtmlElement {
    public int rowCount() throws Exception;

    public int columnCount() throws Exception;

    public int columnCount(int index) throws Exception;

    public TableRow row(int rowIndex) throws Exception;

    public TableCell cell(int rowIndex, int cellIndex) throws Exception;
}
