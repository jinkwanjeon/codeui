package watij.elements;

import org.w3c.dom.Element;
import watij.finders.AttributeFinder;
import watij.finders.TagFinder;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:26:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class Radios extends HtmlElementCollections<Radio> {

    public Radios(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Radio get(Element element) throws Exception {
        return htmlElementFactory().radio(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("input").matches(element) && new AttributeFinder("type", "radio").matches(element);
    }
}
