package watij.elements;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:22:59 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Checkbox extends RadioCheckCommon {
    public void set(boolean setOrClear) throws Exception;
}
