package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

public class Frames extends HtmlElementCollections<Frame> {

    public Frames(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Frame get(Element element) throws Exception {
        if (element != null && matchesIFrame(element)) {
            return htmlElementFactory().iframe(element);
        }
        return htmlElementFactory().frame(element);
    }

    public boolean matches(Element element) throws Exception {
        return matchesFrame(element) || matchesIFrame(element);
    }

    private boolean matchesIFrame(Element element) throws Exception {
        return new TagFinder("iframe").matches(element);
    }

    private boolean matchesFrame(Element element) throws Exception {
        return new TagFinder("frame").matches(element);
    }
}
