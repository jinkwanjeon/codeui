package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

public class Spans extends HtmlElementCollections<Span> {
    public Spans(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected Span get(Element element) throws Exception {
        return htmlElementFactory().span(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("span").matches(element);
    }
}
