package watij.elements;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 9:19:39 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SelectList extends HtmlElement {

    public void clearSelection() throws Exception;

    public List<String> getAllContents() throws Exception;

    public List<String> getSelectedItems() throws Exception;

    public void select(String item) throws Exception;

    public void selectValue(String item) throws Exception;

}
