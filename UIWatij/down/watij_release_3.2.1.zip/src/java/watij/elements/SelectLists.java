package watij.elements;

import org.w3c.dom.Element;
import watij.finders.TagFinder;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 9:50:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SelectLists extends HtmlElementCollections<SelectList> {
    public SelectLists(List<Element> list, HtmlElementFactory htmlElementFactory) throws Exception {
        super(list, htmlElementFactory);
    }

    protected SelectList get(Element element) throws Exception {
        return htmlElementFactory().selectList(element);
    }

    public boolean matches(Element element) throws Exception {
        return new TagFinder("select").matches(element);
    }
}
