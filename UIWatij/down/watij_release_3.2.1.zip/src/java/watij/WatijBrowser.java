package watij;

import watij.elements.HtmlElement;
import watij.finders.Symbol;
import watij.dialogs.AlertDialog;
import watij.dialogs.ModalDialog;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 14, 2006
 * Time: 5:54:56 PM
 * To change this template use File | Settings | File Templates.
 */
public interface WatijBrowser extends Container {

    //Additional Functionality

    public AlertDialog alertDialog() throws Exception;

    public void waitUntilReady() throws Exception;

    public ModalDialog modalDialog() throws Exception;

    public void navigate(String url) throws Exception;

    public WatijBrowser childBrowser() throws Exception;

    public WatijBrowser childBrowser(int index) throws Exception;

    public int childBrowserCount() throws Exception;

    public void screenCapture(String fullyQualifiedFileName_PngFormat) throws Exception;

    public void screenCapture(String fullyQualifiedFileName, String format) throws Exception;

    public void width(int width) throws Exception;

    public void height(int height) throws Exception;

    public int width() throws Exception;

    public int height() throws Exception;

    public Object executeScript(String script) throws Exception;

    public void show() throws Exception;

    public HtmlElement active() throws Exception;

    public void setAdditionalHttpHeaders(String headers) throws Exception;


    //Public Class methods
    public void attach(Symbol how, String what) throws Exception;

    public void start(String url) throws Exception;

    public void start() throws Exception;

    //Attributes
    public List<String> urlList() throws Exception;

    //Public Instance methods
    public void addChecker(Object checker) throws Exception; //!?

    public void attachInit(Symbol how, String what) throws Exception; //!?

    public void back() throws Exception;

    public void bringToFront() throws Exception;

    public void checkForHttpError(WatijBrowser watijBrowser) throws Exception; //!?

    public void clearUrlList() throws Exception;

    public void close() throws Exception;

    public boolean containsText(String textOrRegex) throws Exception;

    public Object dir() throws Exception; //!?

    public void disableChecker(Object checker) throws Exception; //!?

    public void focus() throws Exception;

    public void forward() throws Exception;

    public boolean isFront() throws Exception;

    public void goTo(String url) throws Exception;

    public void log(String what) throws Exception;

    public void maximize() throws Exception;

    public void minimize() throws Exception;

    public void refresh() throws Exception;

    public void restore() throws Exception;

    public void runErrorChecks() throws Exception; //!?

    public void sendKeys(String keyString) throws Exception;

    public void sendKeys(String keyString, boolean blocking) throws Exception;

    public void sendKeys(String title, String keyString) throws Exception;

    public void sendKeys(String title, String keyString, boolean blocking) throws Exception;

    public void setFastSpeed() throws Exception;

    public void setSlowSpeed() throws Exception;

    public String status() throws Exception;

    public String text() throws Exception;

    public String title() throws Exception;

    public String url() throws Exception;

//Instead of supporting the following methods will added the show method on
    //this class and the HtmlElement class and the HtmlElementCollections class
    //Also added the active method to return the active HtmlElement
//    public void showActive() throws Exception;
//
//    public void showAllObjects() throws Exception;
//
//    public void showDivs() throws Exception;
//
//    public void showForms() throws Exception;
//
//    public void showFrames() throws Exception;
//
//    public void showImages() throws Exception;
//
//    public void showLabels() throws Exception;
//
//    public void showLinks() throws Exception;
//
//    public void showSpans() throws Exception;
//
//    public void showTables() throws Exception;


}
