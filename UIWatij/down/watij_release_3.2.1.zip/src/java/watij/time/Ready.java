package watij.time;

public interface Ready {
    boolean isReady() throws Exception;

    String getNotReadyReason();
}
