package watij.time;

import watij.utilities.Output;

public interface Timer {
    public void start();

    public long elapsed();

    public void outputElapsedTime(String prefix, Output output);

    public boolean isElapsed(long millis);
}
