package watij.time;

public class WaiterImpl implements Waiter {
    long timeout;
    long waitIncrement;
    Ready ready;
    Timer timer;

    public WaiterImpl(long timeout, long waitIncrement) {
        this.timeout = timeout;
        this.waitIncrement = waitIncrement;
    }

    public void waitUntil(Ready ready) throws Exception {
        timer = new TimerImpl();
        while (!ready.isReady()) {
            if (timer.isElapsed(timeout)) {
                throw new TimeException("Timeout exceeded.  Reason= " + ready.getNotReadyReason());
            }
            try {
                Thread.sleep(waitIncrement);
            } catch (InterruptedException e) {
                throw new TimeException(e);
            }
        }
    }
}
