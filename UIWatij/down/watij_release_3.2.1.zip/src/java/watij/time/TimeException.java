package watij.time;

public class TimeException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public TimeException() {
    }

    public TimeException(String s) {
        super(s);
    }

    public TimeException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public TimeException(Throwable throwable) {
        super(throwable);
    }
}
