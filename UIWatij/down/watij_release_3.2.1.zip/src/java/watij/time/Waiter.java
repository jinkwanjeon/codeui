package watij.time;

public interface Waiter {
    void waitUntil(Ready ready) throws Exception;
}
