package watij.time;

import watij.utilities.Output;

public class TimerImpl implements Timer {
    long start;

    public TimerImpl() {
        start();
    }

    public synchronized void start() {
        start = System.currentTimeMillis();
    }

    public synchronized long elapsed() {
        return System.currentTimeMillis() - start;
    }

    public synchronized boolean isElapsed(long millis) {
        return elapsed() > millis;
    }

    public void outputElapsedTime(String prefix, Output output) {
        output.println(prefix + "Elapsed Time = " + elapsed());
    }
}
