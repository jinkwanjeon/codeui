package watij.runtime;

public class MissingWayOfFindingObjectException extends Exception {
    public MissingWayOfFindingObjectException() {
    }

    public MissingWayOfFindingObjectException(String message) {
        super(message);
    }

    public MissingWayOfFindingObjectException(String message, Throwable cause) {
        super(message, cause);
    }

    public MissingWayOfFindingObjectException(Throwable cause) {
        super(cause);
    }
}
