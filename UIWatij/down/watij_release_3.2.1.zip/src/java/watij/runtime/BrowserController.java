package watij.runtime;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import watij.elements.TextField;

public interface BrowserController {

    TextField getTextField(Element element) throws Exception;


    void release();

    BrowserController getChildBrowser(int i) throws Exception;

    int getChildBrowserCount() throws Exception;

    int getDeepChildBrowserCount() throws Exception;

    void closeBrowser() throws Exception;

    void setJavaScriptCloseEnabled(boolean javaScriptClose) throws Exception;

    boolean isJavaScriptCloseEnabled() throws Exception;

    void click(Element element) throws Exception;

    void dblClick(Element element) throws Exception;

    void navigate(String url) throws Exception;

    void setText(Element inputText, String value) throws Exception;

    void setTextArea(Element textArea, String value) throws Exception;

    void check(Element radioOrCheckbox, boolean check) throws Exception;

    void select(Element option, boolean select) throws Exception;

    String getHtml() throws Exception;

    Document getDocument() throws Exception;

    String executeScript(String script) throws Exception;

    void sendKeys(String title, String keys) throws Exception;

    void clickBlocking(Element element) throws Exception;

    Object getNativeElement(Element element) throws Exception;
}
