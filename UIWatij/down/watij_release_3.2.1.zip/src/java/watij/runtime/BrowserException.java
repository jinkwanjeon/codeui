package watij.runtime;

public class BrowserException extends Exception {

    public BrowserException() {
    }

    public BrowserException(String message) {
        super(message);
    }

    public BrowserException(String message, Throwable cause) {
        super(message, cause);
    }

    public BrowserException(Throwable cause) {
        super(cause);
    }
}
