package watij.runtime;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 5:30:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class NotImplementedYetException extends Exception {

    public NotImplementedYetException() {
    }

    public NotImplementedYetException(String s) {
        super(s);
    }

    public NotImplementedYetException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public NotImplementedYetException(Throwable throwable) {
        super(throwable);
    }
}
