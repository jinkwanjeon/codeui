package watij.runtime;

public class NavigationException extends Exception {

    public NavigationException() {
    }

    public NavigationException(String s) {
        super(s);
    }

    public NavigationException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public NavigationException(Throwable throwable) {
        super(throwable);
    }

}
