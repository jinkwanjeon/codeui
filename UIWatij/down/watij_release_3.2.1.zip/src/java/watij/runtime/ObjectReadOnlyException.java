package watij.runtime;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 9:19:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class ObjectReadOnlyException extends Exception {
    public ObjectReadOnlyException() {
    }

    public ObjectReadOnlyException(String message) {
        super(message);
    }

    public ObjectReadOnlyException(String message, Throwable cause) {
        super(message, cause);
    }

    public ObjectReadOnlyException(Throwable cause) {
        super(cause);
    }
}
