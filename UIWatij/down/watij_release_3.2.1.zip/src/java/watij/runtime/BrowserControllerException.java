package watij.runtime;

public class BrowserControllerException extends Exception {
    public BrowserControllerException() {
    }

    public BrowserControllerException(String s) {
        super(s);
    }

    public BrowserControllerException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public BrowserControllerException(Throwable throwable) {
        super(throwable);
    }
}
