package watij.runtime;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 18, 2006
 * Time: 10:50:11 AM
 * To change this template use File | Settings | File Templates.
 */
public class UnknownObjectException extends Exception {
    public UnknownObjectException() {
    }

    public UnknownObjectException(String message) {
        super(message);
    }

    public UnknownObjectException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnknownObjectException(Throwable cause) {
        super(cause);
    }
}
