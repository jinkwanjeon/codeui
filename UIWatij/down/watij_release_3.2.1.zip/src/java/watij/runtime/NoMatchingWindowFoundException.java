package watij.runtime;

public class NoMatchingWindowFoundException extends Exception {
    public NoMatchingWindowFoundException() {
    }

    public NoMatchingWindowFoundException(String message) {
        super(message);
    }

    public NoMatchingWindowFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoMatchingWindowFoundException(Throwable cause) {
        super(cause);
    }
}
