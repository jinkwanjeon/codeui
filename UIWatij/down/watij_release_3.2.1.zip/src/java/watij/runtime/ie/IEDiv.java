package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Div;


public class IEDiv extends IEHtmlElement implements Div {
    public IEDiv(Element element, IE ie) throws Exception {
        super(element, ie);
    }
}
