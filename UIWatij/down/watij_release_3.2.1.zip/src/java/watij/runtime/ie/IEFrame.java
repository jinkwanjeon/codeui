package watij.runtime.ie;

import com.jniwrapper.win32.ie.WebBrowser;
import com.jniwrapper.win32.ie.dom.HTMLDocument;
import com.jniwrapper.win32.ie.dom.HTMLElement;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import watij.elements.Frame;
import watij.utilities.StringUtils;

public class IEFrame extends IEHtmlElement implements Frame {

    public IEFrame(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    protected Document document() throws Exception {
        return document(html());
    }

    public Element element() throws Exception {
        return document().getDocumentElement();
    }

    protected IE ie() throws Exception {
        return new IE((WebBrowser) htmlElement());
    }

    protected HTMLElement htmlElement() throws Exception {
        return find(element, ie.htmlDocument());
    }

    protected HTMLDocument htmlDocument() throws Exception {
        IE ie1 = new IE((WebBrowser) htmlElement());
        return ie1.htmlDocument();
    }

    public String html() throws Exception {
        return html(htmlDocument());
    }

    public boolean containsText(String textOrRegex) throws Exception {
        return StringUtils.matchesOrContains(textOrRegex, htmlDocument().getBody().getHTML());
    }

    public String title() throws Exception {
        return htmlDocument().getTitle();
    }
}
