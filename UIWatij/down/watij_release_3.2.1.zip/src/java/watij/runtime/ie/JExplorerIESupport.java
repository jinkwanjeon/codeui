package watij.runtime.ie;

import com.jniwrapper.Int32;
import com.jniwrapper.UInt32;
import com.jniwrapper.win32.automation.IDispatch;
import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.automation.impl.IDispatchImpl;
import com.jniwrapper.win32.automation.server.IDispatchVTBL;
import com.jniwrapper.win32.automation.types.BStr;
import com.jniwrapper.win32.automation.types.Variant;
import com.jniwrapper.win32.automation.types.VariantBool;
import com.jniwrapper.win32.com.IClassFactory;
import com.jniwrapper.win32.com.server.CoClassMetaInfo;
import com.jniwrapper.win32.com.server.IClassFactoryServer;
import com.jniwrapper.win32.com.types.ClsCtx;
import com.jniwrapper.win32.com.types.IID;
import com.jniwrapper.win32.ie.AuthenticateHandler;
import com.jniwrapper.win32.ie.BrowserSupport;
import com.jniwrapper.win32.ie.KeyFilter;
import com.jniwrapper.win32.ie.WebBrowser;
import com.jniwrapper.win32.ie.event.*;
import com.jniwrapper.win32.ole.IConnectionPoint;
import com.jniwrapper.win32.ole.IConnectionPointContainer;
import com.jniwrapper.win32.ole.impl.IConnectionPointContainerImpl;
import com.jniwrapper.win32.shdocvw.DWebBrowserEvents2;
import com.jniwrapper.win32.shdocvw.IWebBrowser2;
import com.jniwrapper.win32.shdocvw.InternetExplorer;
import com.jniwrapper.win32.shdocvw.impl.IWebBrowser2Impl;
import com.jniwrapper.win32.shdocvw.server.DWebBrowserEvents2Server;
import com.jniwrapper.win32.ui.Wnd;
import watij.time.Ready;
import watij.time.Waiter;
import watij.time.WaiterImpl;
import watij.utilities.Debug;

import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

public class JExplorerIESupport extends BrowserSupport {

    private String additionalHttpHeaders;
    List<JExplorerIESupport> childBrowsers;
    long hwnd;
    private static int _browsersIndex = 0;

    public JExplorerIESupport(OleMessageLoop oleMessageLoop) throws Exception {
        super(oleMessageLoop);
        super.initialize();
    }

    public JExplorerIESupport() throws Exception {
        this(createOleMessageLoop());
        createIWebBrowser2();
        setupIWebBrowser2();
    }

    public JExplorerIESupport(JExplorerIESupport parentIESupport) throws Exception {
        this(parentIESupport.getOleMessageLoop());
        createIWebBrowser2();
        setupIWebBrowser2();
        setParentBrowser(parentIESupport);
        parentIESupport.childBrowsers.add(this);
    }

    public JExplorerIESupport(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception {
        this(oleMessageLoop);
        setBrowser(iWebBrowser2);
        setupIWebBrowser2();
    }

    protected static OleMessageLoop createOleMessageLoop() {
        OleMessageLoop result = new OleMessageLoop("IESupportLoop." + _browsersIndex++);
        result.doStart();
        return result;
    }

    private void createIWebBrowser2() throws Exception {
        getOleMessageLoop().doInvokeAndWait(new Runnable() {
            public void run() {
                try {
                    IWebBrowser2 browser = InternetExplorer.create(ClsCtx.LOCAL_SERVER);
                    setBrowser(browser);
                } catch (Exception e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        });
    }

    private void setupIWebBrowser2() throws Exception {
        getOleMessageLoop().doInvokeLater(new Runnable() {
            public void run() {
                try {
                    setupListener(iWebBrowser2());
                    iWebBrowser2().setVisible(VariantBool.TRUE);
                    hwnd = iWebBrowser2().getHWND().getValue();
//                    waitForIWebBrowser2Initialized(iWebBrowser2());
                    childBrowsers = new ArrayList<JExplorerIESupport>();
                } catch (Exception e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        });
    }

//    private void waitForIWebBrowser2Initialized(IWebBrowser2 iWebBrowser2) throws Exception {
//        Thread.sleep(200);
//        while (true) {
//            try {
//                if (iWebBrowser2.isNull() || iWebBrowser2.getBusy().getBooleanValue()) {
//                    Thread.sleep(200);
//                    continue;
//                }
//            }
//            catch (Throwable t) {
//                t.printStackTrace();
//                continue;
//            }
//            break;
//        }
//    }

    public void waitForChildBrowser(final int i) throws Exception {
        Waiter waiter = new WaiterImpl(60000, 1000);
        waiter.waitUntil(new Ready() {
            public boolean isReady() {
                return childBrowsers.size() > i;
            }

            public String getNotReadyReason() {
                return "ChildBrowser does not exist yet";
            }
        });
    }

    public JExplorerIESupport getChildBrowser(int index) {
        return (JExplorerIESupport) childBrowsers.get(index);
    }

    protected int getChildBrowserSize() {
        return childBrowsers.size();
    }

    public IWebBrowser2 iWebBrowser2() {
        return (IWebBrowser2) getBrowserPeer();
    }

    private String getAdditionalHttpHeaders() {
        return additionalHttpHeaders;
    }

    public void setAdditionalHttpHeaders(String additionalHttpHeaders) {
        this.additionalHttpHeaders = additionalHttpHeaders;
    }

    public void setupListener(IWebBrowser2 iWebBrowser2) throws Exception {
        DWebBrowserEvents2Handler dWebBrowserEvents2Handler;

        // Create class factory server for our DWebBrowserEvents2Impl
        IClassFactoryServer server = new IClassFactoryServer(DWebBrowserEvents2Handler.class);
        server.registerInterface(IDispatch.class, new IDispatchVTBL(server));
        server.registerInterface(DWebBrowserEvents2.class, new IDispatchVTBL(server));
        server.setDefaultInterface(IDispatch.class);

        IClassFactory factory = server.createIClassFactory();

        // Create instance of DWebBrowserEvents2Handler with a class factory
        IDispatchImpl handler = new IDispatchImpl();
        factory.createInstance(null, handler.getIID(), handler);

        // Create IConnectionPointContainer to ActiveX object, which is embedded
        //into OleContainer
        IConnectionPointContainer connectionPointContainer = new IConnectionPointContainerImpl(iWebBrowser2);
        // Find a necessary connection point
        IConnectionPoint connectionPoint = connectionPointContainer.findConnectionPoint(new IID(DWebBrowserEvents2.INTERFACE_IDENTIFIER));

        // Advise our handler
        Int32 int32 = connectionPoint.advise(handler);

        dWebBrowserEvents2Handler = (DWebBrowserEvents2Handler) server.getInstances().get(0);
        dWebBrowserEvents2Handler.setIESupport(this);
    }

    public static class DWebBrowserEvents2Handler extends DWebBrowserEvents2Server {

        JExplorerIESupport ieSupport = null;

        public DWebBrowserEvents2Handler(CoClassMetaInfo coClassMetaInfo) {
            super(coClassMetaInfo);
        }

        public void setIESupport(JExplorerIESupport ieSupport) {
            this.ieSupport = ieSupport;
        }


        public void newWindow3(IDispatch /*[in,out]*/ ppDisp, VariantBool /*[in,out]*/ Cancel, UInt32 /*[in]*/ dwFlags, BStr /*[in]*/ bstrUrlContext, BStr /*[in]*/ bstrUrl) {
//            debug("IEController$DWebBrowserEvents2Handler.newWindow3");
            try {
                JExplorerIESupport newIESupport = new JExplorerIESupport(ieSupport);
                IWebBrowser2 browser = newIESupport.iWebBrowser2();
                browser.setRegisterAsBrowser(VariantBool.TRUE);
                ((IDispatchImpl) ppDisp).setValue(browser);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }

        /**
         * BeforeNavigate2 event handler.
         * <p/>
         * args[0] Object that evaluates to the top-level or frame
         * WebBrowser object corresponding to the navigation.
         * args[1] String expression that evaluates to the URL to
         * which the browser is navigating.
         * args[2] Flags
         * args[3] String expression that evaluates to the name of
         * the frame in which the resource will be displayed,
         * or Null if no named frame is targeted for the resource.
         * args[4] Data to send to the server if the HTTP POST transaction
         * is being used.
         * args[5] Value that specifies the additional HTTP headers to send to the
         * server (HTTP URLs only). The headers can specify such things as
         * the action required of the server, the type of data being passed
         * to the server, or a status code.
         * args[6] Boolean value that the container can set to True to cancel the
         * navigation operation, or to False to allow it to proceed.
         */
        private boolean hasNavigated = false;

        public void beforeNavigate2(IDispatch /*[in]*/ pDisp, Variant /*[in]*/ URL, Variant /*[in]*/ Flags, Variant /*[in]*/ TargetFrameName, Variant /*[in]*/ PostData, Variant /*[in]*/ Headers, VariantBool /*[in,out]*/ Cancel) {
//            debug("start IEController$DWebBrowserEvents2Handler.beforeNavigate2");
            if (ieSupport.getAdditionalHttpHeaders() != null && !hasNavigated) {
                String newAddHeaders = existingHeadersValue(Headers) + ieSupport.getAdditionalHttpHeaders();
                IWebBrowser2 iWebBrowser2 = new IWebBrowser2Impl(pDisp);
                iWebBrowser2.stop();
                iWebBrowser2.navigate2(new Variant(URL.getBstrVal()), new Variant(Flags.getIntVal()), new Variant(TargetFrameName.getBstrVal()), new Variant(PostData.getCiVal()), new Variant(newAddHeaders));
                Cancel.setBooleanValue(true);
                hasNavigated = true;
            }
//            debug("end IEController$DWebBrowserEvents2Handler.beforeNavigate2");
        }

        private String existingHeadersValue(Variant existingHeaders) {
            String string = existingHeaders.getBstrVal().getValue();
            return string == null ? "" : string;
        }

        /**
         * NavigateComplete2 event handler
         * <p/>
         * args[0] Object that evaluates to the top-level or frame
         * WebBrowser object corresponding to the navigation.
         * args[1] String that specifies the URL, Universal Naming Convention
         * (UNC) file name, or pointer to an item identifier list (PIDL)
         * of the loaded document.
         */

        public void navigateComplete2(IDispatch /*[in]*/ pDisp, Variant /*[in]*/ URL) {
            hasNavigated = false;
        }
    }

    protected Wnd getBrowserWindow() {
        return new Wnd(iWebBrowser2().getHWND().getValue());
    }

    public void addPropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removePropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNavigationListener(NavigationEventListener navigationEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeNavigationListener(NavigationEventListener navigationEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getNavigationListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addStatusListener(StatusEventListener statusEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeStatusListener(StatusEventListener statusEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getStatusListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setEventHandler(WebBrowserEventsHandler webBrowserEventsHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowserEventsHandler getEventHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setDialogEventHandler(DialogEventHandler dialogEventHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }


    public void setAuthenticateHandler(AuthenticateHandler authenticateHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public AuthenticateHandler getAuthenticateHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public DialogEventHandler getDialogEventHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setScriptErrorListener(ScriptErrorListener scriptErrorListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public ScriptErrorListener getScriptErrorListener() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void close() {
        try {
            iWebBrowser2().quit();
            Thread.sleep(100);
//            new WaiterImpl(5000, 200).waitUntil(new Ready() {
//
//                public boolean isReady() throws Exception {
//                    Debug.getInstance().println("closing");
//                    try {
//                        Debug.getInstance().println("" + iWebBrowser2().getHWND());
//                        return false;
//                    } catch (Throwable e) {
//                        if (Debug.isDebug()) {
//                            e.printStackTrace();
//                        }
//                        return true;
//                    }
//                }
//
//                public String getNotReadyReason() {
//                    return "iWebBrowser2 could not be closed.";
//                }
//            });
        } catch (Exception e1) {
            Debug.handleException(e1);
        }
        if (getParentBrowser() != null) {
            ((JExplorerIESupport) getParentBrowser()).childBrowsers.remove(this);
        }
    }

    public void setNewWindowHandler(NewWindowEventHandler newWindowEventHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public NewWindowEventHandler getNewWindowHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNewWindowListener(NewWindowEventListener newWindowEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeNewWindowListener(NewWindowEventListener newWindowEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getNewWindowListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setKeyFilter(KeyFilter keyFilter) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public KeyFilter getKeyFilter() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void trackChildren() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser getRecentChild() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser waitChildCreation() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser waitChildCreation(Runnable runnable) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    //    private synchronized static IWebBrowser2 createBrowserLocal() throws Exception {
//        StringBuffer command = new StringBuffer();
//        command.append("iexplore.exe");
//        command.append(" about:blank#" + (++allBrowserCount));
//        Runtime runtime = Runtime.getRuntime();
//        try {
//            runtime.exec(command.toString());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        return attachByUrl("about:blank#" + allBrowserCount).iWebBrowser2;
//    }
}
