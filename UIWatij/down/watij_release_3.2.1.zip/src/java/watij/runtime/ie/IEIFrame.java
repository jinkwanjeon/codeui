package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.IFrame;


public class IEIFrame extends IEFrame implements IFrame {

    public IEIFrame(Element element, IE ie) throws Exception {
        super(element, ie);
    }
}
