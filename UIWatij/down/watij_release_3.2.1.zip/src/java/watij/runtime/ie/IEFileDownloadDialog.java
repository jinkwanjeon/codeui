package watij.runtime.ie;

import com.jniwrapper.Function;
import com.jniwrapper.IntBool;
import com.jniwrapper.UInt;
import com.jniwrapper.win32.FunctionName;
import com.jniwrapper.win32.Msg;
import com.jniwrapper.win32.automation.types.BStr;
import com.jniwrapper.win32.ui.User32;
import com.jniwrapper.win32.ui.Wnd;
import watij.dialogs.FileDownloadDialog;
import watij.time.Ready;
import watij.time.WaiterImpl;
import watij.utilities.WatijResourceLoader;
import watij.utilities.WatijResources;

import java.io.File;
import java.util.List;

public class IEFileDownloadDialog implements FileDownloadDialog {

    Wnd fileDownloader;
    Wnd fileDownloadSaveAs;
    IE ie;

    public IEFileDownloadDialog(Wnd fileDownloader, Wnd fileDownloadSaveAs, IE ie) {
        this.fileDownloader = fileDownloader;
        this.fileDownloadSaveAs = fileDownloadSaveAs;
        this.ie = ie;
    }

    public static FileDownloadDialog findFileDownloadDialog(IE ie) throws Exception {
        Wnd fileDownloadSaveAs = IEUtil.waitDialogWnd(
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Title_FileDownload),
                "Button",
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Save));
        Wnd fileDownloader = fileDownloadSaveAs.getParent();
        return new IEFileDownloadDialog(fileDownloader, fileDownloadSaveAs, ie);
    }

    public String text() throws Exception {
        return IEUtil.getStaticText(fileDownloadSaveAs);
    }

    public String title() throws Exception {
        return fileDownloadSaveAs.getWindowText();
    }

    public void quit() throws Exception {
        int wm_quit = 0x0012;
        fileDownloadSaveAs.postMessage(wm_quit, 0, 0);
    }

    public boolean exists() throws Exception {
        return fileDownloader.isWindow();
    }

    public void cancel() throws Exception {
        Wnd wnd = IEUtil.waitDialogWnd(fileDownloadSaveAs, "Button",
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Cancel));
        IEUtil.clickWindowUntilGone(wnd, fileDownloadSaveAs);
    }

    public void open() throws Exception {
        final Wnd openButton = IEUtil.waitDialogWnd(fileDownloadSaveAs, "Button",
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Open));
        IEUtil.clickWindowUntilGone(openButton, fileDownloadSaveAs);
    }

    public void closeThisDialogBoxWhenDownloadCompletes(boolean close) throws Exception {
        Wnd checkbox = IEUtil.waitDialogWnd(fileDownloader, "Button",
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_CloseWhenComplete));
        IEUtil.debugWnd(checkbox, "checkbox");
        int bm_setcheck = 0x00F1;
        int bst_checked = 0x0001;
        int bst_unchecked = 0x0000;
        int doClose = close?bst_checked:bst_unchecked;
        checkbox.sendMessageEx(bm_setcheck, doClose, 0);
    }

    public void save(String fullPathAndFileName) throws Exception {
        IEUtil.debugWndChildren(fileDownloader, "HEHEHHE");

        File file = new File(fullPathAndFileName);
        final Wnd saveButton = IEUtil.waitDialogWnd(fileDownloadSaveAs, "Button",
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Save));

        new WaiterImpl(10000, 200).waitUntil(new Ready() {
            public boolean isReady() throws Exception {
                IEUtil.clickWindow(saveButton);
                return Wnd.findWindow(IEUtil.DIALOG_CLASSNAME,
                        WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Title_SaveAs)).isWindow();
            }

            public String getNotReadyReason() {
                return "Could not find 'Save As' dialog";
            }
        });

        Wnd saveAsWnd = IEUtil.waitDialogWnd(
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Title_SaveAs));
        List saveAsWndChildren = saveAsWnd.getChildWindows();
        for (int i = 0; i < saveAsWndChildren.size(); i++) {
            Wnd saveAsWndChild = (Wnd) saveAsWndChildren.get(i);
            if ("Edit".equals(saveAsWndChild.getWindowClassName())) {
                final Function sendMessage = User32.getInstance().getFunction(
                        new FunctionName("SendMessage").toString());
                IntBool result = new IntBool();
                sendMessage.invoke(result, saveAsWndChild, new UInt(Msg.WM_SETTEXT), new BStr(),
                        new BStr(fullPathAndFileName));
                if (file.exists()) {
                    file.delete();
                }
                IEUtil.clickWindowUntilGone(IEUtil.waitDialogWnd(saveAsWnd, "Button",
                        WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Save)), saveAsWnd);
            }
        }
    }

    public void close() throws Exception {
        if (!exists()) {
            throw new Exception("Download Dialog doesn't exist");
        }
        Wnd wnd = IEUtil.waitDialogWnd(fileDownloader, "Button",
                WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Close));
        IEUtil.clickWindowUntilGone(wnd, fileDownloader);
    }

    public void waitUntilDownloadComplete() throws Exception {
        new WaiterImpl(999999999, 200).waitUntil(new Ready() {

            public boolean isReady() throws Exception {
                if (!exists()) {
                    return true;
                }
                Wnd wnd = Wnd.findWindow(IEUtil.DIALOG_CLASSNAME,
                        WatijResourceLoader.getString(WatijResources.IEFileDownloadDialog_Title_DownloadComplete));
                IEUtil.debugWnd(wnd, "finding Download complete");
                return wnd.isWindow();
            }

            public String getNotReadyReason() {
                return "Could not find 'Download complete' dialog";
            }
        });
    }

}
