package watij.runtime.ie;

import com.jniwrapper.*;
import com.jniwrapper.win32.automation.IDispatch;
import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.automation.types.BStr;
import com.jniwrapper.win32.automation.types.Variant;
import com.jniwrapper.win32.com.IUnknown;
import com.jniwrapper.win32.com.types.ClsCtx;
import com.jniwrapper.win32.ie.IEAutomation;
import com.jniwrapper.win32.mshtml.IHTMLDocument2;
import com.jniwrapper.win32.mshtml.impl.IHTMLDocument2Impl;
import com.jniwrapper.win32.shdocvw.IShellWindows;
import com.jniwrapper.win32.shdocvw.IWebBrowser2;
import com.jniwrapper.win32.shdocvw.ShellWindows;
import com.jniwrapper.win32.shdocvw.impl.IWebBrowser2Impl;
import com.jniwrapper.win32.ui.SystemParametersInfo;
import com.jniwrapper.win32.ui.User32;
import com.jniwrapper.win32.ui.Wnd;
import watij.iwshruntimelibrary.IWshShell3;
import watij.iwshruntimelibrary.WshShell;
import watij.runtime.NoMatchingWindowFoundException;
import watij.time.Ready;
import watij.time.WaiterImpl;
import watij.utilities.*;

import java.util.List;

public class IEUtil {
    protected static final String DIALOG_CLASSNAME = "#32770";

    public static void debug(String s) {
        Debug.getInstance().println(s);
    }

    public static IUnknown bind(OleMessageLoop oleMessageLoop, final IUnknownFactory iUnknownFactory) throws Exception {
        return new IUnknownBinder(oleMessageLoop).bind(iUnknownFactory);
    }

    public static void stopAutoGC() throws Exception {
        NativeResourceCollector.getInstance().stop();
    }

    public static void startAutoGC() throws Exception {
        NativeResourceCollector.getInstance().start();
    }

    public static void switchToThisWindow(Wnd wnd) {
        //found new imp here: http://www.redbugtech.com/forums/viewtopic.php?t=74
        SystemParametersInfo.systemParametersInfo(new UInt(SystemParametersInfo.SPI_SETFOREGROUNDLOCKTIMEOUT), new UInt(0), new Pointer(new Pointer.Void()), new UInt(SystemParametersInfo.SPIF_SENDWININICHANGE | SystemParametersInfo.SPIF_UPDATEINIFILE));
        final Function showAsync = User32.getInstance().getFunction("ShowWindowAsync");
        showAsync.invoke(null, wnd, new Int(Wnd.ShowWindowCommand.SHOWNORMAL.getValue()));
        wnd.setForeground();
        SystemParametersInfo.systemParametersInfo(new UInt(SystemParametersInfo.SPI_SETFOREGROUNDLOCKTIMEOUT), new UInt(200000), new Pointer(new Pointer.Void()), new UInt(SystemParametersInfo.SPIF_SENDWININICHANGE | SystemParametersInfo.SPIF_UPDATEINIFILE));
    }

    protected static IWshShell3 IWshShell3(OleMessageLoop oleMessageLoop) throws Exception {
        return (IWshShell3) bind(oleMessageLoop, new IUnknownFactory() {
            public IUnknown create() throws Exception {
                return WshShell.create(ClsCtx.INPROC_SERVER);
            }
        });
    }

    public static void sendKeys(final String title, final String keys, boolean blocking, OleMessageLoop oleMessageLoop) throws Exception {
        if (blocking) {
            IWshShell3 iWshShell3 = IWshShell3(oleMessageLoop);
            Thread.sleep(200);
            sendKeys(iWshShell3, keys);
            Thread.sleep(200);
        } else {
            OleMessageLoop sendKeysMessageLoop = new OleMessageLoop("sendKeys");
            sendKeysMessageLoop.doStart();
            sendKeysMessageLoop.doInvokeLater(new Runnable() {
                public void run() {
                    try {
                        IWshShell3 iWshShell3 = WshShell.create(ClsCtx.INPROC_SERVER);
                        Thread.sleep(200);
                        sendKeys(iWshShell3, keys);
                        Thread.sleep(200);
                    } catch (Exception e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                }
            });
        }
    }

    private static void sendKeys(IWshShell3 iWshShell3, String keys) throws Exception {
        iWshShell3.sendKeys(new BStr(keys), new Variant(true));
    }

    protected static IEAutomation attach(final String titleOrUrl, final boolean url) throws Exception {
        IEAutomation ieAutomation = new IEAutomation();
        OleMessageLoop oleMessageLoop = ieAutomation.getOleMessageLoop();

        class AttachBrowserAction implements BrowserAction {
            IWebBrowser2 browser = null;

            public boolean perform(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception {
                Debug.getInstance().println("url=" + iWebBrowser2.getLocationURL().getValue());
                if (url && StringUtils.matchesOrEquals(titleOrUrl, iWebBrowser2.getLocationURL().getValue())) {
                    Debug.getInstance().println("Found Visible Browser By URL**");
                    browser = iWebBrowser2;
                    return false;
                } else {
                    IDispatch document = (IDispatch) oleMessageLoop.bindObject(iWebBrowser2.getDocument());
                    IHTMLDocument2 ihtmlDocument2 = (IHTMLDocument2) oleMessageLoop.bindObject(new IHTMLDocument2Impl(document));
                    Debug.getInstance().println("title=" + ihtmlDocument2.getTitle().getValue());
                    if (StringUtils.matchesOrEquals(titleOrUrl, ihtmlDocument2.getTitle().getValue())) {
                        Debug.getInstance().println("Found Visible Browser By Title**");
                        browser = iWebBrowser2;
                        return false;
                    }
                }
                return true;
            }
        }
        ;

        AttachBrowserAction attachBrowserAction = new AttachBrowserAction();
        executeOnAllBrowsers(attachBrowserAction, oleMessageLoop);

        if (attachBrowserAction.browser == null) {
            throw new NoMatchingWindowFoundException("Could not find browser");
        }
        ieAutomation.close();
        ieAutomation.setBrowser(attachBrowserAction.browser);
        return ieAutomation;
    }

    protected static void executeOnAllBrowsers(BrowserAction browserAction, OleMessageLoop oleMessageLoop) throws Exception {

        IWebBrowser2 browser;
        IShellWindows iShellWindows = (IShellWindows) IEUtil.bind(oleMessageLoop, new IUnknownFactory() {
            public IUnknown create() throws Exception {
                return ShellWindows.create(ClsCtx.INPROC_SERVER);
            }
        });

        int count = (int) iShellWindows.getCount().getValue();
        Debug.getInstance().println("Number Browsers Found by ShellWindows = " + count);

        for (int i = count - 1; i >= 0; i--) {
            Debug.getInstance().println("Trying Browser " + i);
            IDispatch item = (IDispatch) oleMessageLoop.bindObject(iShellWindows.item(new Variant(i)));
            if (item.isNull()) {
                browser = null;
                continue;
            }
            browser = (IWebBrowser2) oleMessageLoop.bindObject(new IWebBrowser2Impl(item));
            try {
                Debug.getInstance().println("browser name=" + browser.getName().toString());
                if (!StringUtils.matchesOrContains(IE.TITLE, browser.getName().toString())) {
                    continue;
                }
                IDispatch document = (IDispatch) oleMessageLoop.bindObject(browser.getDocument());
                oleMessageLoop.bindObject(new IHTMLDocument2Impl(document));
            } catch (Throwable t) {
                Debug.handleException(t);
                browser = null;
                continue;
            }
            if (!browserAction.perform(browser, oleMessageLoop)) {
                break;
            }
        }
    }

    static interface BrowserAction {
        boolean perform(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception;
    }

    public static void closeAllBrowsers() throws Exception {
        closeAllDialogs(); //closing the browser won't work unless all dialogs are closed as well
        OleMessageLoop oleMessageLoop = OleMessageLoop.getInstance();
        executeOnAllBrowsers(new BrowserAction() {
            public boolean perform(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception {
                iWebBrowser2.quit();
                return true;
            }
        }, oleMessageLoop);
    }

    public static int browserCount() throws Exception {
        OleMessageLoop oleMessageLoop = OleMessageLoop.getInstance();
        class CountBrowserAction implements BrowserAction {
            int count = 0;

            public boolean perform(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception {
                count++;
                return true;
            }
        }
        ;
        CountBrowserAction countBrowserAction = new CountBrowserAction();
        executeOnAllBrowsers(countBrowserAction, oleMessageLoop);
        return countBrowserAction.count;
    }

    protected static void debugWndChildren(Wnd wnd, String prefix) {
        if (Debug.isDebug()) {
            prefix += "_childWindow";
            List children = wnd.getChildWindows();
            for (int i = 0; i < children.size(); i++) {
                debugWnd((Wnd) children.get(i), prefix);
            }
        }
    }

    protected static void debugWnd(Wnd wnd, String prefix) {
        if (Debug.isDebug()) {
            Debug.getInstance().println(prefix + "_windowClassName = " + wnd.getWindowClassName());
            Debug.getInstance().println(prefix + "_windowText = " + wnd.getWindowText());
            Debug.getInstance().println(prefix + "_isWindow = " + wnd.isWindow());
        }
    }

    protected static Wnd waitDialogWnd(final Wnd startWnd, final String windowClassName, final String windowText) throws Exception {
        class WindowReady implements Ready {
            Wnd wnd;

            public boolean isReady() throws Exception {
                wnd = Wnd.findWindowEx(startWnd, windowClassName, windowText);
                debugWnd(wnd, "findByStartWind");
                return wnd.isWindow();
            }

            public String getNotReadyReason() {
                return "Could not find Dialog with windowClassName = " + windowClassName + " windowText=" + windowText;
            }

            public Wnd wnd() {
                return wnd;
            }
        }
        WindowReady windowReady = new WindowReady();
        new WaiterImpl(10000, 200).waitUntil(windowReady);
        Wnd wnd = windowReady.wnd();
        //switchToThisWindow(wnd);
        return wnd;
    }

    protected static Wnd waitDialogWnd(final String title) throws Exception {
        class WindowReady implements Ready {
            Wnd wnd;

            public boolean isReady() throws Exception {
                wnd = Wnd.findWindow(DIALOG_CLASSNAME, title);
                debugWnd(wnd, "findByTitle");
                return wnd.isWindow();
            }

            public String getNotReadyReason() {
                return "Could not find Dialog with title = " + title;
            }

            public Wnd wnd() {
                return wnd;
            }
        }
        WindowReady windowReady = new WindowReady();
        new WaiterImpl(10000, 200).waitUntil(windowReady);
        Wnd wnd = windowReady.wnd();
        switchToThisWindow(wnd);
        Debug.getInstance().println("Found through findByTitle");
        return wnd;
    }

    protected static Wnd waitDialogWnd(final String title, final String childClassName, final String childText) throws Exception {
        class WindowReady implements Ready {
            Wnd wnd;

            public boolean isReady() throws Exception {
                wnd = findDialogWnd(title, childClassName, childText);
                return wnd != null;
            }

            public String getNotReadyReason() {
                return "Could not find Dialog with title=" + title + " childClassName=" + childClassName + " childText=" + childText;
            }

            public Wnd wnd() {
                return wnd;
            }
        }
        ;
        WindowReady windowReady = new WindowReady();
        new WaiterImpl(10000, 200).waitUntil(windowReady);
        Wnd wnd = windowReady.wnd();
        switchToThisWindow(wnd);
        return wnd;
    }

    protected static Wnd findDialogWnd(String title, String childClassName, String childText) throws Exception {
        Wnd wnd = Wnd.findWindow(DIALOG_CLASSNAME, title);
        debugWnd(wnd, "findByTitleAndChild");
        if (wnd.isWindow()) {
            debugWndChildren(wnd, "findByTitleAndChild");
            Wnd childWnd = Wnd.findWindowEx(wnd, childClassName, childText);
            debugWnd(childWnd, "aChildWnd");
            if (childWnd.isWindow()) {
                return wnd;
            }
        }
        return null;
    }

    protected static void clickWindow(Wnd wnd) {
        wnd.sendMessageEx(0x00F5, 0, 0);
    }

    protected static void clickWindowUntilGone(final Wnd wnd, final Wnd windowToWaitOn) throws Exception {

        new WaiterImpl(10000, 200).waitUntil(new Ready() {

            public boolean isReady() throws Exception {
                clickWindow(wnd);
                Debug.getInstance().println("windowToWaitOn.isWindow()=" + windowToWaitOn.isWindow());
                Debug.getInstance().println("windowToWaitOn.isVisible()=" + windowToWaitOn.isVisible());
                return !windowToWaitOn.isWindow();
            }

            public String getNotReadyReason() {
                return "Dialog never went away";
            }
        });
    }

    protected static String getStaticText(Wnd wnd) {
        List children = wnd.getChildWindows();
        StringBuffer text = new StringBuffer();
        for (int i = 0; i < children.size(); i++) {
            Wnd childWnd = (Wnd) children.get(i);
            if ("Static".equals(childWnd.getWindowClassName())) {
                text.append(childWnd.getWindowText());
            }
        }
        return text.toString();
    }

    public static void closeAllDialogs() {
        List windows = Wnd.getAllWindows();
        for (int i = 0; i < windows.size(); i++) {
            Wnd wnd = (Wnd) windows.get(i);
            if (DIALOG_CLASSNAME.equals(wnd.getWindowClassName())) {
                if (wnd.getParent().isWindow() && "IEFrame".equals(wnd.getParent().getWindowClassName())) {
                    int wm_quit = 0x0012;
                    wnd.postMessage(wm_quit, 0, 0);
                }
            }
        }
    }

    protected static void waitUntilDocumentComplete(final IHTMLDocument2 ihtmlDocument2) throws Exception {
        Debug.getInstance().println("Begin IEUtil.waitUntilDocumentComplete(final IHTMLDocument2 ihtmlDocument2)");
        new WaiterImpl(IE.TIMEOUT_DOCUMENT, 200).waitUntil(new Ready() {
            String readyState;

            public boolean isReady() throws Exception {
                readyState = ihtmlDocument2.getReadyState().getValue();
                debug("Document is " + readyState);
                debug("Document complete? "+ ("complete".equalsIgnoreCase(readyState) || "uninitialized".equalsIgnoreCase(readyState)));
                return "complete".equalsIgnoreCase(readyState) || "uninitialized".equalsIgnoreCase(readyState);
            }

            public String getNotReadyReason() {
                return "Document is not 'complete'...its last known state was '" + readyState + "'";
            }
        });
        Debug.getInstance().println("End IEUtil.waitUntilDocumentComplete(final IHTMLDocument2 ihtmlDocument2)");
    }

}
