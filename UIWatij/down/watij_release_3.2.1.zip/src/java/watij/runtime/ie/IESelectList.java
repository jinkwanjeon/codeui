package watij.runtime.ie;

import com.jniwrapper.win32.ie.dom.OptionElement;
import com.jniwrapper.win32.ie.dom.SelectElement;
import org.w3c.dom.Element;
import watij.elements.SelectList;
import watij.runtime.NoValueFoundException;
import watij.utilities.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class IESelectList extends IEHtmlElement implements SelectList {
    public IESelectList(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    private SelectElement selectElement() throws Exception {
        return (SelectElement) htmlElement();
    }

    public void clearSelection() throws Exception {
        List optionsArray = selectElement().getOptions();
        for (int i = 0; i < optionsArray.size(); i++) {
            IEOption ieOption = new IEOption((OptionElement) optionsArray.get(i), ie());
            ieOption.select(false);
        }
    }

    public List<String> getAllContents() throws Exception {
        List optionsArray = selectElement().getOptions();
        List<String> contents = new ArrayList<String>();
        for (int i = 0; i < optionsArray.size(); i++) {
            // Note: do not instantiate IEOption.  IEOption is expensive to instantiate, particularly if
            // the page has lots of select list options on it (regardless if in one or many select lists)
            contents.add(((OptionElement) optionsArray.get(i)).getText());
        }
        return contents;
    }

    public List<String> getSelectedItems() throws Exception {
        List optionsArray = selectElement().getOptions();
        List<String> contents = new ArrayList<String>();
        for (int i = 0; i < optionsArray.size(); i++) {
            // Note: do not instantiate IEOption.  IEOption is expensive to instantiate, particularly if
            // the page has lots of select list options on it (regardless if in one or many select lists)
            OptionElement oe = (OptionElement) optionsArray.get(i);
            if (Boolean.valueOf(oe.getAttribute("selected"))) {
                contents.add(oe.getText());
            }
        }
        return contents;
    }

    public void select(String item) throws Exception {
        List optionsArray = selectElement().getOptions();
        for (int i = 0; i < optionsArray.size(); i++) {
            OptionElement oe = (OptionElement) optionsArray.get(i);
            // Note: only instantiate IEOption if necessary.  IEOption is expensive to instantiate, particularly if
            // the page has lots of select list options on it (regardless if in one or many select lists)
            if (StringUtils.matchesOrEquals(item, oe.getText())) {
                IEOption ieOption = new IEOption(oe, ie());
                ieOption.select();
                return;
            }
        }
        throw new NoValueFoundException("No option with text of " + item + " in this select element");
    }

    public void selectValue(String item) throws Exception {
        List optionsArray = selectElement().getOptions();
        for (int i = 0; i < optionsArray.size(); i++) {
            OptionElement oe = (OptionElement) optionsArray.get(i);
            // Note: only instantiate IEOption if necessary.  IEOption is expensive to instantiate, particularly if
            // the page has lots of select list options on it (regardless if in one or many select lists)
            if (StringUtils.matchesOrEquals(item, oe.getAttribute("value"))) {
                IEOption ieOption = new IEOption(oe, ie());
                ieOption.select();
                return;
            }
        }
        throw new NoValueFoundException("No option with text of " + item + " in this select element");
    }


}
