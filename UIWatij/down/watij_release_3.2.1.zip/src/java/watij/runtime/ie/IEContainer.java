package watij.runtime.ie;

import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.ie.dom.HTMLDocument;
import com.jniwrapper.win32.ie.dom.HTMLElement;
import org.cyberneko.html.parsers.DOMParser;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import watij.BaseContainer;
import watij.elements.HtmlElementFactory;
import watij.elements.IEHtmlElementFactory;
import watij.utilities.Debug;

import java.io.StringReader;

public abstract class IEContainer extends BaseContainer {

    protected HtmlElementFactory htmlElementFactory() throws Exception {
        return new IEHtmlElementFactory(ie());
    }

    protected abstract HTMLDocument htmlDocument() throws Exception;

    protected abstract IE ie() throws Exception;

    protected abstract OleMessageLoop oleMessageLoop();

    public Object getOLEDocument() throws Exception {
        return htmlDocument().getDocumentPeer();
    }

    protected void debug(String s) {
        Debug.getInstance().println(s);
    }

    protected String html(HTMLDocument htmlDocument) throws Exception {
        return filterBehaviors(((HTMLElement) htmlDocument.getDocumentElement()).getHTML());
//        IHTMLElement documentElement = (IHTMLElement)oleMessageLoop().bindObject((((IHTMLDocument3) oleMessageLoop().bindObject(new IHTMLDocument3Impl(ihtmlDocument2))).getDocumentElement()));
//        String outerHtml = documentElement.getOuterHTML().getValue();
//        return filterBehaviors(outerHtml);
    }

    private String filterBehaviors(String html) {
        String s = html.replaceAll("<[A-Z]*:", "<");
        return s.replaceAll("</[A-Z]*:", "</");
    }

    protected Document document(String html) throws Exception {
//		Tidy tidy = new Tidy();
//		tidy.setWraplen(Integer.MAX_VALUE);
//		tidy.setTidyMark(false);
//		tidy.setErrout(new PrintWriter(new OutputStream() {
//			public void write(int i) {
//			}
//		}));
//		Timer timer = new TimerImpl();
//		final Document document = tidy.parseDOM(new ByteArrayInputStream(html.getBytes()), null);
//		timer.outputElapsedTime("tidy", Debug.getInstance());
//		return document;

        DOMParser domParser = new DOMParser();
        domParser.parse(new InputSource(new StringReader(html)));
        return domParser.getDocument();
    }
}
