package watij.runtime.ie;

import com.jniwrapper.win32.ui.Wnd;
import watij.dialogs.ConfirmDialog;
import watij.utilities.WatijResourceLoader;
import watij.utilities.WatijResources;

public class IEConfirmDialog extends IEAlertDialog implements ConfirmDialog {


    public IEConfirmDialog(Wnd dialog, IE ie) {
        super(dialog, ie);
    }

    public static ConfirmDialog findConfirmDialog(IE ie) throws Exception {
        Wnd wnd = IEUtil.waitDialogWnd(IE.TITLE);
        return new IEConfirmDialog(wnd, ie);
    }

    public void cancel() throws Exception {
        Wnd wnd = IEUtil.waitDialogWnd(dialog, "Button",
                WatijResourceLoader.getString(WatijResources.IEConfirmDialog_Cancel));
        IEUtil.clickWindowUntilGone(wnd, dialog);
    }
}
