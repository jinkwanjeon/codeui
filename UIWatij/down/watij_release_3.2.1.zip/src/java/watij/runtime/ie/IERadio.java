package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Radio;


/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:36:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class IERadio extends IERadioCheckCommon implements Radio {
    public IERadio(Element element, IE ie) throws Exception {
        super(element, ie);
    }
}
