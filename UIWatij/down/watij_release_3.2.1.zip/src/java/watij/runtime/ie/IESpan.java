package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Span;


public class IESpan extends IEHtmlElement implements Span {
    public IESpan(Element element, IE ie) throws Exception {
        super(element, ie);
    }
}
