package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Link;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 6:56:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class IELink extends IEHtmlElement implements Link {

    public IELink(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public boolean linkHasImage() throws Exception {
        return htmlElement().getElementsByTagName("img").getLength() > 0;
    }

    public String type() throws Exception {
        htmlElement();  //make sure link exists
        return "Link";
    }

    public String href() throws Exception {
        return htmlElement().getAttribute("href");
    }
}
