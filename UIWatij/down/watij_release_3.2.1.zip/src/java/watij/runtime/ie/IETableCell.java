package watij.runtime.ie;

import com.jniwrapper.win32.com.IUnknown;
import com.jniwrapper.win32.mshtml.IHTMLTableCell;
import com.jniwrapper.win32.mshtml.impl.IHTMLTableCellImpl;
import org.w3c.dom.Element;
import watij.elements.TableCell;

public class IETableCell extends IEHtmlElement implements TableCell {
    public IETableCell(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    private IHTMLTableCell ihtmlTableCell() throws Exception {
        return (IHTMLTableCell) oleMessageLoop().bindObject(new IHTMLTableCellImpl(oleMessageLoop().bindObject((IUnknown) htmlElement().getElementPeer())));
    }

    public int colspan() throws Exception {
        return (int) ihtmlTableCell().getColSpan().getValue();
    }

//    public int colspan() throws Exception {
//        String colspan = tableCell().getAttributeNode("colspan").getValue();
//        return Utils.isEmpty(colspan)?0:Integer.valueOf(colspan);
//    }
}
