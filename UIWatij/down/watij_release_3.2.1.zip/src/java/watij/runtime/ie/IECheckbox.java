package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Checkbox;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:38:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class IECheckbox extends IERadioCheckCommon implements Checkbox {
    public IECheckbox(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public void set(boolean setOrClear) throws Exception {
        checkControl().setValue(setOrClear);
    }
}
