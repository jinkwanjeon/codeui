package watij.runtime.ie;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLTableRowElement;
import watij.elements.TableCell;
import watij.elements.TableCells;
import watij.elements.TableRow;

import java.util.List;
import java.util.ArrayList;

public class IETableRow extends IEHtmlElement implements TableRow {
    public IETableRow(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    private com.jniwrapper.win32.ie.dom.TableRow tableRow() throws Exception {
        return (com.jniwrapper.win32.ie.dom.TableRow) htmlElement();
    }

    public int columnCount() throws Exception {
        return tableRow().getCells().size();
    }

    public TableCell cell(int cellIndex) throws Exception {
        return cells().get(cellIndex);
    }

    //! Must override these to keep context with table in order to handle subtables */
    public TableCells cells() throws Exception {
        return new TableCells(immediateCells(element()), htmlElementFactory());
    }

    protected List<Element> immediateCells(Element element) throws Exception {
        List<Element> rows = new ArrayList<Element>();
        NodeList nodeList = element.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if ("TD".equalsIgnoreCase(node.getNodeName()) || "TH".equalsIgnoreCase(node.getNodeName())) {
                rows.add((Element)node);
            }
        }
        return rows;
    }
}
