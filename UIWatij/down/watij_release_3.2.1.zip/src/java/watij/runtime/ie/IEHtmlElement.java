package watij.runtime.ie;

import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.com.IUnknown;
import com.jniwrapper.win32.ie.dom.HTMLDocument;
import com.jniwrapper.win32.ie.dom.HTMLElement;
import com.jniwrapper.win32.mshtml.IHTMLElement;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.html.HTMLCollection;
import watij.elements.HtmlElement;
import watij.runtime.ObjectDisabledException;
import watij.runtime.UnknownObjectException;
import watij.utilities.Debug;
import watij.utilities.Utils;

import java.util.ArrayList;
import java.util.List;

public class IEHtmlElement extends IEContainer implements HtmlElement {

    Element element;
    IE ie;

    public IEHtmlElement(Element element, IE ie) throws Exception {
        this.element = element;
        this.ie = ie;
    }

    public Element element() throws Exception {
        return element;
    }

    protected HTMLElement htmlElement() throws Exception {
        return find(element);
    }

    protected IE ie() throws Exception {
        return ie;
    }

    protected HTMLDocument htmlDocument() throws Exception {
        return ie.htmlDocument();
    }

    protected OleMessageLoop oleMessageLoop() {
        return ie.oleMessageLoop();
    }

    //attributes

    public boolean disabled() throws Exception {
        String disabled = htmlElement().getAttribute("disabled");
        return Boolean.valueOf(disabled);
//        return ((IHTMLElement3) oleMessageLoop().bindObject(new IHTMLElement3Impl(htmlElement()))).getDisabled().getBooleanValue();
    }

    public String id() throws Exception {
        return htmlElement().getAttribute("id");
    }

    public String name() throws Exception {
        return htmlElement().getAttribute("name");
    }

    public String title() throws Exception {
        return htmlElement().getAttribute("title");
    }

    public String className() throws Exception {
        return htmlElement().getElementClass();
    }

    public String type() throws Exception {
        return htmlElement().getAttribute("type");
    }

    public String value() throws Exception {
        return htmlElement().getAttribute("value");
    }

    public String style() throws Exception {
        return htmlElement().getBorder().getValue();
//        IHTMLStyle style = (IHTMLStyle)oleMessageLoop().bindObject(htmlElement().getStyle());
//        return style.getCssText().getValue();
    }

//    protected String attributeValue(IHTMLElement ihtmlElement, String name) throws Exception {
//        IHTMLDOMAttribute ihtmldomAttribute = ihtmldomAttribute(ihtmlElement, name);
//        return ihtmldomAttribute == null ? "" : ihtmldomAttribute.getValue();
//    }
//
//    protected IHTMLDOMAttribute ihtmldomAttribute(IHTMLElement ihtmlElement, String name) throws Exception {
//        IHTMLAttributeCollection ihtmlAttributeCollection = new IHTMLAttributeCollectionImpl(new IHTMLDOMNodeImpl(ihtmlElement).getAttributes());
//        for (int i = 0; i < ihtmlAttributeCollection.getLength(); i++) {
//            IHTMLDOMAttribute ihtmldomAttribute = new IHTMLDOMAttributeImpl(ihtmlAttributeCollection.item(new Variant(i)));
//            if (ihtmldomAttribute.getSpecified().getBooleanValue() || "value".equalsIgnoreCase(ihtmldomAttribute.getNodeName().toString()) || "type".equalsIgnoreCase(ihtmldomAttribute.getNodeName().toString()))
//            {
//                if (name.equalsIgnoreCase(ihtmldomAttribute.getNodeName().toString())) {
//                    return ihtmldomAttribute;
//                }
//            }
//        }
//        return null;
//    }

    //methods

    public void click() throws Exception {
        assertEnabled();
        click(htmlElement());
    }

    protected void assertEnabled() throws Exception {
        if (disabled()) {
            throw new ObjectDisabledException();
        }
    }

    public String get() throws Exception {
        return innerText();
    }

    public String text() throws Exception {
        return innerText();
    }

    public String innerText() throws Exception {
        return htmlElement().getText();
    }

    public String tag() throws Exception {
        return htmlElement().getTagName();
    }

    private void click(HTMLElement htmlElement) throws Exception {
        try {
            htmlElement.click();
        } catch (Throwable t) {
            debug("WARNING ON CLICK:" + t.getMessage());
        }
    }

    public void dblClick() throws Exception {
        dblClick(htmlElement());
    }

    private void dblClick(HTMLElement htmlElement) throws Exception {
        fireEvent(htmlElement, "ONDBLCLICK");
    }


    protected HTMLElement find(Element element) throws Exception {
        return find(element, htmlDocument());
    }

    protected HTMLElement find(Element element, HTMLDocument htmlDocument) throws Exception {
        if (element == null) {
            throw new UnknownObjectException();
        }
        NodeList nodeList = htmlDocument.getElementsByTagName(filterTagNameForIEBehaviors(element));
        int i = getByTagNameIndexForElement(element);
        return (HTMLElement) nodeList.item(i);
    }

    protected List<Element> toList(HTMLCollection htmlCollection) {
        List<Element> list = new ArrayList<Element>();
        for (int i = 0; i < htmlCollection.getLength(); i++) {
            list.add((Element) htmlCollection.item(i));
        }
        return list;
    }

    private String filterTagNameForIEBehaviors(Element element) {
        String tagName = element.getTagName();
        int semiColonIndex = tagName.indexOf(":");
        if (semiColonIndex != -1) {
            tagName = tagName.substring(semiColonIndex + 1);
        }
        return tagName;
    }

    private int getByTagNameIndexForElement(Element element) {
        NodeList nodeList = element.getOwnerDocument().getElementsByTagName(element.getTagName());
        for (int i = 0; i < nodeList.getLength(); i++) {
            if (nodeList.item(i).equals(element)) {
                return i;
            }
        }
        return -1;
    }

    protected void fireBeforeSetEvents(HTMLElement htmlElement) throws Exception {
        fireEvent(htmlElement, "ONSELECT");
    }

    protected void fireAfterSetEvents(HTMLElement htmlElement) throws Exception {
        fireEvent(htmlElement, "ONKEYPRESS");
        fireEvent(htmlElement, "ONKEYDOWN");
        fireEvent(htmlElement, "ONKEYUP");
        fireEvent(htmlElement, "ONCHANGE");
        fireEvent(htmlElement, "ONBLUR");
    }

    public void fireEvent(String eventName) throws Exception {
        assertEnabled();
        fireEvent(htmlElement(), eventName);
    }

    private void fireEvent(HTMLElement htmlElement, String eventName) throws Exception {
        try {
            htmlElement.fireEvent(eventName);
        } catch (Throwable t) {
            debug("WARNING ON FIRE EVENT:" + t.getMessage());
        }
    }

    public boolean enabled() throws Exception {
        return !disabled();
    }

    public boolean exists() throws Exception {
        if (!ie().exists()) {
            return false;
        }
        try {
            return htmlElement() != null;
        } catch (Exception e) {
            Debug.handleException(e);
            return false;
        }
    }

    public void focus() throws Exception {
        htmlElement().focus();
    }

    public Object getOLEObject() throws Exception {
        return htmlElement().getElementPeer();
    }

    public String html() throws Exception {
        IHTMLElement ihtmlElement = (IHTMLElement) oleMessageLoop().bindObject((IUnknown) htmlElement().getElementPeer());
        return ihtmlElement.getOuterHTML().getValue();
    }

    public void flash() throws Exception {
        HTMLElement htmlElement = htmlElement();
        for (int i = 0; i < 10; i++) {
            toggleColor(htmlElement);
        }
    }

    private void toggleColor(HTMLElement htmlElement) throws Exception {
        String originalColor = htmlElement.getStyle("background");
        htmlElement.setStyle("background", "yellow");
        Thread.sleep(50);
        htmlElement.setStyle("background", "blue");
        Thread.sleep(50);
        if (Utils.isEmpty(originalColor)) {
            htmlElement.setStyle("background", "transparent");
        } else {
            htmlElement.setStyle("background", originalColor);
        }
//        IHTMLElement2 ihtmlElement2 = (IHTMLElement2)oleMessageLoop().bindObject(new IHTMLElement2Impl(ihtmlElement));
//        IHTMLCurrentStyle currentStyle = (IHTMLCurrentStyle)oleMessageLoop().bindObject(ihtmlElement2.getCurrentStyle());
//        String originalColor = currentStyle.getBackgroundColor().getBstrVal().getValue();
//        IHTMLStyle style = (IHTMLStyle)oleMessageLoop().bindObject(ihtmlElement.getStyle());
//        style.setBackgroundColor(new Variant("yellow"));
//        Thread.sleep(50);
//        style.setBackgroundColor(new Variant("blue"));
//        Thread.sleep(50);
//        if (Utils.isEmpty(originalColor)) {
//            style.setBackgroundColor(new Variant("transparent"));
//        } else {
//            style.setBackgroundColor(new Variant(originalColor));
//        }
    }

    public void show() throws Exception {
        System.out.println(toString());
    }

    //JSON format
    public String toString() {
        Debug.getInstance().println("Begin IEHtmlElement.toString()");
        try {
            StringBuffer s = new StringBuffer();
            s.append("\n");
            s.append("{");
            s.append("\n");
            s.append("\t\"").append(tag()).append("\": {");

            readAttributesFromBrowser(s);

            s.deleteCharAt(s.length() - 1);//remove last ,
            s.append("\n");
            s.append("\t}");
            s.append("\n");
            s.append("}");
            Debug.getInstance().println("End IEHtmlElement.toString()");
            return s.toString();
        } catch (Exception e) {
            return super.toString();
        }

    }

    private void readAttributesFromBrowser(StringBuffer s) throws Exception {
        Debug.getInstance().println("Begin IEHtmlElement.readAttributesFromBrowser(StringBuffer s)");
        NamedNodeMap attrMap = htmlElement().getAttributes();
        Debug.getInstance().println("attrMap.getLength()= "+attrMap.getLength());
        readAttributes(attrMap, s);
        Debug.getInstance().println("End IEHtmlElement.readAttributesFromBrowser(StringBuffer s)");
//        IHTMLDOMNode ihtmldomNode = (IHTMLDOMNode)oleMessageLoop().bindObject(new IHTMLDOMNodeImpl(htmlElement()));
//        IDispatch attributes = (IDispatch)oleMessageLoop().bindObject(ihtmldomNode.getAttributes());
//        IHTMLAttributeCollection collection = (IHTMLAttributeCollection)oleMessageLoop().bindObject(new IHTMLAttributeCollectionImpl(attributes));
//        int count = (int) collection.invokeGetLength().getValue();
//        for (int i = 0; i < count; i++) {
//            IDispatch item = (IDispatch)oleMessageLoop().bindObject(collection.item(new Variant(i)));
//            IHTMLDOMAttribute attribute = (IHTMLDOMAttribute)oleMessageLoop().bindObject(new IHTMLDOMAttributeImpl(item));
//            if (attribute.getSpecified().getBooleanValue() || "value".equalsIgnoreCase(attribute.getNodeName().getValue()) || "type".equalsIgnoreCase(attribute.getNodeName().getValue()))
//            {
//                s.append("\n");
//                s.append("\t\t\"").append(attribute.getNodeName().getValue()).append("\": ");
//                s.append("\"");
//                try {
//                    s.append(attribute.getNodeValue().getValue());
//                } catch (Exception e) {
//                }
//                s.append("\"");
//                s.append(",");
//            }
//        }
    }

    private void readAttributesFromCache(StringBuffer s) throws Exception {
        NamedNodeMap attrMap = element().getAttributes();
        readAttributes(attrMap, s);
    }

    private void readAttributes(NamedNodeMap attrMap, StringBuffer s) {
        Debug.getInstance().println("Begin IEHtmlElement.readAttributes(NamedNodeMap attrMap, StringBuffer s)");
        int count = attrMap.getLength();
        for (int i = 0; i < count; i++) {
            Attr attribute = (Attr) attrMap.item(i);
            if (attribute.getSpecified() || "value".equalsIgnoreCase(attribute.getName()) || "type".equalsIgnoreCase(attribute.getName())) {
                s.append("\n");
                s.append("\t\t\"").append(attribute.getName()).append("\": ");
                s.append("\"");
                try {
                    s.append(attribute.getValue());
                } catch (Exception e) {
                }
                s.append("\"");
                s.append(",");
            }
        }
        Debug.getInstance().println("End IEHtmlElement.readAttributes(NamedNodeMap attrMap, StringBuffer s)");
    }

}
