package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.TextArea;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 16, 2006
 * Time: 10:29:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class IETextArea extends IETextField implements TextArea {

    public IETextArea(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public String get() throws Exception {
        return innerText();
    }

//    public void set(String value) throws Exception {
//        assertEnabled();
//        assertNotReadOnly();
//        set(ihtmlTextAreaElement(), value);
//    }

    public String value() throws Exception {
        return get();
    }

//    private void set(IHTMLTextAreaElement ihtmlTextAreaElement, String value) throws Exception {
//        assertEnabled();
//        IHTMLElement ihtmlElement = (IHTMLElement)oleMessageLoop().bindObject(new IHTMLElementImpl(ihtmlTextAreaElement));
//        fireBeforeSetEvents(ihtmlElement);
//        ihtmlTextAreaElement.setValue(new BStr(value));
//        waitUnitDocumentComplete(htmlDocument);
//        fireAfterSetEvents(ihtmlElement);
//    }

    public int size() throws Exception {
        return -1;
    }

    public int maxLength() throws Exception {
        return -1;
    }

}
