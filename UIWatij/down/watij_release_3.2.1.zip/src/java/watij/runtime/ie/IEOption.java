package watij.runtime.ie;

import com.jniwrapper.win32.ie.dom.HTMLElement;
import com.jniwrapper.win32.ie.dom.OptionElement;
import org.w3c.dom.Element;
import watij.elements.Option;

public class IEOption extends IEHtmlElement implements Option {

    public IEOption(Element element, IE ie) throws Exception {
        super(element, ie);
    }

//    public IEOption(OptionElement optionElement, IE ie) throws Exception {
//        super(null, ie);
//        this.htmlElement = optionElement;
//    }

    public void select() throws Exception {
        select(true);
    }

    public void select(boolean select) throws Exception {
        select(optionElement(), select);
    }

    public boolean selected() throws Exception {
        return selected(optionElement());
    }

    private boolean selected(OptionElement optionElement) {
        return Boolean.valueOf(optionElement.getAttribute("selected"));
    }

    private OptionElement optionElement() throws Exception {
        return (OptionElement) htmlElement();
    }

    public void clear() throws Exception {
        select(false);
    }

    private void select(OptionElement optionElement, boolean select) throws Exception {
        if (select && selected(optionElement)) {
            return;
        }
        HTMLElement parentElement = (HTMLElement) optionElement.getParentNode();
//        System.out.println("parentElement.getTagName() = " + parentElement.getTagName());
        fireBeforeSetEvents(parentElement);
        optionElement.setAttribute("selected", "" + select);
        fireAfterSetEvents(parentElement);
    }

}
