package watij.runtime.ie;

public class IEDispatchPtrNullException extends Exception {

    public IEDispatchPtrNullException() {
    }

    public IEDispatchPtrNullException(String s) {
        super(s);
    }

    public IEDispatchPtrNullException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public IEDispatchPtrNullException(Throwable throwable) {
        super(throwable);
    }

}
