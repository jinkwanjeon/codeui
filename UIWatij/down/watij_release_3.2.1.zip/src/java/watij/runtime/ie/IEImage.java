package watij.runtime.ie;

import com.jniwrapper.win32.com.IUnknown;
import com.jniwrapper.win32.mshtml.IHTMLImgElement;
import com.jniwrapper.win32.mshtml.impl.IHTMLImgElementImpl;
import org.w3c.dom.Element;
import watij.elements.Image;
import watij.runtime.NotImplementedYetException;
import watij.utilities.Utils;

public class IEImage extends IEHtmlElement implements Image {

    public IEImage(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    private IHTMLImgElement ihtmlImgElement() throws Exception {
        return (IHTMLImgElement) oleMessageLoop().bindObject(new IHTMLImgElementImpl(oleMessageLoop().bindObject((IUnknown) htmlElement().getElementPeer())));
    }

    public String alt() throws Exception {
        return htmlElement().getAttribute("alt");
    }

    public String fileCreatedDate() throws Exception {
        return ihtmlImgElement().getFileCreatedDate().getValue();
    }

    public int fileSize() throws Exception {
        return Integer.valueOf(ihtmlImgElement().getFileSize().getValue());
    }

    public int height() throws Exception {
        return (int) ihtmlImgElement().getHeight().getValue();
    }

    public int width() throws Exception {
        return (int) ihtmlImgElement().getWidth().getValue();
    }

    public boolean hasLoaded() throws Exception {
        return (!Utils.isEmpty(fileCreatedDate())) && (fileSize() > -1);
    }

    public void save(String path) throws NotImplementedYetException {
        throw new NotImplementedYetException();
    }

    public String src() throws Exception {
        return ihtmlImgElement().getSrc().getValue();
    }
}
