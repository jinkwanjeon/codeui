package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.FileField;
import watij.utilities.WatijResourceLoader;
import watij.utilities.WatijResources;


public class IEFileField extends IETextField implements FileField {
    public IEFileField(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public void set(final String value) throws Exception {
        assertEnabled();
        assertNotReadOnly();
        IEUtil.sendKeys(WatijResourceLoader.getString(WatijResources.IEFileField_ChooseFile), value + "{TAB}{TAB} ",
                false, oleMessageLoop());
        click();
    }

}
