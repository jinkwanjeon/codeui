package watij.runtime.ie;

import com.jniwrapper.*;
import com.jniwrapper.win32.FunctionName;
import com.jniwrapper.win32.Msg;
import com.jniwrapper.win32.automation.types.BStr;
import com.jniwrapper.win32.ui.User32;
import com.jniwrapper.win32.ui.Wnd;
import watij.dialogs.PromptDialog;
import watij.utilities.Debug;
import watij.utilities.WatijResourceLoader;
import watij.utilities.WatijResources;

import java.util.List;

public class IEPromptDialog extends IEConfirmDialog implements PromptDialog {

    public IEPromptDialog(Wnd dialog, IE ie) {
        super(dialog, ie);
    }

    public static PromptDialog findPromptDialog(IE ie) throws Exception {
        Wnd wnd = IEUtil.waitDialogWnd(
                WatijResourceLoader.getString(WatijResources.IEPromptDialog_Title_ExplorerUserPrompt));
        return new IEPromptDialog(wnd, ie);
    }

    public void value(String text) throws Exception {
        List children = dialog.getChildWindows();
        for (int i = 0; i < children.size(); i++) {
            Wnd childWnd = (Wnd) children.get(i);
            IEUtil.debugWnd(childWnd, "setValueForChild");
            if ("Edit".equals(childWnd.getWindowClassName())) {
                final Function sendMessage =
                        User32.getInstance().getFunction(new FunctionName("SendMessage").toString());
                IntBool result = new IntBool();
                sendMessage.invoke(result, childWnd, new UInt(Msg.WM_SETTEXT), new BStr(), new BStr(text));
                Debug.getInstance().println("setValue result.getBooleanValue() = " + result.getBooleanValue());
            }
        }
    }

    public String value() throws Exception {
        List children = dialog.getChildWindows();
        for (int i = 0; i < children.size(); i++) {
            Wnd childWnd = (Wnd) children.get(i);
            IEUtil.debugWnd(childWnd, "valueForChild");
            if ("Edit".equals(childWnd.getWindowClassName())) {
                final Function sendMessage = User32.getInstance().getFunction(new FunctionName("SendMessage").toString());
                final Str text = new Str(1024);
                final Int resultLength = new Int();
                sendMessage.invoke(resultLength, childWnd, new UInt(Msg.WM_GETTEXT), new Int(1024), new Pointer(text));
                return text.getValue();
            }
        }
        return null;
    }

//    public String text() throws Exception {
//        System.out.println("IEPromptDialog.text");
//        List children = dialog.getChildWindows();
//        for (int i = 0; i < children.size(); i++) {
//            Wnd childWnd = (Wnd) children.get(i);
//            if ("Static".equals(childWnd.getWindowClassName()) && !"Script Prompt:".equals(childWnd.getWindowText())) {
//                return childWnd.getWindowText();
//            }
//        }
//        return null;
//    }
}
