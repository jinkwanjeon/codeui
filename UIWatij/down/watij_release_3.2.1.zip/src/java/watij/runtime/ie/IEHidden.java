package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Hidden;


public class IEHidden extends IETextField implements Hidden {
    public IEHidden(Element element, IE ie) throws Exception {
        super(element, ie);
    }
}
