package watij.runtime.ie;

import com.jniwrapper.*;
import com.jniwrapper.win32.automation.IDispatch;
import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.automation.impl.IDispatchImpl;
import com.jniwrapper.win32.automation.server.IDispatchVTBL;
import com.jniwrapper.win32.automation.types.BStr;
import com.jniwrapper.win32.automation.types.Variant;
import com.jniwrapper.win32.automation.types.VariantBool;
import com.jniwrapper.win32.com.IClassFactory;
import com.jniwrapper.win32.com.impl.IUnknownImpl;
import com.jniwrapper.win32.com.server.CoClassMetaInfo;
import com.jniwrapper.win32.com.server.IClassFactoryServer;
import com.jniwrapper.win32.com.types.ClsCtx;
import com.jniwrapper.win32.com.types.IID;
import com.jniwrapper.win32.ie.AuthenticateHandler;
import com.jniwrapper.win32.ie.BrowserSupport;
import com.jniwrapper.win32.ie.KeyFilter;
import com.jniwrapper.win32.ie.WebBrowser;
import com.jniwrapper.win32.ie.dom.DomFactory;
import com.jniwrapper.win32.ie.dom.HTMLDocument;
import com.jniwrapper.win32.ie.event.*;
import com.jniwrapper.win32.mshtml.IHTMLDocument2;
import com.jniwrapper.win32.mshtml.impl.IHTMLDocument2Impl;
import com.jniwrapper.win32.ole.IConnectionPoint;
import com.jniwrapper.win32.ole.IConnectionPointContainer;
import com.jniwrapper.win32.ole.impl.IConnectionPointContainerImpl;
import com.jniwrapper.win32.shdocvw.DWebBrowserEvents2;
import com.jniwrapper.win32.shdocvw.IWebBrowser2;
import com.jniwrapper.win32.shdocvw.InternetExplorer;
import com.jniwrapper.win32.shdocvw.impl.IWebBrowser2Impl;
import com.jniwrapper.win32.shdocvw.server.DWebBrowserEvents2Server;
import com.jniwrapper.win32.ui.Wnd;
import watij.dialogs.ModalDialog;
import watij.time.Ready;
import watij.time.Waiter;
import watij.time.WaiterImpl;
import watij.utilities.Debug;

import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

public class ModalDialogSupport extends BrowserSupport {

    private String additionalHttpHeaders;
    DWebBrowserEvents2Handler dWebBrowserEvents2Handler;
    List<ModalDialogSupport> childBrowsers;
    long hwnd;
    private static int _browsersIndex = 0;

    HTMLDocument htmlDocument;

    public ModalDialogSupport(OleMessageLoop oleMessageLoop) throws Exception {
        super(oleMessageLoop);
        super.initialize();
    }

    public ModalDialogSupport() throws Exception {
        this(createOleMessageLoop());
        createIWebBrowser2();
        setupIWebBrowser2();
    }

    public ModalDialogSupport(ModalDialogSupport parentModalDialogSupport) throws Exception {
        this(parentModalDialogSupport.getOleMessageLoop());
        createIWebBrowser2();
        setupIWebBrowser2();
        setParentBrowser(parentModalDialogSupport);
        parentModalDialogSupport.childBrowsers.add(this);
    }

    public ModalDialogSupport(IWebBrowser2 iWebBrowser2, OleMessageLoop oleMessageLoop) throws Exception {
        this(oleMessageLoop);
        setBrowser(iWebBrowser2);
        setupIWebBrowser2();
    }

    public static OleMessageLoop createOleMessageLoop() {
        OleMessageLoop result = new OleMessageLoop("IESupportLoop." + _browsersIndex++);
        result.doStart();
        return result;
    }

    private void createIWebBrowser2() throws Exception {
        getOleMessageLoop().doInvokeAndWait(new Runnable() {
            public void run() {
                try {
                    IWebBrowser2 browser = InternetExplorer.create(ClsCtx.LOCAL_SERVER);
                    setBrowser(browser);
                } catch (Exception e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        });
    }


    public HTMLDocument getDocument() {
        return htmlDocument;
    }

    public void setDocument(HTMLDocument htmlDocument) {
        this.htmlDocument = htmlDocument;
    }

    private void setupIWebBrowser2() throws Exception {
        //getOleMessageLoop().doInvokeLater(new Runnable() { //This is to support JExplorer 1.7.470
        getOleMessageLoop().doInvokeAndWait(new Runnable() {
            public void run() {
                try {
                    setupListener(iWebBrowser2());
                    iWebBrowser2().setVisible(VariantBool.TRUE);
                    hwnd = iWebBrowser2().getHWND().getValue();
                    childBrowsers = new ArrayList<ModalDialogSupport>();
                } catch (Exception e1) {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        });
        waitForIWebBrowser2Initialized(iWebBrowser2());
    }

    private void waitForIWebBrowser2Initialized(final IWebBrowser2 iWebBrowser2) throws Exception {
        new WaiterImpl(30000, 200).waitUntil(new Ready() {
            Throwable throwable;
            boolean notNull = false
                    ,
                    notBusy = false
                    ,
                    hasHwnd = false;

            public boolean isReady() throws Exception {
                try {
                    notNull = !iWebBrowser2.isNull();
                    notBusy = !iWebBrowser2.getBusy().getBooleanValue();
                    hasHwnd = iWebBrowser2.getHWND().getValue() != 0;
                    return notNull && notBusy && hasHwnd;
                } catch (Throwable t) {
                    Debug.handleException(t);
                    throwable = t;
                    return false;
                }
            }

            public String getNotReadyReason() {
                if (throwable != null) {
                    return "Browser is not initialized...the following exception was thrown: " + throwable;
                }
                return "Browser is not initialized......its last known state was notNull:" + notNull + " notBusy:" + notBusy + " hasHwnd:" + hasHwnd;
            }
        });
    }

    public void waitForChildBrowser(final int i) throws Exception {
        Waiter waiter = new WaiterImpl(60000, 1000);
        waiter.waitUntil(new Ready() {
            public boolean isReady() {
                return childBrowsers.size() > i;
            }

            public String getNotReadyReason() {
                return "ChildBrowser does not exist yet";
            }
        });
    }

    public ModalDialogSupport getChildBrowser(int index) {
        return childBrowsers.get(index);
    }

    protected int getChildBrowserSize() {
        return childBrowsers.size();
    }

    protected void removeSelfFromParent() {
        if (getParentBrowser() != null) {
            ((ModalDialogSupport) getParentBrowser()).childBrowsers.remove(this);
            setParentBrowser(null);
        }
    }

    public IWebBrowser2 iWebBrowser2() {
        return (IWebBrowser2) getBrowserPeer();
    }

    public ModalDialog getModalDialog() throws Exception {
        final OleMessageLoop modalDialogMessageLoop = new OleMessageLoop("modalDialogMessageLoop");
        final ModalDialogFinder modalDialogFinder = new ModalDialogFinder((int) hwnd, modalDialogMessageLoop);
        modalDialogMessageLoop.doStart();
        modalDialogMessageLoop.doInvokeAndWait(modalDialogFinder);
        return new IEModalDialog(modalDialogFinder.getHtmlDocument(), modalDialogMessageLoop, new IE(modalDialogFinder.getWebBrowser()));
    }

    static class ModalDialogFinder implements Runnable {
        Pointer.Void popupDocPointer = new Pointer.Void();
        Int hWndParent = new Int();
        HTMLDocument htmlDocument = null;
        OleMessageLoop oleMessageLoop;
        WebBrowser webBrowser;

        // define some win32api constants
        final UInt GW_ENABLEDPOPUP = new UInt(6);
        final UInt GW_CHILD = new UInt(5);
        final UInt GW_HWNDNEXT = new UInt(2);
        final UInt SMTO_ABORTIFHUNG = new UInt(2);

        // temporary variables
        Int32 hWnd = new Int32(0), hWnd2 = new Int32(0);
        AnsiString className = new AnsiString();

        public ModalDialogFinder(int _hWndParent, OleMessageLoop oleMessageLoop) {
            hWndParent.setValue(_hWndParent);
            this.oleMessageLoop = oleMessageLoop;
        }

        public HTMLDocument getHtmlDocument() {
            return htmlDocument;
        }

        public Wnd getModalWnd() {
            return new Wnd(hWnd.getValue());
        }

        public WebBrowser getWebBrowser() {
            return webBrowser;
        }

        public void run() {
            try {
                final Library user32 = new Library("user32");

                new WaiterImpl(60000, 200).waitUntil(new Ready() {
                    public boolean isReady() throws Exception {
                        user32.getFunction("GetWindow").invoke(hWnd2, new Int32(hWndParent), GW_ENABLEDPOPUP);
                        return hWnd2.getValue() != 0;
                    }

                    public String getNotReadyReason() {
                        return "Handle to Browser not found";
                    }
                });

                new WaiterImpl(60000, 200).waitUntil(new Ready() {
                    public boolean isReady() throws Exception {
                        user32.getFunction("GetWindow").invoke(hWnd, hWnd2, GW_CHILD);
                        if (hWnd.getValue() != 0) {
                            do {
                                user32.getFunction("GetClassNameA").invoke(null, hWnd, className, new UInt(255));
                                if (className.getValue().compareTo("Internet Explorer_Server") == 0) {
                                    return true;
                                }
                                user32.getFunction("GetWindow").invoke(hWnd, hWnd, GW_HWNDNEXT);
                            } while (hWnd.getValue() != 0);
                        }
                        return false;
                    }

                    public String getNotReadyReason() {
                        return "Handle to Internet Explorer_Server not found";
                    }
                });

                // ok - we have it
                Int lResult = new Int(0);
                Pointer lresPointer = new Pointer(lResult);

                UInt nMsg = new UInt(0);
                user32.getFunction("RegisterWindowMessageA").invoke(nMsg, new AnsiString("WM_HTML_GETOBJECT"));

                Parameter[] params = new Parameter[]{hWnd,
                        nMsg,
                        new UInt(0), new UInt(0), SMTO_ABORTIFHUNG,
                        new UInt(100), lresPointer};

                user32.getFunction("SendMessageTimeoutA").invoke(null, params);

                IHTMLDocument2Impl doc2Impl = new IHTMLDocument2Impl();

                Pointer ppDoc = new Pointer(popupDocPointer);
                Int retVal = new Int(0);
                Function.call("oleacc", "ObjectFromLresult",
                        retVal, lResult,
                        new Pointer(doc2Impl.getIID()), new
                        UInt(0), ppDoc);
                IHTMLDocument2 doc2 = new IHTMLDocument2Impl(new IUnknownImpl(popupDocPointer));
                IEUtil.waitUntilDocumentComplete(doc2);
                webBrowser = new ModalDialogSupport(oleMessageLoop);
                htmlDocument = DomFactory.getInstance(webBrowser).createDocument(doc2);

            } catch (Exception e) {
                Debug.handleException(e);
            }
        }
    }

    private String getAdditionalHttpHeaders() {
        return additionalHttpHeaders;
    }

    public void setAdditionalHttpHeaders(String additionalHttpHeaders) {
        this.additionalHttpHeaders = additionalHttpHeaders;
    }

    public void setupListener(IWebBrowser2 iWebBrowser2) throws Exception {
        DWebBrowserEvents2Handler dWebBrowserEvents2Handler;

        // Create class factory server for our DWebBrowserEvents2Impl
        IClassFactoryServer server = new IClassFactoryServer(DWebBrowserEvents2Handler.class);
        server.registerInterface(IDispatch.class, new IDispatchVTBL(server));
        server.registerInterface(DWebBrowserEvents2.class, new IDispatchVTBL(server));
        server.setDefaultInterface(IDispatch.class);

        IClassFactory factory = server.createIClassFactory();

        // Create instance of DWebBrowserEvents2Handler with a class factory
        IDispatchImpl handler = new IDispatchImpl();
        factory.createInstance(null, handler.getIID(), handler);

        // Create IConnectionPointContainer to ActiveX object, which is embedded
        //into OleContainer
        IConnectionPointContainer connectionPointContainer = new IConnectionPointContainerImpl(iWebBrowser2);
        // Find a necessary connection point
        IConnectionPoint connectionPoint = connectionPointContainer.findConnectionPoint(new IID(DWebBrowserEvents2.INTERFACE_IDENTIFIER));

        // Advise our handler
        Int32 int32 = connectionPoint.advise(handler);

        dWebBrowserEvents2Handler = (DWebBrowserEvents2Handler) server.getInstances().get(0);
        dWebBrowserEvents2Handler.setIESupport(this);
        this.dWebBrowserEvents2Handler = dWebBrowserEvents2Handler;
    }

    public static class DWebBrowserEvents2Handler extends DWebBrowserEvents2Server {

        ModalDialogSupport modalDialogSupport = null;
        boolean onQuit = false;
        boolean documentComplete = false;

        public DWebBrowserEvents2Handler(CoClassMetaInfo coClassMetaInfo) {
            super(coClassMetaInfo);
        }

        public void setIESupport(ModalDialogSupport modalDialogSupport) {
            this.modalDialogSupport = modalDialogSupport;
        }

        public void trackOnQuit() {
            onQuit = false;
        }

        public void trackDocumentComplete() {
            documentComplete = false;
        }

        public boolean isOnQuit() {
            return onQuit;
        }

        public boolean isDocumentComplete() {
            return documentComplete;
        }

        public void newWindow3(IDispatch /*[in,out]*/ ppDisp, VariantBool /*[in,out]*/ Cancel, UInt32 /*[in]*/ dwFlags, BStr /*[in]*/ bstrUrlContext, BStr /*[in]*/ bstrUrl) {
            Debug.getInstance().println("ModalDialogSupport$DWebBrowserEvents2Handler.newWindow3");
            final IDispatch /*[in,out]*/ inOut = ppDisp;
            try {
                ModalDialogSupport newModalDialogSupport = new ModalDialogSupport(modalDialogSupport);
                final IWebBrowser2 browser = newModalDialogSupport.iWebBrowser2();
                newModalDialogSupport.getOleMessageLoop().doInvokeAndWait(new Runnable() {
                    public void run() {
                        browser.setRegisterAsBrowser(VariantBool.TRUE);
                        ((IDispatchImpl) inOut).setValue(browser);
                    }
                });

            } catch (Throwable t) {
                Debug.handleException(t);
            }
        }


        public void onQuit() {
            Debug.getInstance().println("ModalDialogSupport$DWebBrowserEvents2Handler.onQuit");
            onQuit = true;
            modalDialogSupport.removeSelfFromParent();
        }

        public void documentComplete(IDispatch iDispatch, Variant variant) {
            documentComplete = true;
        }

        /**
         * BeforeNavigate2 event handler.
         * <p/>
         * args[0] Object that evaluates to the top-level or frame
         * WebBrowser object corresponding to the navigation.
         * args[1] String expression that evaluates to the URL to
         * which the browser is navigating.
         * args[2] Flags
         * args[3] String expression that evaluates to the name of
         * the frame in which the resource will be displayed,
         * or Null if no named frame is targeted for the resource.
         * args[4] Data to send to the server if the HTTP POST transaction
         * is being used.
         * args[5] Value that specifies the additional HTTP headers to send to the
         * server (HTTP URLs only). The headers can specify such things as
         * the action required of the server, the type of data being passed
         * to the server, or a status code.
         * args[6] Boolean value that the container can set to True to cancel the
         * navigation operation, or to False to allow it to proceed.
         */
        private boolean hasNavigated = false;

        public void beforeNavigate2(IDispatch /*[in]*/ pDisp, Variant /*[in]*/ URL, Variant /*[in]*/ Flags, Variant /*[in]*/ TargetFrameName, Variant /*[in]*/ PostData, Variant /*[in]*/ Headers, VariantBool /*[in,out]*/ Cancel) {
            Debug.getInstance().println("ModalDialogSupport$DWebBrowserEvents2Handler.beforeNavigate2");
            if (modalDialogSupport.getAdditionalHttpHeaders() != null && !hasNavigated) {
                String newAddHeaders = existingHeadersValue(Headers) + modalDialogSupport.getAdditionalHttpHeaders();
                IWebBrowser2 iWebBrowser2 = new IWebBrowser2Impl(pDisp);
                iWebBrowser2.stop();
                iWebBrowser2.navigate2(new Variant(URL.getBstrVal()), new Variant(Flags.getIntVal()), new Variant(TargetFrameName.getBstrVal()), new Variant(PostData.getCiVal()), new Variant(newAddHeaders));
                Cancel.setBooleanValue(true);
                hasNavigated = true;
            }
//            debug("end IEController$DWebBrowserEvents2Handler.beforeNavigate2");
        }

        private String existingHeadersValue(Variant existingHeaders) {
            String string = existingHeaders.getBstrVal().getValue();
            return string == null ? "" : string;
        }

        /**
         * NavigateComplete2 event handler
         * <p/>
         * args[0] Object that evaluates to the top-level or frame
         * WebBrowser object corresponding to the navigation.
         * args[1] String that specifies the URL, Universal Naming Convention
         * (UNC) file name, or pointer to an item identifier list (PIDL)
         * of the loaded document.
         */

        public void navigateComplete2(IDispatch /*[in]*/ pDisp, Variant /*[in]*/ URL) {
            Debug.getInstance().println("ModalDialogSupport$DWebBrowserEvents2Handler.navigateComplete2");
            hasNavigated = false;
        }
    }

    protected Wnd getBrowserWindow() {
        return new Wnd(iWebBrowser2().getHWND().getValue());
    }

    public void addPropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removePropertyChangeListener(String string, PropertyChangeListener propertyChangeListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNavigationListener(NavigationEventListener navigationEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeNavigationListener(NavigationEventListener navigationEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getNavigationListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addStatusListener(StatusEventListener statusEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeStatusListener(StatusEventListener statusEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getStatusListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setEventHandler(WebBrowserEventsHandler webBrowserEventsHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowserEventsHandler getEventHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setDialogEventHandler(DialogEventHandler dialogEventHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public DialogEventHandler getDialogEventHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setScriptErrorListener(ScriptErrorListener scriptErrorListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public ScriptErrorListener getScriptErrorListener() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void close() {
        dWebBrowserEvents2Handler.trackOnQuit();
        try {
            iWebBrowser2().quit();
            new WaiterImpl(5000, 200).waitUntil(new Ready() {
                public boolean isReady() throws Exception {
                    Debug.getInstance().println("closing");
                    return dWebBrowserEvents2Handler.isOnQuit();
                }

                public String getNotReadyReason() {
                    return "iWebBrowser2 could not be closed.";
                }
            });
        } catch (Throwable t) {
            Debug.handleException(t);
        }
    }

    public void setNewWindowHandler(NewWindowEventHandler newWindowEventHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public NewWindowEventHandler getNewWindowHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void addNewWindowListener(NewWindowEventListener newWindowEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeNewWindowListener(NewWindowEventListener newWindowEventListener) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getNewWindowListeners() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setKeyFilter(KeyFilter keyFilter) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public KeyFilter getKeyFilter() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void trackChildren() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser getRecentChild() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser waitChildCreation() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public WebBrowser waitChildCreation(Runnable runnable) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }


    public void setAuthenticateHandler(AuthenticateHandler authenticateHandler) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public AuthenticateHandler getAuthenticateHandler() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }//    private synchronized static IWebBrowser2 createBrowserLocal() throws Exception {
//        StringBuffer command = new StringBuffer();
//        command.append("iexplore.exe");
//        command.append(" about:blank#" + (++allBrowserCount));
//        Runtime runtime = Runtime.getRuntime();
//        try {
//            runtime.exec(command.toString());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        return attachByUrl("about:blank#" + allBrowserCount).iWebBrowser2;
//    }
}
