package watij.runtime.ie;

import com.jniwrapper.win32.ie.dom.CheckControl;
import org.w3c.dom.Element;
import watij.elements.RadioCheckCommon;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 20, 2006
 * Time: 8:36:52 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class IERadioCheckCommon extends IEHtmlElement implements RadioCheckCommon {
    public IERadioCheckCommon(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    protected CheckControl checkControl() throws Exception {
        return (CheckControl) htmlElement();
    }

    public boolean checked() throws Exception {
        return checkControl().getValue();
    }

    public void clear() throws Exception {
        assertEnabled();

        CheckControl checkControl = checkControl();
        if (checkControl.getValue()) {
            checkControl.setValue(false);
            fireEvent("ONCLICK");
            fireEvent("ONCHANGE");
        }
    }

    public boolean getState() throws Exception {
        return checked();
    }

    public boolean isSet() throws Exception {
        return checked();
    }

    public void set() throws Exception {
        checkControl().setValue(true);
        fireEvent("ONCLICK");
        fireEvent("ONCHANGE");
    }
}
