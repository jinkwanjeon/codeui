package watij.runtime.ie;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.html.HTMLTableSectionElement;
import watij.elements.TableBody;
import watij.elements.TableCell;
import watij.elements.TableRows;

import java.util.List;
import java.util.ArrayList;


public class IETableBody extends IEHtmlElement implements TableBody {

    public IETableBody(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public int rowCount() throws Exception {
        htmlElement(); //make sure tablebody exists;
        return rows().length();
    }

    public int columnCount() throws Exception {
        return columnCount(0);
    }

    public int columnCount(int index) throws Exception {
        htmlElement(); //make sure tablebody exists;
        return row(index).cells().length();
    }

    public TableCell cell(int rowIndex, int cellIndex) throws Exception {
        return rows().get(rowIndex).cells().get(cellIndex);
    }

    //! Must override these to keep context with table in order to handle subtables */

    public TableRows rows() throws Exception {
        return new TableRows(immediateRows(element()), htmlElementFactory());
    }

    protected List<Element> immediateRows(Element element) throws Exception {
        List<Element> rows = new ArrayList<Element>();
        NodeList nodeList = element.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if ("TR".equalsIgnoreCase(node.getNodeName())) {
                rows.add((Element)node);
            }
        }
        return rows;
    }
}
