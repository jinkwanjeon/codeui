package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Label;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 19, 2006
 * Time: 11:53:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class IELabel extends IEHtmlElement implements Label {

    public IELabel(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public String type() throws Exception {
        htmlElement(); //should throw exception if not found
        return "Label";
    }

    public String htmlFor() throws Exception {
        return htmlElement().getAttribute("htmlFor");
    }
}
