package watij.runtime.ie;

import org.w3c.dom.Element;
import org.w3c.dom.html.HTMLTableElement;
import watij.elements.Table;
import watij.elements.TableRows;


public class IETable extends IETableBody implements Table {

    public IETable(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    //! Must override these to keep context with table in order to handle subtables */
    public TableRows rows() throws Exception {
        return new TableRows(immediateRows((Element)element().getElementsByTagName("TBODY").item(0)), htmlElementFactory());
    }

}
