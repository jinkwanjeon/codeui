package watij.runtime.ie;

import com.jniwrapper.win32.ie.dom.TextControl;
import org.w3c.dom.Element;
import watij.elements.TextField;
import watij.finders.Symbol;
import watij.runtime.NotImplementedYetException;
import watij.runtime.ObjectReadOnlyException;
import watij.utilities.StringUtils;


public class IETextField extends IEHtmlElement implements TextField {

    public IETextField(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    private TextControl textControl() throws Exception {
        return (TextControl) htmlElement();
    }

    public void set(String value) throws Exception {
        assertEnabled();
        assertNotReadOnly();
        setText(textControl(), value);
    }

    public int size() throws Exception {
        return (int) textControl().getSize().getWidth();
    }

    public boolean verifyContains(String what) throws Exception {
        return StringUtils.matchesOrEquals(what, value());
    }

    private void setText(TextControl textControl, String value) throws Exception {
        fireBeforeSetEvents(textControl);
        textControl.setValue(value);
        fireAfterSetEvents(textControl);
    }

    public void append(String append) throws Exception {
        set(get() + append);
    }

    public void assertNotReadOnly() throws Exception {
        if (readOnly()) {
            throw new ObjectReadOnlyException();
        }
    }

    public void clear() throws Exception {
        assertEnabled();
        set("");
    }

    public void dragContentsTo(Symbol destinationHow, String destinationWhat) throws NotImplementedYetException {
        throw new NotImplementedYetException();
    }

    public String getContents() throws Exception {
        return get();
    }

    public int maxLength() throws Exception {
        return Integer.valueOf(textControl().getAttribute("maxLength"));
    }

    public boolean readOnly() throws Exception {
        return Boolean.valueOf((textControl().getAttribute("readOnly")));
    }

    public String get() throws Exception {
        return textControl().getValue();
    }

}
