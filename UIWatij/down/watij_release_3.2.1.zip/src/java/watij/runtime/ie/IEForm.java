package watij.runtime.ie;

import com.jniwrapper.win32.ie.dom.HTMLForm;
import org.w3c.dom.Element;
import watij.elements.Form;

public class IEForm extends IEHtmlElement implements Form {

    public IEForm(Element element, IE ie) throws Exception {
        super(element, ie);
    }

    public void submit() throws Exception {
        ((HTMLForm) htmlElement()).submit();
    }
}
