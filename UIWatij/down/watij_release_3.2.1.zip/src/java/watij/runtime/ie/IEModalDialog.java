package watij.runtime.ie;

import com.jniwrapper.win32.automation.OleMessageLoop;
import com.jniwrapper.win32.automation.types.BStr;
import com.jniwrapper.win32.ie.dom.HTMLDocument;
import com.jniwrapper.win32.mshtml.IHTMLDocument2;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import watij.dialogs.ModalDialog;
import watij.utilities.Debug;

public class IEModalDialog extends IEContainer implements ModalDialog {

    HTMLDocument htmlDocument;
    OleMessageLoop oleMessageLoop;
    IE ie;

    public IEModalDialog(HTMLDocument htmlDocument, OleMessageLoop oleMessageLoop, IE ie) {
        this.htmlDocument = htmlDocument;
        this.oleMessageLoop = oleMessageLoop;
        this.ie = ie;
    }

    protected HTMLDocument htmlDocument() throws Exception {
        return htmlDocument;
    }

    protected OleMessageLoop oleMessageLoop() {
        return oleMessageLoop;
    }

    protected IE ie() {
        return ie;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String html() throws Exception {
        return html(htmlDocument());
    }

    public void close() throws Exception {
        oleMessageLoop().doInvokeAndWait(new Runnable() {
            public void run() {
                try {
                    ((IHTMLDocument2) htmlDocument().getDocumentPeer()).getParentWindow()
                            .execScript(new BStr("window.opener=null;window.close();"), new BStr());
                } catch (Exception e) {
                    Debug.handleException(e);
                }
            }
        });
    }

    public Element element() throws Exception {
        return document().getDocumentElement();
    }

    protected Document document() throws Exception {
        return document(html());
    }
}
