package watij.runtime.ie;

import org.w3c.dom.Element;
import watij.elements.Button;


/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 14, 2006
 * Time: 6:37:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class IEButton extends IEHtmlElement implements Button {

    public IEButton(Element element, IE ie) throws Exception {
        super(element, ie);
    }
}
