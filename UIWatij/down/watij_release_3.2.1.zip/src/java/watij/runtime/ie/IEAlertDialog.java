package watij.runtime.ie;

import com.jniwrapper.win32.ui.Wnd;
import watij.dialogs.AlertDialog;
import watij.utilities.WatijResourceLoader;
import watij.utilities.WatijResources;

public class IEAlertDialog extends IEBaseDialog implements AlertDialog {

    public static AlertDialog findAlertDialog(IE ie) throws Exception {
        Wnd wnd = IEUtil.waitDialogWnd(IE.TITLE);
        return new IEAlertDialog(wnd, ie);
    }

    public IEAlertDialog(Wnd dialog, IE ie) {
        super(dialog, ie);
    }

    public void ok() throws Exception {
        Wnd wnd = IEUtil.waitDialogWnd(dialog, "Button", "OK");
        IEUtil.clickWindowUntilGone(wnd, dialog);
    }
}
