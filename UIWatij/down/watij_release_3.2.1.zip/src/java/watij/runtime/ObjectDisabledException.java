package watij.runtime;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: Apr 17, 2006
 * Time: 9:20:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class ObjectDisabledException extends Exception {

    public ObjectDisabledException() {
    }

    public ObjectDisabledException(String message) {
        super(message);
    }

    public ObjectDisabledException(String message, Throwable cause) {
        super(message, cause);
    }

    public ObjectDisabledException(Throwable cause) {
        super(cause);
    }
}
